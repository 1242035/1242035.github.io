#include <stdarg.h>

#define P2P_LOG_ERROR		1
#define P2P_LOG_INFO		2
#define P2P_LOG_DEBUG		3

int curr_loglevel = 2;

void log(int level, char *fmt, ...)
{
  char str[2048];

  if (curr_loglevel >= level) {
    va_list ap;
    va_start(ap, fmt);
    vsnprintf(str, 2048, fmt, ap);
    va_end(ap);
    printf("%s", str);
  }
}

int main()
{
  log(1, "name = %s (error)\n", "oni");
  log(2, "name = %s (info)\n", "oni");
  log(3, "name = %s (debug)\n", "oni");
}
