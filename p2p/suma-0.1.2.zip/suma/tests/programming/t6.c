#include <string.h>
#include <stdlib.h>

void str2argv
(char *str, const char *delim, char **holder, int *argc, char ***argv,
 void (*handler)(int *argc, char **holder, char *arg))
{
  char buf[2048];
  char *ptr = buf;

  strcpy(buf, str);
  ptr = strtok(ptr, delim);
  if (ptr != NULL) {
    do {
      handler(argc, holder, ptr);
    } while ((ptr = strtok(NULL, " ")) != NULL);
  }
  *argv = (char **)calloc(*argc + 1, sizeof(char *));
  memcpy(*argv, holder, sizeof(char *) * *argc);
}

void eps_handler(int *argc, char **holder, char *arg)
{
  holder[*argc] = malloc(strlen(arg) + 1);
  strcpy(holder[*argc], arg);
  (*argc)++;
}

void argv_handler(int *argc, char **holder, char *arg)
{
  if (strcmp(arg, "-") != 0) {
    if (strcmp(arg, "c") == 0 || strcmp(arg, "s") == 0 || strcmp(arg, "p") == 0) {
      holder[*argc] = malloc(strlen(arg) + 2);
      sprintf(holder[*argc], "-%s", arg);
      (*argc)++;
    } else {
      holder[*argc] = malloc(strlen(arg) + 1);
      sprintf(holder[*argc], "%s", arg);
      (*argc)++;
    }
  }
}

void print_argc_and_argv(int argc, char **argv)
{
  int i;

  printf("argc = %d\n", argc);
  for (i = 0; argv[i] != NULL; i++) {
    printf("argv[%d] = %s\n", i, argv[i]);
  }
}

int main()
{
  char *argv_str = "- c s p 10002";
  char *eps_str = "127.0.0.1 127.0.0.2";
  int n_argv, n_eps;
  char **argv, **eps;
  char *tmp_argv[8], *tmp_eps[8];

  tmp_argv[0] = "aaa";
  n_argv = 1;
  str2argv(argv_str, " ", tmp_argv, &n_argv, &argv, argv_handler);
  print_argc_and_argv(n_argv, argv);
  n_eps = 0;
  str2argv(eps_str, " ", tmp_eps, &n_eps, &eps, eps_handler);
  print_argc_and_argv(n_eps, eps);
}
