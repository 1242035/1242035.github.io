int main()
{
  char *a = "abcdefghijklmnaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa";
  char *b = "a";
  strncmp(a, b, strlen(a));
}
