typedef struct {
  int n;
  char name[2][5];
} a_t;

int main()
{
  a_t a;

  strcpy(a.name[0], "abcd");
  strcpy(a.name[1], "wxyz");
  printf("name = %s\n", a.name[0]);
  printf("name = %s\n", a.name[1]);
}
