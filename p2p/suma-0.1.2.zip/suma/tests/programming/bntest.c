#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <openssl/bn.h>
#include <openssl/bio.h>

BIO *open_bio()
{
  BIO *out;

  out=BIO_new(BIO_s_file());
  if (out == NULL) exit(1);
  BIO_set_fp(out,stdout,BIO_NOCLOSE);
  return out;
}

void print_result(BIO *out, BIGNUM *rval)
{
  BN_print(out, rval);
  printf(" (hex)\n");
  BIO_flush(out);
}

int main()
{
  BIGNUM a,b,c,d;
  unsigned long x = 15, y = 4;
  BIO *out;
  BN_CTX *ctx;

  out = open_bio();
  ctx = BN_CTX_new();

  BN_init(&a);
  BN_init(&b);
  BN_init(&c);
  BN_init(&d);

  BN_set_word(&a, x);
  printf("x = ");
  print_result(out, &a);
  BN_set_word(&b, y);
  printf("y = ");
  print_result(out, &b);

  printf("addition: x + y = ");
  BN_add(&c,&a,&b);
  print_result(out, &c);

  printf("division: x / y = ");
  BN_div(&d,&c,&a,&b,ctx);
  print_result(out, &d);
  printf("mod = ");
  print_result(out, &c);

  printf("exponential: x ^ y = ");
  BN_exp(&c,&a,&b,ctx);
  print_result(out, &c);
  
  BN_free(&a);
  BN_free(&b);
  BN_free(&c);
  BN_free(&d);
  return(1);
}

