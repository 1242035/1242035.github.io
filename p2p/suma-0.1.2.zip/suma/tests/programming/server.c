#include <apr.h>
#include <apr_pools.h>
#include <apr_network_io.h>
#include <apr_signal.h>
#include <stdlib.h>
#include <signal.h>

apr_pool_t *mypool;
apr_socket_t *suma_sock;

int main()
{
  apr_socket_t *accepted_sock;
  apr_sockaddr_t *localsa;
  int len;
  char buf[2048];
  apr_status_t stat;
  char msgbuf[80];

  apr_initialize();
  apr_pool_initialize();
  apr_pool_create(&mypool, 0);
  apr_socket_create(&suma_sock, AF_INET, SOCK_STREAM, mypool);
  apr_socket_addr_get(&localsa, APR_LOCAL, suma_sock);
  apr_sockaddr_port_set(localsa, 10001);
  apr_bind(suma_sock, localsa);
  apr_listen(suma_sock, 5);
  while (1) {
    apr_accept(&accepted_sock, suma_sock, mypool);
    memset(buf, 0, len = 2048);
    if ((stat = apr_recv(accepted_sock, buf, &len)) != APR_SUCCESS) {
      apr_socket_close(accepted_sock);
      printf("Problem receiving data: %s (%d)\n", 
	     apr_strerror(stat, msgbuf, sizeof(msgbuf)), stat);
      exit(-1);
    }
    printf("%s\n", buf);
    apr_socket_close(accepted_sock);
  }
  apr_socket_close(suma_sock);
  apr_pool_terminate();
  apr_terminate();
}

