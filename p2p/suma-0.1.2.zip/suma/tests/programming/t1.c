#include <apr.h>
#include <apr_uuid.h>

int main()
{
  apr_uuid_t uuid;
  char buf[64];

  apr_uuid_get(&uuid);
  apr_uuid_format(buf, &uuid);
  printf("%s\n", buf);
}
