#define RADIO_PORT	2
static int radio_cb(p2p_channel_t *chann)
{
  char buf[2048];
  int fd_in, fd_out, len;

  log(P2P_LOG_INFO, "p2p radio start\n");
  spawn("madplay -v", &fd_in, &fd_out);
  while ((len = p2p_read(chann, buf, 2048)) > 0) {
    write(fd_in, buf, len);
  }
  log(P2P_LOG_INFO, "p2p radio end\n");
}
