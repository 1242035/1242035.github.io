int main()
{
  int r, s;
  int i;

  printf("resolution     = ");
  r = atoi(gets());
  printf("index          = ");
  i = atoi(gets());
  printf("new resolution = ");
  s = atoi(gets());
  printf("
}
