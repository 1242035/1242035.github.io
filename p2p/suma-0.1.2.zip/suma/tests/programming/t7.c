#include "string.h"
/* -------------------- stubs start -------------------- */
#include <apr.h>
#include <apr_strings.h>
#include <stdarg.h>
#define P2P_LOG_ERROR		1
#define P2P_LOG_INFO		2
#define P2P_LOG_DEBUG		3
void p2p_log(int level, char *fmt, ...)
{
  char str[2048];
  va_list ap;

  va_start(ap, fmt);
  vsnprintf(str, 2048, fmt, ap);
  va_end(ap);
  printf("%s", str);
}
#define P2P_PORT		10001		/* tcp/ip service port */
static apr_pool_t *mypool;
/* -------------------- stubs end   -------------------- */

void split_ipaddr_string(char *str, char **ip_addr, int *port)
{
  char *port_str = strchr(str, ':');
  int len;

  if (port_str != NULL) {
    len = port_str - str + 1;
    port_str++;
    *port = atoi(port_str);
  } else {
    *port = P2P_PORT;
    len = strlen(str) + 1;
  }
  *ip_addr = (char *)apr_pcalloc(mypool, len);
  apr_cpystrn(*ip_addr, str, len);
  p2p_log(P2P_LOG_DEBUG, "str = %s, ip_addr = %s, port = %d\n", str, *ip_addr, *port);
}

int main()
{
  char *str[] = {"127.0.0.1:10002", "127.0.0.2", "127.0.0.3:99999", 0};
  int i;

  apr_initialize();
  apr_pool_initialize();
  apr_pool_create(&mypool, 0);
  for (i = 0; ; i++) {
    char *ip_addr;
    int port;

    if (str[i] == 0) break;
    split_ipaddr_string(str[i], &ip_addr, &port);
  }
  apr_pool_terminate();
  apr_terminate();
}
