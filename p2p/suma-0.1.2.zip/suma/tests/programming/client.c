#include <apr.h>
#include <apr_pools.h>
#include <apr_network_io.h>
#include <stdlib.h>

apr_pool_t *mypool;

int main()
{
  char *ipaddr = "127.0.0.1";
  int port = 10001;
  char *msg = "this is a message from your client.";
  apr_socket_t *sock;
  apr_sockaddr_t *remote_sa;
  apr_status_t stat;
  char msgbuf[80];
  int len;

  apr_initialize();
  apr_pool_initialize();
  apr_pool_create(&mypool, 0);
  if ((stat = apr_sockaddr_info_get(&remote_sa, ipaddr, APR_UNSPEC, port, 0, mypool)) != APR_SUCCESS) {
    printf("Address resolution failed for %s: %s\n",
	   ipaddr, apr_strerror(stat, msgbuf, sizeof(msgbuf)));
    exit(-1);
  }
  if (apr_socket_create(&sock, remote_sa->family, SOCK_STREAM, mypool) != APR_SUCCESS) {
    printf("Couldn't create socket\n");
    exit(-1);
  }
  stat = apr_connect(sock, remote_sa);
  if (stat != APR_SUCCESS) {
    apr_socket_close(sock);
    printf("Could not connect: %s (%d)\n", 
	   apr_strerror(stat, msgbuf, sizeof(msgbuf)), stat);
    exit(-1);
  }
  len = strlen(msg) + 1;
  printf("before: len = %d\n");
  if ((stat = apr_send(sock, (char *)msg, &len) != APR_SUCCESS)) {
    apr_socket_close(sock);
    printf("Problem sending data: %s (%d)\n",
	   apr_strerror(stat, msgbuf, sizeof(msgbuf)), stat);
    exit(-1);
  }
  printf("after: len = %d\n");
#if 1
#define BYE	"bye"
  printf("sending BYE\n");
  len = strlen(BYE);
  if ((stat = apr_send(sock, (char *)BYE, &len) != APR_SUCCESS)) {
    apr_socket_close(sock);
    printf("Problem sending data: %s (%d)\n",
	   apr_strerror(stat, msgbuf, sizeof(msgbuf)), stat);
    exit(-1);
  }
#endif
  apr_socket_close(sock);
  apr_pool_terminate();
  apr_terminate();
}
