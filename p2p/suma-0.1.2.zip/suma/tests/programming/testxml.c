#include "apr.h"
#include "apr_general.h"
#include "apr_xml.h"

#if APR_HAVE_STDLIB_H
#include <stdlib.h>  /* for exit() */
#endif

static void dump_xml(apr_xml_elem *e, int level)
{
  apr_xml_attr *a;
  apr_xml_elem *ec;

  printf("%d: element %s (%s)\n", level, e->name, e->first_cdata.first->text);
  if (e->attr) {
    a = e->attr;
    printf("%d:\tattrs\t", level);
    while (a) {
      printf("%s=%s\t", a->name, a->value);
      a = a->next;
    }
    printf("\n");
  }
  if (e->first_child) {
    ec = e->first_child;
    while (ec) {
      dump_xml(ec, level + 1);
      ec = ec->next;
    }
  }
}

int main(int argc, const char *const * argv)
{
  apr_pool_t *pool;
  apr_file_t *fd;
  apr_xml_parser *parser;
  apr_xml_doc *doc;
  apr_status_t rv;
  char errbuf[2000];
  char errbufXML[2000];
  char *buf;
  int ns_map = 0;
  apr_size_t size;

  (void) apr_initialize();
  apr_pool_create(&pool, NULL);
#define FNAME	"test.xml"
  rv = apr_file_open(&fd, FNAME, APR_READ, APR_OS_DEFAULT, pool);
  if (rv != APR_SUCCESS) {
    fprintf(stderr, "cannot open: %s", argv[1], rv);
  }
  rv = apr_xml_parse_file(pool, &parser, &doc, fd, 2000);
  if (rv != APR_SUCCESS) {
    fprintf(stderr, "APR Error %s\nXML Error: %s\n",
	    apr_strerror(rv, errbuf, sizeof(errbuf)),
	    apr_xml_parser_geterror(parser, errbufXML, sizeof(errbufXML)));
    return rv;
  }
  dump_xml(doc->root, 0);
  apr_xml_to_text(pool, doc->root, 
		  APR_XML_X2T_FULL,
#if 0
		  APR_XML_X2T_INNER,
		  APR_XML_X2T_LANG_INNER,
		  APR_XML_X2T_FULL_NS_LANG,
#endif
		  doc->namespaces,
		  &ns_map,
		  (const char **)&buf,
		  &size);
  printf("%s\n", buf);
  apr_file_close(fd);
  apr_pool_destroy(pool);
  apr_terminate();
  return rv;
}
