#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <openssl/bn.h>
#include <apr.h>
#include <apr_uuid.h>
#include <apr_pools.h>
#include <apr_file_io.h>

#if defined(UUID_TEST)
/* -------------------- stubs start -------------------- */
#include <stdarg.h>
#define P2P_LOG_ERROR		1
#define P2P_LOG_INFO		2
#define P2P_LOG_DEBUG		3
void p2p_log(int level, char *fmt, ...)
{
  char str[2048];
  va_list ap;

  va_start(ap, fmt);
  vsnprintf(str, 2048, fmt, ap);
  va_end(ap);
  printf("%s", str);
}
static apr_pool_t *mypool;
apr_uuid_t uuid;
/* -------------------- stubs end   -------------------- */
#endif	/* UUID_TEST */


#define UUID_FILENAME	"uuid.file"

/*
(* 4-tree hash function
H(x,0) = 0
H(x,r) = H(x,r-1) * 4 + (x%(4^r) / 4^(r-1))
*)
let pow4 x = int_of_float (4.0 ** float_of_int x)
let rec t4 id r =
  if r = 0 then 0
  else
    (((t4 id (r-1)) * 4) + ((id mod (pow4 r)) / (pow4 (r - 1))))
*/
static BIGNUM t4(BIGNUM id, unsigned long r) {
  BIGNUM rval;

  BN_init(&rval);
  if (r == 0) {
    BN_set_word(&rval, 0);
  } else {
    BIGNUM tmp = t4(id, r - 1);
    BIGNUM t1, v4, p4r, vr, dummy, t2, t3;
    BN_CTX *ctx;

    /* 1st term */
    BN_init(&v4);
    BN_init(&t1);
    BN_set_word(&v4, 4);
    ctx = BN_CTX_new();
    BN_mul(&t1, &tmp, &v4, ctx);

    /* 2nd term */
    BN_init(&p4r);
    BN_init(&vr);
    BN_set_word(&vr, r);
    BN_exp(&p4r, &v4, &vr, ctx);
    BN_init(&dummy);
    BN_init(&t2);
    BN_div(&dummy, &t2, &id, &p4r, ctx);

    /* 3rd term */
    BN_init(&vr);
    BN_init(&t3);
    BN_set_word(&vr, r - 1);
    BN_exp(&t3, &v4, &vr, ctx);

    /* now, calculate (t2 / t3) */
    BN_init(&tmp);
    BN_div(&tmp, &dummy, &t2, &t3, ctx);

    /* now, calculate (t1 + (t2 / t3)) */
    BN_add(&rval, &t1, &tmp);
  }
  return rval;
}

/*
(* 2-d hash function
H(x,0) = (0,0)
H(x,r) = H(x,r-1) * r + (dx, dy)
*)
let rec h2 id r =
  if r = 0 then (0,0)
  else
    let (x,y) = h2 (id / 4) (r-1) in
    let xx = x * 2 in
    let yy = y * 2 in
    match (id mod 4) with
      0 -> (xx,yy)
    | 1 -> (xx+1,yy)
    | 2 -> (xx,yy+1)
    | 3 -> (xx+1,yy+1)
*/
static void h2(BIGNUM id, unsigned long r, unsigned long *x, unsigned long *y) {
  if (r == 0) {
    *x = 0;
    *y = 0;
  } else {
    BIGNUM tmp, v4, dummy, bn_m;
    BN_CTX *ctx;
    unsigned long xx, yy, w_m;

    BN_init(&v4);
    BN_init(&tmp);
    BN_init(&dummy);
    BN_set_word(&v4, 4);
    ctx = BN_CTX_new();
    BN_div(&tmp, &dummy, &id, &v4, ctx);
    h2(tmp, r - 1, x, y);
    xx = *x * 2;
    yy = *y * 2;
    BN_init(&bn_m);
    BN_div(&dummy, &bn_m, &id, &v4, ctx);
    w_m = BN_get_word(&bn_m);
    switch (w_m) {
    case 0: *x = xx    ; *y = yy    ; break;
    case 1: *x = xx + 1; *y = yy    ; break;
    case 2: *x = xx    ; *y = yy + 1; break;
    case 3: *x = xx + 1; *y = yy + 1; break;
    default:
      p2p_log(P2P_LOG_ERROR, "h2(): illegal mod value.\n");
      exit(-1);
    }
  }
  return;
}

/*
let p2p_hash id r =
  let u = t4 id r in
  h2 u r
*/
void p2p_hash(BIGNUM id, unsigned long r, unsigned long x, unsigned long y)
{
  BIGNUM bn_rval = t4(id, r);

  h2(bn_rval, r, &x, &y);
}

void set_uuid()
{
  apr_file_t *f = NULL;
  char buf[64];
  apr_status_t stat;

  stat = apr_file_open(&f, UUID_FILENAME, APR_READ, APR_OS_DEFAULT, mypool);
  if (stat != APR_SUCCESS) {
    p2p_log(P2P_LOG_DEBUG, "set_uuid(): open failed. trying to create\n");
    stat = apr_file_open(&f, UUID_FILENAME, APR_WRITE | APR_CREATE, APR_OS_DEFAULT, mypool);
    if (stat == APR_SUCCESS) {
      p2p_log(P2P_LOG_DEBUG, "set_uuid(): created successfully. trying to store new uuid...\n");
      apr_uuid_get(&uuid);
      apr_uuid_format(buf, &uuid);
      apr_file_puts(buf, f);
      apr_file_close(f);
      p2p_log(P2P_LOG_DEBUG, "set_uuid(): ...done\n");
    } else {
      p2p_log(P2P_LOG_DEBUG, "set_uuid(): cannot create uuid file.\n");
      exit(-1);
    }
  } else {
    p2p_log(P2P_LOG_DEBUG, "set_uuid(): opened successfully. \n");
    memset(buf, 0, 64);
    apr_file_gets(buf, APR_UUID_FORMATTED_LENGTH + 1, f);
    p2p_log(P2P_LOG_DEBUG, "set_uuid(): uuid = %s\n", buf);
    apr_uuid_parse(&uuid, buf);
    apr_file_close(f);
    p2p_log(P2P_LOG_DEBUG, "set_uuid(): ...done\n");
  }
}

#if defined(UUID_TEST)
#include <math.h>
/*
let t4s r =
  for i = 0 to (pow4 r) - 1 do
    print_int (t4 i r); (* print_string " " *)print_newline()
  done(*;
  print_newline()
*/
static void t4s(unsigned long r)
{
  unsigned long i;
  double lim;
  BIGNUM uuid, bn_rval;
  unsigned long w_rval;

  lim = pow(4, r);
  for (i = 0; i < lim; i++) {
    BN_init(&uuid);
    BN_set_word(&uuid, i);
    bn_rval = t4(uuid, r);
    w_rval = BN_get_word(&bn_rval);
    printf("%d -> %d\n", i, w_rval);
  }
}

/*
let h2s r =
  for i = 0 to (pow4 r) - 1 do
    let u = t4 i r in
    let (x,y) = h2 u r in
    Printf.printf "%d\t->\t%d:\t(%d,%d)" i u x y; print_newline()
  done
*/
static void h2s(unsigned long r)
{
  unsigned long i;
  double lim;
  BIGNUM uuid, bn_rval;
  unsigned long w_rval, x, y;

  lim = pow(4, r);
  for (i = 0; i < lim; i++) {
    BN_init(&uuid);
    BN_set_word(&uuid, i);
    bn_rval = t4(uuid, r);
    w_rval = BN_get_word(&bn_rval);
    h2(bn_rval, r, &x, &y);
    printf("%d\t->\t%d:\t(%d,%d)\n", i, w_rval, x, y);
  }
}

int main()
{
  char buf[64];

  apr_initialize();
  apr_pool_initialize();
  apr_pool_create(&mypool, 0);

#if 0
  set_uuid();
  apr_uuid_format(buf, &uuid);
  printf("%s\n", buf);

  t4s(3);
#endif

  h2s(2);

  apr_pool_terminate();
  apr_terminate();

  return(1);
}
#endif	/* UUID_TEST */
