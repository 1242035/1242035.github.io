#include <apr.h>
#include <apr_pools.h>
#include <apr_network_io.h>
#include <stdlib.h>
#include <util.h>

#define DEBUG_PORT	90001

apr_pool_t *mypool;

static void read_loop(apr_socket_t *sock)
{
  /* FIXME: not yet */
  char buf[2048];
  int len;
  apr_status_t stat;
  char msgbuf[80];
  char *ptr;

  while (1) {
    memset(buf, 0, len = 2048);
    if ((stat = apr_recv(sock, buf, &len)) != APR_SUCCESS) {
      apr_socket_close(sock);
      printf("Problem receiving data: %s (%d)\n", 
	     apr_strerror(stat, msgbuf, sizeof(msgbuf)), stat);
      return;
    }
    ptr = buf;
    while (1) {
      if (strncmp(ptr, "byebye", 6) == 0) {
	return;
      } else {
	printf("%s", ptr);
      }
      len -= (strlen(ptr) + 1);
      if (len == 0)
	break;
      else
	ptr += (strlen(ptr) + 1);
    }
  }
}

static void main_loop(apr_socket_t *sock, apr_sockaddr_t *remote_sa)
{
  apr_status_t stat;
  char buf[2048];
  char msgbuf[80];
  int len;

  while (1) {
    printf("debugger> ");
    gets(buf);
    if (strncmp(buf, "quit", 4) == 0) {
      /* FIXME: send quit-msg. */
      return;
    }
    if (apr_socket_create(&sock, remote_sa->family, SOCK_STREAM, mypool) != APR_SUCCESS) {
      printf("Couldn't create socket\n");
      exit(-1);
    }
    stat = apr_connect(sock, remote_sa);
    if (stat != APR_SUCCESS) {
      apr_socket_close(sock);
      printf("Could not connect: %s (%d)\n", 
	     apr_strerror(stat, msgbuf, sizeof(msgbuf)), stat);
      exit(-1);
    }
    len = strlen(buf) + 1;
    if ((stat = apr_send(sock, buf, &len) != APR_SUCCESS)) {
      apr_socket_close(sock);
      printf("Problem sending data: %s (%d)\n",
	     apr_strerror(stat, msgbuf, sizeof(msgbuf)), stat);
      break;
    }
    read_loop(sock);
#if 0
#define BYE	"bye"
    printf("sending BYE\n");
    len = strlen(BYE);
    if ((stat = apr_send(sock, (char *)BYE, &len) != APR_SUCCESS)) {
      apr_socket_close(sock);
      printf("Problem sending data: %s (%d)\n",
	     apr_strerror(stat, msgbuf, sizeof(msgbuf)), stat);
      exit(-1);
    }
#endif
    apr_socket_close(sock);
  }
}

void usage()
{
  printf("debugger ip-address:port\n");
  exit(-1);
}

int main(int argc, char *argv[])
{
  char *ipaddr;
  int port;
  apr_socket_t *sock;
  apr_sockaddr_t *remote_sa;
  apr_status_t stat;
  char msgbuf[80];

  apr_initialize();
  apr_pool_initialize();
  apr_pool_create(&mypool, 0);
  if (argc != 2)
    usage();
  split_ipaddr_string(argv[1], &ipaddr, &port, DEBUG_PORT);
  if ((stat = apr_sockaddr_info_get(&remote_sa, ipaddr, APR_UNSPEC, port, 0, mypool)) != APR_SUCCESS) {
    printf("Address resolution failed for %s: %s\n",
	   ipaddr, apr_strerror(stat, msgbuf, sizeof(msgbuf)));
    exit(-1);
  }
  main_loop(sock, remote_sa);
  apr_pool_terminate();
  apr_terminate();
}
