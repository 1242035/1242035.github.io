../bot -s ../../../settings/settings2l.xml
