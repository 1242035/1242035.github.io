../im -s ../../../settings/settings3l.xml
