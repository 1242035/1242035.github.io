../im -s ../../../settings6.xml
