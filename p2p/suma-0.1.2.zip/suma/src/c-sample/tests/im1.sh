../im -s ../../../settings/settings1.xml
