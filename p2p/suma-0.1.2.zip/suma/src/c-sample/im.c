#include <string.h>
#include <apr.h>
#include <apr_pools.h>
#include <apr_ring.h>
#include <apr_strings.h>
#include <sumalib.h>
#include <command.h>
#include <mystream.h>

#define IM_PORT		1

typedef struct im_friend_s im_friend_t;

typedef struct im_friend_link_s im_friend_link_t;
struct im_friend_link_s {
  im_friend_t *prev;
  im_friend_t *next;
};

struct im_friend_s {
  char name[16];
  char uuid[P2P_UUID_FORMATTED_LENGTH + 1];
  im_friend_link_t link;
};

static char myname[16];
static im_friend_link_t friends;
static apr_pool_t *mypool;

static void parse_user(char *user, char **name, char **uuid)
{
  *uuid = strchr(user, '@');
  **uuid = 0;
  (*uuid)++;
  *name = user;
}

/* login  : create an user locally and set his status 'present'
 */
static void login(mystream_t *mystream, char **argv, char *rest) {
  apr_cpystrn(myname, argv[0], strlen(argv[0]) + 1);
}

/* catch  : ask a remote user to be a friend and get OK or NG
 */
static void catch(mystream_t *mystream, char **argv, char *rest)
{
  p2p_channel_t *chann;
  char *name, *uuidstr;
  char buf[64];
  char myuuid[P2P_UUID_FORMATTED_LENGTH + 1];
  im_friend_t *friend;

  parse_user(argv[0], &name, &uuidstr);
  chann = p2p_create_unicast_channel(IM_PORT, uuidstr);
  p2p_uuid_format(myuuid, &uuid);
  sprintf(buf, "catch %s %s %s", myname, myuuid, name);
  p2p_write(chann, buf, strlen(buf) + 1);

  /* FIXME: get reply */
  p2p_close_channel(chann);
  friend = (im_friend_t *)apr_pcalloc(mypool, sizeof(im_friend_t));
  apr_cpystrn(friend->name, name, strlen(name) + 1);
  apr_cpystrn(friend->uuid, uuidstr, strlen(uuidstr) + 1);
  APR_RING_INSERT_TAIL(&friends, friend, im_friend_s, link);
}

/* talk   : talk to a remote user
 */
static void talk(mystream_t *mystream, char **argv, char *rest)
{
  p2p_channel_t *chann;
  char *name, *uuid;
  char buf[2048];

  parse_user(argv[0], &name, &uuid);
  chann = p2p_create_unicast_channel(IM_PORT, uuid);
  sprintf(buf, "talk %s %s %s", myname, name, rest);
  p2p_write(chann, buf, strlen(buf) + 1);
  p2p_close_channel(chann);
}

/* leave  : change my status to 'absent' and let friends know
 */
static void leave(mystream_t *mystream, char **argv, char *rest)
{
  p2p_channel_t *chann;
  char buf[64];
  im_friend_t *friend;
  int n_dst = 0, i;
  p2p_destinations_t *dst;

  APR_RING_FOREACH(friend, &friends, im_friend_s, link) n_dst++;
  dst = apr_pcalloc(mypool, sizeof(p2p_destinations_t) + (P2P_UUID_FORMATTED_LENGTH + 1) * n_dst);
  dst->n_dst = n_dst;
  i = 0;
  APR_RING_FOREACH(friend, &friends, im_friend_s, link) {
    apr_cpystrn(dst->uuids[i++], friend->uuid, P2P_UUID_FORMATTED_LENGTH + 1);
  }
  chann = p2p_create_multicast_channel(IM_PORT, dst);
  sprintf(buf, "leave %s", myname);
  p2p_write(chann, buf, strlen(buf) + 1);
  p2p_close_channel(chann);
}

/* back   : change my status to 'present' and let friends know
 */
static void back(mystream_t *mystream, char **argv, char *rest)
{
  p2p_channel_t *chann;
  char buf[64];
  im_friend_t *friend;
  int n_dst = 0, i;
  p2p_destinations_t *dst;

  APR_RING_FOREACH(friend, &friends, im_friend_s, link) n_dst++;
  dst = apr_pcalloc(mypool, sizeof(p2p_destinations_t) + (P2P_UUID_FORMATTED_LENGTH + 1) * n_dst);
  dst->n_dst = n_dst;
  i = 0;
  APR_RING_FOREACH(friend, &friends, im_friend_s, link) {
    apr_cpystrn(dst->uuids[i++], friend->uuid, P2P_UUID_FORMATTED_LENGTH + 1);
  }
  chann = p2p_create_multicast_channel(IM_PORT, dst);
  sprintf(buf, "back %s", myname);
  p2p_write(chann, buf, strlen(buf) + 1);
  p2p_close_channel(chann);
}

/* list   : print all friends and their status
 */
static void list(mystream_t *mystream, char **argv, char *rest)
{
  im_friend_t *friend;

  APR_RING_FOREACH(friend, &friends, im_friend_s, link) {
    printf("%s@%s\n", friend->name, friend->uuid);
  }
}

/* callback (server-side functions)
 */
static void catch_cb(mystream_t *mystream, char **argv, char *rest)
{
  char *name = argv[0], *uuidstr = argv[1];
  im_friend_t *friend;

  printf("%s@%s caught you.\n", name, uuidstr);
  friend = (im_friend_t *)apr_pcalloc(mypool, sizeof(im_friend_t));
  apr_cpystrn(friend->name, name, strlen(name) + 1);
  apr_cpystrn(friend->uuid, uuidstr, strlen(uuidstr) + 1);
  APR_RING_INSERT_TAIL(&friends, friend, im_friend_s, link);
}

static void talk_cb(mystream_t *mystream, char **argv, char *rest)
{
  char *friend_name = argv[0], *myname = argv[1], *msg = rest;

  printf("%s> %s\n", friend_name, msg);
}

static void leave_cb(mystream_t *mystream, char **argv, char *rest)
{
  char *name = argv[0];

  printf("%s is away from computer.\n", name);
}

static void back_cb(mystream_t *mystream, char **argv, char *rest)
{
  char *name = argv[0];

  printf("%s has come back.\n", name);
}

#define N_MSG_COMMANDS		4
command_t msg_commands[] = {
  {"catch", 3, 0, catch_cb},
  {"talk",  2, 1, talk_cb},
  {"leave", 1, 0, leave_cb},
  {"back",  1, 0, back_cb}
};

static int im_cb(p2p_channel_t *chann)
{
  char buf[2048];

  p2p_read(chann, buf, 2048);
  dispatch(0, buf, N_MSG_COMMANDS, msg_commands);
}

/* im     : start dialog session
 */
#define N_SHELL_COMMANDS	10
command_t shell_commands[] = {
  {"login", 1, 0, login},
  {"catch", 1, 0, catch},
  {"talk",  1, 1, talk},
  {"leave", 0, 0, leave},
  {"back",  0, 0, back},
  {"list",  0, 0, list},

  /* basic commands */
  {"conn",  0, 0, p2p_list_connections},
  {"chann", 0, 0, p2p_list_channels},
  {"log?",  0, 0, p2p_show_loglevel},
  {"log=",  1, 0, p2p_set_loglevel},
};

static void im()
{
  char buf[2048];
  char uuidstr[P2P_UUID_FORMATTED_LENGTH + 1];
  apr_file_t *file;
  mystream_t *mystream;

  p2p_uuid_format(uuidstr, &uuid);
  p2p_log(P2P_LOG_INFO, "im started on %s\n", uuidstr);
  APR_RING_INIT(&friends, im_friend_s, link);
  p2p_register_response_callback(IM_PORT, im_cb);
  apr_file_open_stdout(&file, mypool);
  mystream = file2mystream(mypool, file);
  while (1) {
    printf("im> ");
    gets(buf);
    if (strncmp(buf, "quit", 4) == 0) {
      /* FIXME: send quit-msg. */
      return;
    }
    dispatch(mystream, buf, N_SHELL_COMMANDS, shell_commands);
  }
}

/*-------------- simple im app end   -----------------*/

void print_argc_and_argv(int argc, char **argv)
{
  int i;

  p2p_log(P2P_LOG_DEBUG, "argc = %d\n", argc);
  for (i = 0; argv[i] != NULL; i++) {
    p2p_log(P2P_LOG_DEBUG, "argv[%d] = %s\n", i, argv[i]);
  }
}

int main(int argc, char *argv[])
{
#if 0
  char *ep_addrs[] = {"127.0.0.1", 0};
#else
  char *ep_addrs[] = {0};
#endif

  print_argc_and_argv(argc, argv);
  p2p_init(argc, argv, ep_addrs);
  apr_pool_create(&mypool, 0);
  im();
  p2p_shutdown();
}
