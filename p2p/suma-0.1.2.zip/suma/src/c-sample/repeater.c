#include <string.h>
#include <apr.h>
#include <apr_pools.h>
#include <apr_ring.h>
#include <apr_strings.h>
#include <sumalib.h>
#include <command.h>
#include <mystream.h>

static apr_pool_t *mypool;

/* repeater : start dialog session
 */
#define N_SHELL_COMMANDS	4
command_t shell_commands[] = {
  /* basic commands */
  {"conn",  0, 0, p2p_list_connections},
  {"chann", 0, 0, p2p_list_channels},
  {"log?",  0, 0, p2p_show_loglevel},
  {"log=",  1, 0, p2p_set_loglevel},
};

static void repeater()
{
  char buf[2048];
  char uuidstr[P2P_UUID_FORMATTED_LENGTH + 1];
  apr_file_t *file;
  mystream_t *mystream;

  p2p_uuid_format(uuidstr, &uuid);
  p2p_log(P2P_LOG_INFO, "repeater started on %s\n", uuidstr);
  apr_file_open_stdout(&file, mypool);
  mystream = file2mystream(mypool, file);
  while (1) {
    printf("rep> ");
    gets(buf);
    if (strncmp(buf, "quit", 4) == 0) {
      /* FIXME: send quit-msg. */
      return;
    }
    dispatch(mystream, buf, N_SHELL_COMMANDS, shell_commands);
  }
}

/*-------------- simple repeater app end   -----------------*/

void print_argc_and_argv(int argc, char **argv)
{
  int i;

  p2p_log(P2P_LOG_DEBUG, "argc = %d\n", argc);
  for (i = 0; argv[i] != NULL; i++) {
    p2p_log(P2P_LOG_DEBUG, "argv[%d] = %s\n", i, argv[i]);
  }
}

int main(int argc, char *argv[])
{
#if 0
  char *ep_addrs[] = {"127.0.0.1", 0};
#else
  char *ep_addrs[] = {0};
#endif

  print_argc_and_argv(argc, argv);
  p2p_init(argc, argv, ep_addrs);
#if 0
  apr_pool_create(&mypool, 0);
  repeater();
#endif
  p2p_shutdown();
}
