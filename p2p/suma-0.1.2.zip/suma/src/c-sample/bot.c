#include <string.h>
#include <apr.h>
#include <apr_pools.h>
#include <apr_ring.h>
#include <apr_strings.h>
#include <sumalib.h>
#include <command.h>
#include <mystream.h>

#define IM_PORT		1

static char *myname = "bot";
static apr_pool_t *mypool;

static void parse_user(char *user, char **name, char **uuid)
{
  *uuid = strchr(user, '@');
  **uuid = 0;
  (*uuid)++;
  *name = user;
}

/* callback (server-side functions)
   o  catch_cb
   o  catchall_cb
   o  catchme_cb
   o  talk_cb
   o  leave_cb
   o  back_cb
   o  hello_cb
   o  hello2_cb
 */

static void catch_cb(mystream_t *mystream, char **argv, char *rest)
{
  char *name = argv[0], *uuidstr = argv[1];

  p2p_log(P2P_LOG_INFO, "%s@%s caught me.\n", name, uuidstr);
}

static void catchall_cb(mystream_t *mystream, char **argv, char *rest)
{
  char *friend_loc = argv[0];
  p2p_channel_t *chann;
  char buf[2048];
  char my_loc[P2P_UUID_FORMATTED_LENGTH + 1];

  printf("!!!here!!!\n");
  p2p_log(P2P_LOG_INFO, "%s listing all.\n", friend_loc);
  chann = p2p_create_unicast_channel(IM_PORT, friend_loc);
  p2p_uuid_format(my_loc, &uuid);
  sprintf(buf, "catchme %s %s", myname, my_loc);
  p2p_write(chann, buf, strlen(buf) + 1);
  p2p_close_channel(chann);
}

static void catchme_cb(mystream_t *mystream, char **argv, char *rest)
{
  /* do nothing */
}

static void talk_cb(mystream_t *mystream, char **argv, char *rest)
{
  char *friend_name = argv[0], *friend_loc = argv[2], *msg = rest;
  char *mymsg = "i'm a bot. your message is recorded.";
  p2p_channel_t *chann;
  char buf[2048];
  char my_loc[P2P_UUID_FORMATTED_LENGTH + 1];

  p2p_log(P2P_LOG_INFO, "talk: %s> %s\n", friend_name, msg);
  chann = p2p_create_unicast_channel(IM_PORT, friend_loc);
  p2p_uuid_format(my_loc, &uuid);
  sprintf(buf, "talk %s %s %s %s", myname, friend_name, my_loc, mymsg);
  p2p_write(chann, buf, strlen(buf) + 1);
  p2p_close_channel(chann);
  p2p_log(P2P_LOG_INFO, "talk: %s> %s\n", myname, mymsg);
}

static void leave_cb(mystream_t *mystream, char **argv, char *rest)
{
  char *name = argv[0];

  p2p_log(P2P_LOG_INFO, "%s is away from computer.\n", name);
}

static void back_cb(mystream_t *mystream, char **argv, char *rest)
{
  char *name = argv[0];

  p2p_log(P2P_LOG_INFO, "%s has come back.\n", name);
}

static void hello_cb(mystream_t *mystream, char **argv, char *rest)
{
  char *name = argv[0];

  p2p_log(P2P_LOG_INFO, "%s said hello to me.\n", name);
}

static void hello2_cb(mystream_t *mystream, char **argv, char *rest)
{
  char *name = argv[0], *friend_loc = argv[1];
  p2p_channel_t *chann;
  char buf[2048];

  p2p_log(P2P_LOG_INFO, "%s added me as a friend.\n", name);
  chann = p2p_create_unicast_channel(IM_PORT, friend_loc);
  sprintf(buf, "back %s", myname);
  p2p_write(chann, buf, strlen(buf) + 1);
  p2p_close_channel(chann);
}

#define N_MSG_COMMANDS		8
command_t msg_commands[] = {
  {"catchall",	1, 0, catchall_cb},	/* FIXME: order is important. */
  {"catchme",	2, 0, catchme_cb},	/* FIXME: order is important. */
  {"catch",	3, 0, catch_cb},	/* FIXME: order is important. */
  {"talk",	3, 1, talk_cb},
  {"leave",	1, 0, leave_cb},
  {"back",	1, 0, back_cb},
  {"hello2",	2, 0, hello2_cb},	/* FIXME: order is important. */
  {"hello",	1, 0, hello_cb},	/* FIXME: order is important. */
};

static int im_cb(p2p_channel_t *chann)
{
  char buf[2048];

  p2p_read(chann, buf, 2048);
  dispatch(0, buf, N_MSG_COMMANDS, msg_commands);
}

static void im_bot()
{
  char buf[2048];
  char uuidstr[P2P_UUID_FORMATTED_LENGTH + 1];
  apr_file_t *file;
  mystream_t *mystream;

  p2p_uuid_format(uuidstr, &uuid);
  p2p_log(P2P_LOG_INFO, "im started on %s\n", uuidstr);
  p2p_register_response_callback(IM_PORT, im_cb);
}

/*-------------- simple im app end   -----------------*/

void print_argc_and_argv(int argc, char **argv)
{
  int i;

  p2p_log(P2P_LOG_DEBUG, "argc = %d\n", argc);
  for (i = 0; argv[i] != NULL; i++) {
    p2p_log(P2P_LOG_DEBUG, "argv[%d] = %s\n", i, argv[i]);
  }
}

int main(int argc, char *argv[])
{
#if 0
  char *ep_addrs[] = {"127.0.0.1", 0};
#else
  char *ep_addrs[] = {0};
#endif

  print_argc_and_argv(argc, argv);
  p2p_init(argc, argv, ep_addrs);
  apr_pool_create(&mypool, 0);
  im_bot();
  p2p_shutdown();
}
