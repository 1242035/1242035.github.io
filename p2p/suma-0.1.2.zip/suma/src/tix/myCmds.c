/* progress:
   o  My_p2p_init (02-07-07)
   o  My_p2p_shutdown (02-07-07)
   o  My_p2p_create_broadcast_channel (02-07-07)
   o  My_p2p_create_multicast_channel (02-07-08)
   o  My_p2p_create_unicast_channel (02-07-07)
   o  My_p2p_write (02-07-08)
   o  My_p2p_read (02-07-08)
   o  My_p2p_close_channel (02-07-07)
   o  My_p2p_myuuid (02-07-08)
   o  My_p2p_get_active_channel (02-07-08)
*/
#include <tk.h>
#include <tix.h>
#include <string.h>
#include <stdlib.h>
#include <apr.h>
#include <apr_pools.h>
#include <apr_hash.h>
#include <apr_ring.h>
#include <apr_strings.h>
#include <apr_thread_mutex.h>
#include <sumalib.h>
#if 1
#include <chann.h>
#endif

static apr_pool_t *mypool;
static int cnt_chann = 1;
static apr_hash_t *chann_tbl;

static apr_thread_mutex_t *chann_hash_mutex;

static int register_channel(p2p_channel_t *chann)
{
  apr_status_t s;

  s = apr_thread_mutex_lock(chann_hash_mutex);
  if (s != APR_SUCCESS) {
    printf("register_channel(): mutex lock failed!\n");
  }
  {
#if 1
    int *chann_id = (int *)malloc(sizeof(int));

    memcpy(chann_id, &cnt_chann, sizeof(int));
    apr_hash_set(chann_tbl, chann_id, sizeof(int), chann);
#else	/* this won't work */
    apr_hash_set(chann_tbl, &cnt_chann, sizeof(int), chann);
#endif
  }
  s = apr_thread_mutex_unlock(chann_hash_mutex);
  if (s != APR_SUCCESS) {
    printf("register_channel(): mutex unlock failed!\n");
  }
  return cnt_chann++;
}

static void unregister_channel(int chann_id)
{
  apr_status_t s;

  s = apr_thread_mutex_lock(chann_hash_mutex);
  if (s != APR_SUCCESS) {
    printf("unregister_channel(): mutex lock failed!\n");
  }
  {
#if 1
    int *tmp = (int *)malloc(sizeof(int));

    memcpy(tmp, &chann_id, sizeof(int));
    apr_hash_set(chann_tbl, tmp, sizeof(int), NULL);
#else	/* this won't work */
    apr_hash_set(chann_tbl, tmp, sizeof(int), NULL);
#endif
  }
  s = apr_thread_mutex_unlock(chann_hash_mutex);
  if (s != APR_SUCCESS) {
    printf("unregister_channel(): mutex unlock failed!\n");
  }
}

static void str2argv
(char *str, const char *delim, char **holder, int *argc, char ***argv,
 void (*handler)(int *argc, char **holder, char *arg))
{
  char buf[2048];
  char *ptr = buf;

  strcpy(buf, str);
  ptr = strtok(ptr, delim);
  if (ptr != NULL) {
    do {
      handler(argc, holder, ptr);
    } while ((ptr = strtok(NULL, " ")) != NULL);
  }
  *argv = (char **)calloc(*argc + 1, sizeof(char *));
  memcpy(*argv, holder, sizeof(char *) * *argc);
}

static void standard_handler(int *argc, char **holder, char *arg)
{
  holder[*argc] = malloc(strlen(arg) + 1);
  strcpy(holder[*argc], arg);
  (*argc)++;
}

static void eps_handler(int *argc, char **holder, char *arg)
{
  standard_handler(argc, holder, arg);
}

static void dst_handler(int *argc, char **holder, char *arg)
{
  standard_handler(argc, holder, arg);
}

static void argv_handler(int *argc, char **holder, char *arg)
{
  if (strcmp(arg, "-") != 0) {
#if defined(XML_SETTINGS)
    if (strcmp(arg, "s") == 0) {
#else
    if (strcmp(arg, "c") == 0 || strcmp(arg, "s") == 0 || strcmp(arg, "u") == 0
	|| strcmp(arg, "e") == 0 || strcmp(arg, "p") == 0) {
#endif	/* XML_SETTINGS */
      holder[*argc] = malloc(strlen(arg) + 2);
      sprintf(holder[*argc], "-%s", arg);
      (*argc)++;
    } else {
      holder[*argc] = malloc(strlen(arg) + 1);
      sprintf(holder[*argc], "%s", arg);
      (*argc)++;
    }
  }
}

static void print_argc_and_argv(char *func, int argc, char **argv)
{
  int i;

  printf("%s: argc = %d\n", func, argc);
  for (i = 0; argv[i] != NULL; i++) {
    printf("%s: argv[%d] = %s\n", func, i, argv[i]);
  }
}

typedef struct tix_channel_s tix_channel_t;

typedef struct tix_channel_link_s tix_channel_link_t;
struct tix_channel_link_s {
  tix_channel_t *prev;
  tix_channel_t *next;
};

struct tix_channel_s {
  int chann_id;
  tix_channel_link_t link;
};

static tix_channel_link_t active_channels;

static int tix_cb(p2p_channel_t *chann)
{
  int chann_id;
  tix_channel_t *tix_chann;

  printf("tix_cb(): start with chann = 0x%08x\n", chann);
  chann_id = register_channel(chann);
  tix_chann = (tix_channel_t *)malloc(sizeof(tix_channel_t));
  tix_chann->chann_id = chann_id;
  APR_RING_INSERT_TAIL(&active_channels, tix_chann, tix_channel_s, link);
  printf("tix_cb(): end with chann_id = %d\n", chann_id);
  return 0;
}

int My_p2p_init(clientData, interp, argc, argv)
     ClientData clientData;
     Tcl_Interp *interp;	/* Current interpreter. */
     int argc;			/* Number of arguments. */
     char **argv;		/* Argument strings. */
{
  int port, i, n_args, n_eps;
  char **args, **eps;
  char *tmp_args[8], *tmp_eps[8];
  apr_status_t s;

  if (argc != 4) {
    return Tix_ArgcError(interp, 1, argv, 1, "port argv eps");
  }
  if (Tcl_GetInt(interp, argv[1], &port) != TCL_OK) {
    return TCL_ERROR;
  }
  tmp_args[0] = "aaa";
  n_args = 1;
  str2argv(argv[2], " ", tmp_args, &n_args, &args, argv_handler);
  print_argc_and_argv(argv[0], n_args, args);
  n_eps = 0;
  str2argv(argv[3], " ", tmp_eps, &n_eps, &eps, eps_handler);
  print_argc_and_argv(argv[0], n_eps, eps);
  p2p_init(n_args, args, eps);
  apr_pool_create(&mypool, 0);
  chann_tbl = apr_hash_make(mypool);

  APR_RING_INIT(&active_channels, tix_channel_s, link);
  p2p_register_response_callback(port, tix_cb);
  s = apr_thread_mutex_create(&(chann_hash_mutex), APR_THREAD_MUTEX_DEFAULT, mypool);
  if (s != APR_SUCCESS) {
    printf("mutex creation failed!\n");
    return 0;
  }

  return TCL_OK;
}

int My_p2p_shutdown(clientData, interp, argc, argv)
     ClientData clientData;
     Tcl_Interp *interp;	/* Current interpreter. */
     int argc;			/* Number of arguments. */
     char **argv;		/* Argument strings. */
{
  if (argc != 1) {
    return Tix_ArgcError(interp, 1, argv, 1, "none");
  }
  p2p_shutdown();
  return TCL_OK;
}

int My_p2p_create_broadcast_channel(clientData, interp, argc, argv)
     ClientData clientData;
     Tcl_Interp *interp;	/* Current interpreter. */
     int argc;			/* Number of arguments. */
     char **argv;		/* Argument strings. */
{
  p2p_channel_t *chann;
  int port, chann_id;
  char buf[30];

  if (argc != 2) {
    return Tix_ArgcError(interp, 1, argv, 1, "port(integer)");
  }
  if (Tcl_GetInt(interp, argv[1], &port) != TCL_OK) {
    return TCL_ERROR;
  }
  chann = p2p_create_broadcast_channel(port);
  chann_id = register_channel(chann);
  sprintf(buf, "%d", chann_id);
  Tcl_AppendResult(interp, buf, NULL);
  return TCL_OK;
}

int My_p2p_create_multicast_channel(clientData, interp, argc, argv)
     ClientData clientData;
     Tcl_Interp *interp;	/* Current interpreter. */
     int argc;			/* Number of arguments. */
     char **argv;		/* Argument strings. */
{
  p2p_channel_t *chann;
  int port, chann_id;
  char buf[30];
  int i, n_dst;
  char **args;
  char *tmp_args[8];
  p2p_destinations_t *dst;

  if (argc != 3) {
    return Tix_ArgcError(interp, 1, argv, 1, "port(integer) dst");
  }
  if (Tcl_GetInt(interp, argv[1], &port) != TCL_OK) {
    return TCL_ERROR;
  }
  n_dst = 0;
  str2argv(argv[2], " ", tmp_args, &n_dst, &args, dst_handler);
  dst = apr_pcalloc(mypool, sizeof(p2p_destinations_t) + (P2P_UUID_FORMATTED_LENGTH + 1) * n_dst);
  dst->n_dst = n_dst;
  i = 0;
  for (i = 0; i < n_dst; i++) {
    apr_cpystrn(dst->uuids[i], args[i], P2P_UUID_FORMATTED_LENGTH + 1);
  }
  chann = p2p_create_multicast_channel(port, dst);
  chann_id = register_channel(chann);
  sprintf(buf, "%d", chann_id);
  Tcl_AppendResult(interp, buf, NULL);
  return TCL_OK;
}

int My_p2p_create_unicast_channel(clientData, interp, argc, argv)
     ClientData clientData;
     Tcl_Interp *interp;	/* Current interpreter. */
     int argc;			/* Number of arguments. */
     char **argv;		/* Argument strings. */
{
  p2p_channel_t *chann;
  int port, chann_id;
  char buf[30];

  if (argc != 3) {
    return Tix_ArgcError(interp, 1, argv, 1, "port(integer) dst");
  }
  if (Tcl_GetInt(interp, argv[1], &port) != TCL_OK) {
    return TCL_ERROR;
  }
  chann = p2p_create_unicast_channel(port, argv[2]);
  chann_id = register_channel(chann);
  sprintf(buf, "%d", chann_id);
  Tcl_AppendResult(interp, buf, NULL);
  return TCL_OK;
}

int My_p2p_write(clientData, interp, argc, argv)
     ClientData clientData;
     Tcl_Interp *interp;	/* Current interpreter. */
     int argc;			/* Number of arguments. */
     char **argv;		/* Argument strings. */
{
  p2p_channel_t *chann;
  int chann_id;
  apr_status_t s;

  if (argc != 3) {
    return Tix_ArgcError(interp, 1, argv, 1, "chann(integer) str");
  }
  if (Tcl_GetInt(interp, argv[1], &chann_id) != TCL_OK) {
    return TCL_ERROR;
  }
  printf("My_p2p_write(): start\n");
  s = apr_thread_mutex_lock(chann_hash_mutex);
  if (s != APR_SUCCESS) {
    printf("My_p2p_write(): mutex lock failed!\n");
  }
  chann = apr_hash_get(chann_tbl, &chann_id, sizeof(int));
  s = apr_thread_mutex_unlock(chann_hash_mutex);
  if (s != APR_SUCCESS) {
    printf("My_p2p_write(): mutex unlock failed!\n");
  }
  p2p_write(chann, argv[2], strlen(argv[2]) + 1);
  printf("My_p2p_write(): end\n");
  return TCL_OK;
}

int My_p2p_read(clientData, interp, argc, argv)
     ClientData clientData;
     Tcl_Interp *interp;	/* Current interpreter. */
     int argc;			/* Number of arguments. */
     char **argv;		/* Argument strings. */
{
  p2p_channel_t *chann;
  int chann_id;
  char buf[2048];
  apr_status_t s;

  if (argc != 2) {
    return Tix_ArgcError(interp, 1, argv, 1, "chann(integer)");
  }
  if (Tcl_GetInt(interp, argv[1], &chann_id) != TCL_OK) {
    return TCL_ERROR;
  }
  printf("My_p2p_read(): start\n");
  s = apr_thread_mutex_lock(chann_hash_mutex);
  if (s != APR_SUCCESS) {
    printf("My_p2p_read(): mutex lock failed!\n");
  }
  chann = apr_hash_get(chann_tbl, &chann_id, sizeof(int));
  s = apr_thread_mutex_unlock(chann_hash_mutex);
  if (s != APR_SUCCESS) {
    printf("My_p2p_read(): mutex unlock failed!\n");
  }
  memset(buf, 0, 2048);
  printf("My_p2p_read(): channel is %s\n", chann->ready ? "ready" : "not ready");
  printf("My_p2p_read(): p2p_reading %d bytes...\n", chann->buflen);
  p2p_read(chann, buf, 2048);
  printf("My_p2p_read(): p2p_read done\n", chann->buflen);
  Tcl_AppendResult(interp, buf, NULL);
  printf("My_p2p_read(): end\n");
  return TCL_OK;
}

int My_p2p_close_channel(clientData, interp, argc, argv)
     ClientData clientData;
     Tcl_Interp *interp;	/* Current interpreter. */
     int argc;			/* Number of arguments. */
     char **argv;		/* Argument strings. */
{
  p2p_channel_t *chann;
  int chann_id;
  apr_status_t s;

  if (argc != 2) {
    return Tix_ArgcError(interp, 1, argv, 1, "chann(integer)");
  }
  if (Tcl_GetInt(interp, argv[1], &chann_id) != TCL_OK) {
    return TCL_ERROR;
  }
  s = apr_thread_mutex_lock(chann_hash_mutex);
  if (s != APR_SUCCESS) {
    printf("My_p2p_close_channel(): mutex lock failed!\n");
  }
  chann = apr_hash_get(chann_tbl, &chann_id, sizeof(int));
  s = apr_thread_mutex_unlock(chann_hash_mutex);
  if (s != APR_SUCCESS) {
    printf("My_p2p_close_channel(): mutex unlock failed!\n");
  }
  p2p_close_channel(chann);
  unregister_channel(chann_id);
  return TCL_OK;
}

int My_p2p_myuuid(clientData, interp, argc, argv)
     ClientData clientData;
     Tcl_Interp *interp;	/* Current interpreter. */
     int argc;			/* Number of arguments. */
     char **argv;		/* Argument strings. */
{
  char myuuid[P2P_UUID_FORMATTED_LENGTH + 1];

  if (argc != 1) {
    return Tix_ArgcError(interp, 1, argv, 1, "none");
  }
  p2p_uuid_format(myuuid, &uuid);
  Tcl_AppendResult(interp, myuuid, NULL);
  return TCL_OK;
}

int My_p2p_get_active_channel(clientData, interp, argc, argv)
     ClientData clientData;
     Tcl_Interp *interp;	/* Current interpreter. */
     int argc;			/* Number of arguments. */
     char **argv;		/* Argument strings. */
{
  int rval = -1;
  char buf[30];
  tix_channel_t *chann;
#if 1
  p2p_channel_t *p2p_chann;
  apr_status_t s;
#endif

  if (argc != 1) {
    return Tix_ArgcError(interp, 1, argv, 1, "none");
  }
  APR_RING_FOREACH(chann, &active_channels, tix_channel_s, link) {
#if 0
    rval = chann->chann_id;
    break;
#else
    s = apr_thread_mutex_lock(chann_hash_mutex);
    if (s != APR_SUCCESS) {
      printf("My_p2p_get_active_channel(): mutex lock failed!\n");
    }
    p2p_chann = apr_hash_get(chann_tbl, &(chann->chann_id), sizeof(int));
    s = apr_thread_mutex_unlock(chann_hash_mutex);
    if (s != APR_SUCCESS) {
      printf("My_p2p_get_active_channel(): mutex unlock failed!\n");
    }
    if (/*p2p_chann->ready*/1) {
      rval = chann->chann_id;
      printf("My_p2p_get_active_channel(): rval = %d, chan = 0x%08x\n", rval, p2p_chann);
      break;
    } else {
      continue;
    }
#endif
  }
  if (rval != -1) {
    s = apr_thread_mutex_lock(chann_hash_mutex);
    if (s != APR_SUCCESS) {
      printf("My_p2p_get_active_channel(): mutex lock failed!\n");
    }
    APR_RING_REMOVE(chann, link);
    s = apr_thread_mutex_unlock(chann_hash_mutex);
    if (s != APR_SUCCESS) {
      printf("My_p2p_get_active_channel(): mutex unlock failed!\n");
    }
  }
  sprintf(buf, "%d", rval);
  Tcl_AppendResult(interp, buf, NULL);
  return TCL_OK;
}
