./mytixwish im.tcl s settings.xml
