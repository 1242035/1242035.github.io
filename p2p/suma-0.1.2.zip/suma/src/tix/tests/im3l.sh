../mytixwish ../im.tcl f ../../../settings/s3.file s ../../../settings/settings3l.xml
