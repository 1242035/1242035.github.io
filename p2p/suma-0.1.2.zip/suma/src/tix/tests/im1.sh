../mytixwish ../im.tcl f ../../../settings/s1.file s ../../../settings/settings1.xml
