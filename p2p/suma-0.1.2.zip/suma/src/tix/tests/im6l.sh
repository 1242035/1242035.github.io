../mytixwish ../im.tcl f ../../../settings/s6.file s ../../../settings/settings6l.xml
