../mytixwish ../im.tcl f ../../../settings/s5.file s ../../../settings/settings5l.xml
