../mytixwish ../im.tcl f ../../../settings/s2.file s ../../../settings/settings2.xml
