../mytixwish ../im.tcl f ../../../settings/s4.file s ../../../settings/settings4l.xml
