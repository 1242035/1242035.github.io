
/*	$Id: myInit.c,v 1.1.1.1 2002/08/06 07:24:50 onioni Exp $	*/

/*
 * myInit.c --
 *
 *	Initialze the Tix demo application.
 *
 * Copyright (c) 1996, Expert Interface Technologies
 *
 * See the file "license.terms" for information on usage and redistribution
 * of this file, and for a DISCLAIMER OF ALL WARRANTIES.
 *
 */

#include <tk.h>
#include <tix.h>

#ifndef _Windows
#  ifndef _export
#  define _export
#  endif
#endif

extern TIX_DECLARE_CMD(My_p2p_init);
extern TIX_DECLARE_CMD(My_p2p_shutdown);
extern TIX_DECLARE_CMD(My_p2p_create_broadcast_channel);
extern TIX_DECLARE_CMD(My_p2p_create_multicast_channel);
extern TIX_DECLARE_CMD(My_p2p_create_unicast_channel);
extern TIX_DECLARE_CMD(My_p2p_write);
extern TIX_DECLARE_CMD(My_p2p_read);
extern TIX_DECLARE_CMD(My_p2p_close_channel);
extern TIX_DECLARE_CMD(My_p2p_myuuid);
extern TIX_DECLARE_CMD(My_p2p_get_active_channel);

#if 0
#ifndef MY_LIBRARY
#define MY_LIBRARY "./library"
#endif
#endif


static Tix_TclCmd commands[] = {
    {"p2p_init",		       	My_p2p_init},
    {"p2p_shutdown",			My_p2p_shutdown},
    {"p2p_create_broadcast_channel",	My_p2p_create_broadcast_channel},
    {"p2p_create_multicast_channel",	My_p2p_create_multicast_channel},
    {"p2p_create_unicast_channel",	My_p2p_create_unicast_channel},
    {"p2p_write",			My_p2p_write},
    {"p2p_read",			My_p2p_read},
    {"p2p_close_channel",		My_p2p_close_channel},
    {"p2p_myuuid",			My_p2p_myuuid},
    {"p2p_get_active_channel",		My_p2p_get_active_channel},

    /*
     * Make sure this list is terminated by a NULL element
     */
    {(char *) NULL,		(int (*)()) NULL}
};

/* My_Init --
 *
 * 	This is the function to call in your Tcl_AppInit() function. It
 *	creates the commands of this application that are defined by
 *	C functions.
 */
int _export
My_Init(interp)
    Tcl_Interp * interp;
{
    /* Initialize the Tix commands */
    Tix_CreateCommands(interp, commands, (ClientData) NULL,
	(void (*)()) NULL);

#if 0
    if (Tix_LoadTclLibrary(interp, "MY_LIBRARY", "my_library", 
	"Init.tcl", MY_LIBRARY, "myapp") != TCL_OK) {
	return TCL_ERROR;
    }
#endif

    return TCL_OK;
}
