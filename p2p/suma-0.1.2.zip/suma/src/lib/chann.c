#include <apr.h>
#include <apr_ring.h>
#include <apr_strings.h>
#include <apr_hash.h>
#include <apr_thread_cond.h>
#include <apr_thread_mutex.h>
#include "sumalib.h"
#include "internal.h"
#include "msg.h"
#include "cb.h"
#include "clusters.h"
#include "chann.h"
#include "routing.h"
#include "mystream.h"

extern unsigned int flags;
extern apr_pool_t *mypool;
extern int resolution;
p2p_channel_link_t channels;

void init_channels()
{
  APR_RING_INIT(&channels, p2p_channel_s, link);
}

p2p_channel_t *p2p_create_broadcast_channel(unsigned int service_port)
{
  p2p_channel_t *chann = (p2p_channel_t *)apr_pcalloc(mypool, sizeof(p2p_channel_t));

  chann->kind = P2P_KIND_BROAD;
  chann->port = service_port;
  apr_thread_mutex_create(&(chann->mutex), APR_THREAD_MUTEX_DEFAULT, mypool);
  apr_thread_cond_create(&(chann->cv), mypool);
  chann->dst = 0;
  APR_RING_INSERT_TAIL(&channels, chann, p2p_channel_s, link);
  return chann;
}

p2p_channel_t *p2p_create_multicast_channel(unsigned int service_port, p2p_destinations_t *dst)
{
  p2p_channel_t *chann = (p2p_channel_t *)apr_pcalloc(mypool, sizeof(p2p_channel_t));
  apr_status_t s;

  chann->kind = P2P_KIND_MULTI;
  chann->port = service_port;
  s = apr_thread_mutex_create(&(chann->mutex), APR_THREAD_MUTEX_DEFAULT, mypool);
  if (s != APR_SUCCESS) {
    p2p_log(P2P_LOG_ERROR, "mutex creation failed!\n");
    return 0;
  }
  s = apr_thread_cond_create(&(chann->cv), mypool);
  if (s != APR_SUCCESS) {
    p2p_log(P2P_LOG_ERROR, "cv creation failed!\n");
    return 0;
  }
  chann->dst = dst;
  APR_RING_INSERT_TAIL(&channels, chann, p2p_channel_s, link);
  return chann;
}

p2p_channel_t *p2p_create_unicast_channel(unsigned int service_port, char* dst_uuid)
{
  p2p_channel_t *chann = (p2p_channel_t *)apr_pcalloc(mypool, sizeof(p2p_channel_t));
  apr_status_t s;

  chann->kind = P2P_KIND_UNI;
  chann->port = service_port;
  s = apr_thread_mutex_create(&(chann->mutex), APR_THREAD_MUTEX_DEFAULT, mypool);
  if (s != APR_SUCCESS) {
    p2p_log(P2P_LOG_ERROR, "mutex creation failed!\n");
    return 0;
  }
  s = apr_thread_cond_create(&(chann->cv), mypool);
  if (s != APR_SUCCESS) {
    p2p_log(P2P_LOG_ERROR, "cv creation failed!\n");
    return 0;
  }
  chann->dst = (p2p_destinations_t *)
    apr_pcalloc(mypool, sizeof(p2p_destinations_t) +  (APR_UUID_FORMATTED_LENGTH + 1));
  chann->dst->n_dst = 1;
  apr_cpystrn(chann->dst->uuids[0], dst_uuid, APR_UUID_FORMATTED_LENGTH + 1);
  APR_RING_INSERT_TAIL(&channels, chann, p2p_channel_s, link);
  return chann;
} 

p2p_channel_t *create_channel_from_msg(char *buf)
{
  char *kind = ((p2p_msg_common_t *)buf)->kind;
  p2p_channel_t *chann;

  if (strncmp(kind, P2P_KIND_BROAD, strlen(P2P_KIND_BROAD)) == 0) {
    p2p_msg_broadcast_header_t *msg = (p2p_msg_broadcast_header_t *)buf;

    chann = p2p_create_broadcast_channel(msg->port);
  } else if (strncmp(kind, P2P_KIND_MULTI, strlen(P2P_KIND_MULTI)) == 0) {
    p2p_msg_multicast_header_t *msg = (p2p_msg_multicast_header_t *)buf;
    p2p_destinations_t *dst = (p2p_destinations_t *)
      apr_pcalloc(mypool, sizeof(p2p_destinations_t) + (APR_UUID_FORMATTED_LENGTH + 1) * msg->n_dst);
    int i;

    dst->n_dst = msg->n_dst;
    for (i = 0; i < msg->n_dst; i++) {
      apr_cpystrn(dst->uuids[i], msg->dst_uuids[i], APR_UUID_FORMATTED_LENGTH + 1);
    }
    chann = p2p_create_multicast_channel(msg->port, dst);
  } else if (strncmp(kind, P2P_KIND_UNI, strlen(P2P_KIND_UNI)) == 0) {
    p2p_msg_unicast_header_t *msg = (p2p_msg_unicast_header_t *)buf;

    chann = p2p_create_unicast_channel(msg->port, msg->dst_uuid);
  }
  return chann;
}

void signal_channel(p2p_channel_t *chann, char *body, int len)
{
  apr_status_t s;

  p2p_log(P2P_LOG_DEBUG, "signal_channel(): lock start for signal\n");
  s = apr_thread_mutex_lock(chann->mutex);
  if (s != APR_SUCCESS) {
    p2p_log(P2P_LOG_ERROR, "signal_channel(): mutex lock failed!\n");
    return;
  }
  p2p_log(P2P_LOG_DEBUG, "signal_channel(): lock end for signal\n");
  chann->buf = body;
  chann->buflen = len;
  chann->ready = 1;
  s = apr_thread_cond_signal(chann->cv);
  if (s != APR_SUCCESS) {
    p2p_log(P2P_LOG_ERROR, "signal_channel(): cv signal failed!\n");
    return;
  }
  s = apr_thread_mutex_unlock(chann->mutex);
  if (s != APR_SUCCESS) {
    p2p_log(P2P_LOG_ERROR, "signal_channel(): mutex unlock failed!\n");
    return;
  }
}

int p2p_write(p2p_channel_t *chann, char *body, int len)
{
  p2p_connection_link_t dst_conn_list;
  apr_size_t length;
  char *msg;

#if !defined(PROHIBIT_LOCAL_CONNECTION)
  if (
#if defined(XML_SETTINGS)
      settings.general_settings.is_listening == 0
#else
      !(flags & P2P_INIT_SERVER)
#endif	/* XML_SETTINGS */
      ) {
    apr_hash_t *cluster = get_cluster(adhoc_clusters, resolution);

    if (cluster != NULL) {
      apr_hash_index_t *i;
      p2p_connection_t *conn;

      APR_RING_INIT(&dst_conn_list, p2p_connection_s, link);
      for (i = apr_hash_first(mypool, cluster); i; i = apr_hash_next(i)) {
	apr_hash_this(i, NULL, NULL, (void **)&(conn));
	APR_RING_INSERT_TAIL(&dst_conn_list, conn, p2p_connection_s, link);
	break;
      }
    } else {
      p2p_log(P2P_LOG_DEBUG, "p2p_write(): cannot find adhoc cluster\n");
      return -1;
    }
  } else {
    select_connections(chann->kind, chann->dst, &dst_conn_list, 0);
  }
#else
  select_connections(chann->kind, chann->dst, &dst_conn_list, 0);
#endif	/* !PROHIBIT_LOCAL_CONNECTION */

  /* construct msg */
  msg = construct_msg(chann, body, len);
  length = ((p2p_msg_common_t *)msg)->length;

  p2p_log(P2P_LOG_DEBUG, "p2p_write(): kind = %s\n", ((p2p_msg_common_t *)msg)->kind);
  return send_msg_to_connections(&dst_conn_list, &length, msg);
}

int p2p_read(p2p_channel_t *chann, char *msg, int len)
{
  apr_status_t s;

  p2p_log(P2P_LOG_DEBUG, "p2p_read(): lock start for wait\n");
  s = apr_thread_mutex_lock(chann->mutex);
  if (s != APR_SUCCESS) {
    p2p_log(P2P_LOG_ERROR, "p2p_read(): mutex lock failed!\n");
    return -1;
  }
  p2p_log(P2P_LOG_DEBUG, "p2p_read(): lock end for wait\n");
  if (!chann->ready) {
    s = apr_thread_cond_wait(chann->cv, chann->mutex);
    if (s != APR_SUCCESS) {
      p2p_log(P2P_LOG_ERROR, "p2p_read(): cv wait failed!\n");
      return -1;
    }
  } else chann->ready = 0;
  memcpy(msg, chann->buf, chann->buflen);
  s = apr_thread_mutex_unlock(chann->mutex);
  if (s != APR_SUCCESS) {
    p2p_log(P2P_LOG_ERROR, "p2p_read(): mutex unlock failed!\n");
    return -1;
  }
  return strlen(msg);	/* FIXME: non-sence? */
}

int p2p_close_channel(p2p_channel_t *chann)
{
  /* FIXME: destroy channel */
  return 0;
}

void p2p_list_channels(mystream_t *mystream, char **argv, char *rest)
{
  p2p_channel_t *chann;

  APR_RING_FOREACH(chann, &channels, p2p_channel_s, link) {
    mystream_printf(mystream, "%s [port = %d]\n", chann->kind, chann->port);
    if (chann->dst != 0) {
      int i;

      for (i = 0; i < chann->dst->n_dst; i++) {
	mystream_printf(mystream, "\t%s\n", chann->dst->uuids[i]);
      }
    }
  }
}
