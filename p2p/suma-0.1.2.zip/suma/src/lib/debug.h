#if !defined(_DEBUG_H_)
#define _DEBUG_H_

#define DEBUG_PORT		90001

void join_debug_listener(apr_status_t *rval);
void init_debug(int port);

#endif	/* _DEBUG_H_ */
