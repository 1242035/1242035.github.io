/* TODO:
   o  status management of connections.
   o  eliminate memory leaks.
   o  enable logger to store logs in file.
*/
/* CHANGES:
   [02-06-18] added basic commands:
      o  p2p_list_connections
      o  p2p_list_channels
   [02-06-20] a relay station can decide his own port number.
   [02-07-23] storing uuid and entry points in file.
   [02-07-30] wan-lan bridging added.
   [02-08-08] dump_connection was moved to 'util.c'.
*/
#include <apr.h>
#include <apr_uuid.h>
#include <apr_pools.h>
#include <apr_thread_proc.h>
#include <apr_network_io.h>
#include <apr_getopt.h>
#include <apr_strings.h>
#include <apr_signal.h>
#include <stdlib.h>
#include <signal.h>
#include "sumalib.h"
#include "uuid.h"
#include "internal.h"
#include "msg.h"
#include "clusters.h"
#include "util.h"
#include "chann.h"
#include "cb.h"
#include "debug.h"
#if defined(XML_SETTINGS)
#include <apr_ring.h>
#include "settings.h"
#endif	/* XML_SETTINGS */

void p2p_uuid_format(char *buffer, const p2p_uuid_t *uuid) {
  apr_uuid_format(buffer, uuid);
}

unsigned int flags = 0;

p2p_uuid_t uuid;
apr_pool_t *mypool;
int myport = P2P_PORT;
unsigned long resolution = 0;
static apr_thread_t *listener;
#if !defined(XML_SETTINGS)
static char uuid_filename[2048];
#endif	/* !XML_SETTINGS */
static apr_socket_t *suma_sock;
int exit_flag = 0;

void * APR_THREAD_FUNC message_reader(apr_thread_t *t, void *data)
{
  p2p_connection_t *conn = (p2p_connection_t *)data;
  char *buf;
  char *kind;

  p2p_log(P2P_LOG_DEBUG, "message_reader(): start\n");
  while(1) {
    if (read_msg(conn->sock, &buf) == -1) {
#if !defined(PROHIBIT_LOCAL_CONNECTION)
      if (conn->is_local)
	remove_connection(adhoc_clusters, conn->r, conn);
      else
	remove_connection(basic_clusters, conn->r, conn);
#else
      remove_connection(basic_clusters, conn->r, conn);
#endif	/* !PROHIBIT_LOCAL_CONNECTION */
      /* FIXME: error handling is needed. */
      return (void *)0;
    }
    kind = ((p2p_msg_common_t *)buf)->kind;
#if !defined(PROHIBIT_LOCAL_CONNECTION)
    p2p_log(P2P_LOG_DEBUG, "message_reader(): got packet from %s (r = %d, is_local = %s), kind = %s\n",
	    conn->peer_uuid, conn->r, conn->is_local ? "true" : "false", kind);
    if (conn->is_local &&
#if defined(XML_SETTINGS)
	settings.general_settings.is_listening == 1
#else
	(flags & P2P_INIT_SERVER)
#endif	/* XML_SETTINGS */
	) {
      relay_local(buf);
    } else
#else
    p2p_log(P2P_LOG_DEBUG, "message_reader(): got packet from %s (r = %d), kind = %s\n",
	    conn->peer_uuid, conn->r, kind);
#endif	/* !PROHIBIT_LOCAL_CONNECTION */
    {
      if (strncmp(kind, P2P_KIND_HELLO1, strlen(P2P_KIND_HELLO1)) == 0) {
	process_hello1(conn, buf);
      } else if (strncmp(kind, P2P_KIND_REPLY1, strlen(P2P_KIND_REPLY1)) == 0) {
	process_reply1(conn, buf);
      } else if (strncmp(kind, P2P_KIND_HELLO2, strlen(P2P_KIND_HELLO2)) == 0) {
	process_hello2(conn, buf);
      } else if (strncmp(kind, P2P_KIND_BROAD, strlen(P2P_KIND_BROAD)) == 0) {
	process_broad(conn, buf);
      } else if (strncmp(kind, P2P_KIND_MULTI, strlen(P2P_KIND_MULTI)) == 0) {
	process_multi(conn, buf);
      } else if (strncmp(kind, P2P_KIND_UNI, strlen(P2P_KIND_UNI)) == 0) {
	process_uni(conn, buf);
      } else {
	p2p_log(P2P_LOG_ERROR, "message_reader(): illegal msg kind (%s)\n", kind);
	/* FIXME: error handling is needed. */
	return (void *)0;
      }
    }
#if !defined(PROHIBIT_LOCAL_CONNECTION)
    if (/*!(conn->is_local)*/1 &&
#if defined(XML_SETTINGS)
	settings.general_settings.is_listening == 1
#else
	(flags & P2P_INIT_SERVER)
#endif	/* XML_SETTINGS */
	&& ((strncmp(kind, P2P_KIND_BROAD, strlen(P2P_KIND_BROAD)) == 0)
	    || (strncmp(kind, P2P_KIND_MULTI, strlen(P2P_KIND_MULTI)) == 0)
	    || (strncmp(kind, P2P_KIND_UNI, strlen(P2P_KIND_UNI)) == 0))) {
      apr_hash_index_t *i, *j;
      apr_hash_t *cluster;
      p2p_connection_t *tmp;
      apr_status_t stat;
      char msgbuf[80];
      unsigned int length = ((p2p_msg_common_t *)buf)->length;

      p2p_log(P2P_LOG_DEBUG, "message_reader(): selecting connection for adhoc clusters ...\n");
      for (i = apr_hash_first(mypool, adhoc_clusters); i; i = apr_hash_next(i)) {
	apr_hash_this(i, NULL, NULL, (void **)&(cluster));
	for (j = apr_hash_first(mypool, cluster); j; j = apr_hash_next(j)) {
	  apr_hash_this(j, NULL, NULL, (void **)&(tmp));
	  p2p_log(P2P_LOG_DEBUG, "message_reader(): sending to local node %s ...\n", tmp->peer_uuid);
	  if (strncmp(tmp->peer_uuid, conn->peer_uuid, APR_UUID_FORMATTED_LENGTH) == 0) {
	    p2p_log(P2P_LOG_DEBUG, "message_reader(): skipped (sender equals receiver)\n");
	    continue;
	  }
	  if ((stat = apr_send(tmp->sock, buf, &length) != APR_SUCCESS)) {
	    apr_socket_close(tmp->sock);
	    remove_connection(adhoc_clusters, tmp->r, tmp);
	    p2p_log(P2P_LOG_ERROR, "Problem sending data: %s (%d)\n",
		    apr_strerror(stat, msgbuf, sizeof(msgbuf)), stat);
	    continue;
	  }
	  p2p_log(P2P_LOG_DEBUG, "message_reader(): done\n");
	}
      }
      p2p_log(P2P_LOG_DEBUG, "message_reader(): connection for adhoc clusters selected\n");
    }
#endif	/* !PROHIBIT_LOCAL_CONNECTION */
  }
  p2p_log(P2P_LOG_DEBUG, "message_reader(): end\n");
}

static void * APR_THREAD_FUNC connection_listener(apr_thread_t *t, void *data)
{
  apr_socket_t *accepted_sock;
  apr_sockaddr_t *localsa;
  p2p_connection_t *conn;
  apr_threadattr_t *attr;

  p2p_log(P2P_LOG_DEBUG, "connection_listener(): creating socket (port = %d)\n", myport);
  apr_socket_create(&suma_sock, AF_INET, SOCK_STREAM, mypool);
  apr_socket_addr_get(&localsa, APR_LOCAL, suma_sock);
  apr_sockaddr_port_set(localsa, myport);
  apr_bind(suma_sock, localsa);
  p2p_log(P2P_LOG_DEBUG, "connection_listener(): dumping listening socket\n");
  dump_connection(suma_sock);
  apr_listen(suma_sock, 5);
  while (1) {
    apr_accept(&accepted_sock, suma_sock, mypool);
    if (exit_flag)
      break;
    p2p_log(P2P_LOG_DEBUG, "connection_listener(): accepted\n");
    dump_connection(accepted_sock);
    conn = (p2p_connection_t *)apr_pcalloc(mypool, sizeof(p2p_connection_t));
    conn->sock = accepted_sock;
    apr_threadattr_create(&attr, mypool);
    apr_thread_create(&(conn->reader), attr, message_reader, (void *)conn, mypool);
  }
  apr_socket_close(suma_sock);
  p2p_log(P2P_LOG_DEBUG, "connection_listener(): end\n");
  return (void *)0;
}

void sig_handler(int signo)
{
  if (exit_flag == 1)
    return;
  p2p_log(P2P_LOG_DEBUG, "sig_handler(): called\n");
  exit_flag = 1;
  apr_socket_close(suma_sock);
  p2p_shutdown();
  exit(-1);
}

int p2p_init(int argc, char *argv[], char *entry_points_ip_addrs[])
{
  apr_getopt_t *opt;
  const char *optarg;
  char optchar;
  apr_status_t rval;
  apr_threadattr_t *attr;
#if defined(XML_SETTINGS)
  char xml_settings_filename[2048];
#else
  char eps_filename[2048];	/* file name for entry points */
#endif	/* XML_SETTINGS */

  apr_initialize();
  apr_pool_initialize();
  apr_pool_create(&mypool, 0);
  apr_signal_init(mypool);
#if !defined(WIN32)
  apr_signal(SIGHUP, sig_handler);
#endif
  apr_signal(SIGTERM, sig_handler);
  apr_signal(SIGINT, sig_handler);
  init_clusters(&basic_clusters);
#if !defined(PROHIBIT_LOCAL_CONNECTION)
  init_clusters(&adhoc_clusters);
#endif	/* !PROHIBIT_LOCAL_CONNECTION */
  init_channels();
  init_callbacks();
  apr_getopt_init(&opt, mypool, argc, (const char **)argv);
#if defined(XML_SETTINGS)
#define XML_SETTINGS_FILENAME	"settings.xml"
  apr_cpystrn(xml_settings_filename, XML_SETTINGS_FILENAME, strlen(XML_SETTINGS_FILENAME) + 1);
#else
  apr_cpystrn(uuid_filename, UUID_FILENAME, strlen(UUID_FILENAME) + 1);
  apr_cpystrn(eps_filename, EPS_FILENAME, strlen(EPS_FILENAME) + 1);
#endif	/* XML_SETTINGS */
  while ((rval = apr_getopt(opt,
#if defined(XML_SETTINGS)
			    "s:",
#else
			    "csp:u:e:",
#endif	/* XML_SETTINGS */
			    &optchar, &optarg)) == APR_SUCCESS) {
    switch (optchar) {
#if defined(XML_SETTINGS)
    case 's':
      apr_cpystrn(xml_settings_filename, optarg, strlen(optarg) + 1);
      p2p_log(P2P_LOG_INFO, "xml settings file = %s\n", xml_settings_filename);
      break;
#else
    case 'c':
      flags |= P2P_INIT_CLIENT;
      break;
    case 's':
      flags |= P2P_INIT_SERVER;
      break;
    case 'p':
      p2p_log(P2P_LOG_INFO, "port = %d\n", myport = atoi(optarg));
      break;
    case 'u':
      apr_cpystrn(uuid_filename, optarg, strlen(optarg) + 1);
      p2p_log(P2P_LOG_INFO, "uuid file = %s\n", uuid_filename);
      break;
    case 'e':
      apr_cpystrn(eps_filename, optarg, strlen(optarg) + 1);
      p2p_log(P2P_LOG_INFO, "entry points file = %s\n", eps_filename);
      break;
#endif	/* XML_SETTINGS */
    }
  }
#if defined(XML_SETTINGS)
  init_settings(xml_settings_filename);
  p2p_log(P2P_LOG_INFO, "port = %d\n", myport = settings.general_settings.basic_port);
  if (settings.general_settings.uuid == 0) {
    apr_uuid_get(&uuid);
    set_uuid_slot(&uuid);
  } else {
    apr_uuid_parse(&uuid, settings.general_settings.uuid);
  }
  if (settings.general_settings.is_listening == 1) {
    apr_threadattr_create(&attr, mypool);
    apr_thread_create(&listener, attr, connection_listener, 0, mypool);
    p2p_register_response_callback(SUMA_CORE_PORT, reply1_cb);
  }
  if (settings.debug_settings.is_listening == 1)
    init_debug(settings.debug_settings.debug_port);
  {
    int c = 0;
    str_elem_t *tmp;

    APR_RING_FOREACH(tmp, &settings.general_settings.entry_points, str_elem_s, link) c++;
    if (c > 0)
      establish_basic_connection(&settings.general_settings.entry_points);
  }
#else
  set_uuid(uuid_filename);
  if (flags & P2P_INIT_SERVER) {
    apr_threadattr_create(&attr, mypool);
    apr_thread_create(&listener, attr, connection_listener, 0, mypool);
    init_debug(DEBUG_PORT);
    p2p_register_response_callback(SUMA_CORE_PORT, reply1_cb);
  }
  if (flags & P2P_INIT_CLIENT) {
    if (entry_points_ip_addrs[0] == 0) {
      char **eps = read_eps_from_file(eps_filename);

      if (eps == 0) {
	p2p_log(P2P_LOG_ERROR, "no entry points\n");
	exit(-1);
      }
      establish_basic_connection(eps);
    } else
      establish_basic_connection(entry_points_ip_addrs);
  }
#endif	/* XML_SETTINGS */
  return 0;
}

int p2p_shutdown()
{
  apr_status_t rval;

  p2p_log(P2P_LOG_DEBUG, "p2p_shutdown(): start\n");
  if (
#if defined(XML_SETTINGS)
      settings.general_settings.is_listening == 1
#else
      flags & P2P_INIT_SERVER
#endif	/* XML_SETTINGS */
      ) {
    p2p_log(P2P_LOG_DEBUG, "p2p_shutdown(): join connection_listener start\n");
    apr_thread_join(&rval, listener);
    p2p_log(P2P_LOG_DEBUG, "p2p_shutdown(): join connection_listener end\n");
  }
  if (
#if defined(XML_SETTINGS)
      settings.debug_settings.is_listening == 1
#else
      flags & P2P_INIT_SERVER
#endif	/* XML_SETTINGS */
      )
    join_debug_listener(&rval);
  /* FIXME: excute shutdown handlers */
  /* FIXME: send BYE msg to all connections */
  /* FIXME: destroy all channels */
  /* FIXME: destroy all connections */
  remove_all_connections(basic_clusters);
  remove_all_connections(adhoc_clusters);
  /* FIXME: stop all threads */
  apr_pool_terminate();
  apr_terminate();
  p2p_log(P2P_LOG_DEBUG, "p2p_shutdown(): end\n");
  return 0;
}
