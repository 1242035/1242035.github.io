#if !defined(_CHANN_H_)
#define _CHANN_H_

#include <apr_thread_proc.h>
#include <apr_thread_cond.h>
#include <apr_thread_mutex.h>

typedef struct p2p_channel_link_s p2p_channel_link_t;
struct p2p_channel_link_s {
  p2p_channel_t *prev;
  p2p_channel_t *next;
};

struct p2p_channel_s {
  char *kind;
  unsigned int port;
  apr_thread_mutex_t *mutex;
  apr_thread_cond_t *cv;
  apr_thread_t *thread;		/* FIXME: useless? */
  p2p_destinations_t *dst;
  char *buf;
  int buflen;
  int ready;
  int done;
  p2p_channel_link_t link;
};

extern p2p_channel_link_t channels;
void init_channels();
void signal_channel(p2p_channel_t *chann, char *body, int len);
p2p_channel_t *create_channel_from_msg(char *buf);

#endif	/* _CHANN_H_ */
