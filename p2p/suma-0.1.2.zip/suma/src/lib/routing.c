#include <apr.h>
#include <apr_ring.h>
#include <apr_network_io.h>
#include <apr_uuid.h>
#include <apr_hash.h>
#include <apr_strings.h>
#include <openssl/bn.h>
#include "internal.h"
#include "sumalib.h"
#include "uuid.h"
#include "clusters.h"
#include "msg.h"

extern apr_pool_t *mypool;
extern unsigned long resolution;

static int heq(char *idstr1, char *idstr2, unsigned long r)
{
  p2p_uuid_t uuid1, uuid2;
  BIGNUM bn1, bn2;
  unsigned long x1, y1, x2, y2;

  apr_uuid_parse(&uuid1, idstr1);
  apr_uuid_parse(&uuid2, idstr2);
  BN_init(&bn1);
  BN_init(&bn2);
  BN_bin2bn((unsigned char *)&uuid1, UUID_LENGTH, &bn1);
  BN_bin2bn((unsigned char *)&uuid2, UUID_LENGTH, &bn2);
  p2p_hash(bn1, r, &x1, &y1);
  p2p_hash(bn2, r, &x2, &y2);
  p2p_log(P2P_LOG_DEBUG, "heq(): id1 = %s -> (%d,%d) at r=%d\n", idstr1, x1, y1, r);
  p2p_log(P2P_LOG_DEBUG, "heq(): id2 = %s -> (%d,%d) at r=%d\n", idstr2, x2, y2, r);
  return (x1 == x2 && y1 == y2);
}

static int neighbor_heq(char *target_uuid, unsigned long r, p2p_connection_t **conn)
{
  apr_hash_t *cluster;

  p2p_log(P2P_LOG_DEBUG, "neighbor_heq(): start with r=%d\n", r);
  if ((cluster = get_cluster(basic_clusters, r)) != NULL) {
    apr_hash_index_t *i;
    p2p_connection_t *cc;

    p2p_log(P2P_LOG_DEBUG, "neighbor_heq(): cluster = 0x%08x\n", cluster);
    for (i = apr_hash_first(mypool, cluster); i; i = apr_hash_next(i)) {
      apr_hash_this(i, NULL, NULL, (void **)&(cc));
      if (heq(cc->peer_uuid, target_uuid, r)) {
	*conn = cc;
	p2p_log(P2P_LOG_DEBUG, "neighbor_heq(): found another member (%s)\n", (*conn)->peer_uuid);
	return 0;
      }
    }
  }
  *conn = NULL;
  p2p_log(P2P_LOG_DEBUG, "neighbor_heq(): i am the neighbor\n");
  return 1;
}

static int find_tunnel(unsigned long r, p2p_connection_t **conn)
{
  apr_hash_t *cluster;

  p2p_log(P2P_LOG_DEBUG, "find_tunnel(): start with r=%d\n", r);
  *conn = NULL;
  if ((cluster = get_cluster(basic_clusters, r)) != 0) {
    apr_hash_index_t *i;
    p2p_connection_t *cc;

    for (i = apr_hash_first(mypool, cluster); i; i = apr_hash_next(i)) {
      apr_hash_this(i, NULL, NULL, (void **)&(cc));
      if (cc->is_tunnel) {
	*conn = cc;
	p2p_log(P2P_LOG_DEBUG, "find_tunnel(): found at another member (%s)\n", (*conn)->peer_uuid);
	return 0;
      }
    }
  }
  p2p_log(P2P_LOG_DEBUG, "find_tunnel(): i am tunnel\n");
  return 1;
}

#if 1
static int neighbor_exactly_eq(char *dst_uuid, int r, p2p_connection_t **conn)
{
  apr_hash_t *cluster;

  p2p_log(P2P_LOG_DEBUG, "neighbor_exactly_eq(): start with r=%d\n", r);
  *conn = NULL;
  if ((cluster = get_cluster(basic_clusters, r)) != NULL) {
    apr_hash_index_t *i;
    p2p_connection_t *cc;

    p2p_log(P2P_LOG_DEBUG, "neighbor_exactly_eq(): cluster = 0x%08x\n", cluster);
    for (i = apr_hash_first(mypool, cluster); i; i = apr_hash_next(i)) {
      apr_hash_this(i, NULL, NULL, (void **)&(cc));
      if (strncmp(cc->peer_uuid, dst_uuid, APR_UUID_FORMATTED_LENGTH) == 0) {
	*conn = cc;
	p2p_log(P2P_LOG_DEBUG, "neighbor_exactly_eq(): found another member (%s)\n", (*conn)->peer_uuid);
	return 1;
      }
    }
  }
  p2p_log(P2P_LOG_DEBUG, "neighbor_exactly_eq(): no neighbor\n");
  return 0;
}
#endif

int find_neighbor(char *newbee_uuid, int *r, p2p_connection_t **conn)
{
/*
let rec find_neighbor n1 n2 (r:int) =
  if (heq n1 n2 r) = true then (
    match (n1#neighbor_heq n2 (r + 1)) with
      None -> (n1, r + 1)
    | Some (n3) -> find_neighbor n3 n2 (r + 1)
  ) else (
    if (heq n1 n2 (r - 1)) = false then (
      find_neighbor (n1#find_tunnel ~low:(r - 1) ~heigh:r) n2 (r - 1)
    ) else
      match (n1#neighbor_heq n2 r) with
        None -> (n1, r)
      | Some (n3) -> find_neighbor n3 n2 r
  )
*/
  char my_uuid[APR_UUID_FORMATTED_LENGTH + 1];

  p2p_log(P2P_LOG_DEBUG, "find_neighbor(): start with r=%d\n", *r);
  apr_uuid_format(my_uuid, &uuid);
  if (heq(my_uuid, newbee_uuid, *r)) {
    *r = *r + 1;
    if (neighbor_heq(newbee_uuid, *r, conn)) {
      p2p_log(P2P_LOG_DEBUG, "find_neighbor(): case1\n");
      return find_neighbor(newbee_uuid, r, conn);
    }
    if (conn != NULL) {
      p2p_log(P2P_LOG_DEBUG, "find_neighbor(): case2 (delegate to a node in cluster)\n");
    } else {
      p2p_log(P2P_LOG_DEBUG, "find_neighbor(): case3 (i am the neighbor)\n");
    }
  } else if (heq(my_uuid, newbee_uuid, *r - 1)) {
    p2p_log(P2P_LOG_DEBUG, "find_neighbor(): case4\n");
    neighbor_heq(newbee_uuid, *r, conn);
    if (conn == NULL) {
      p2p_log(P2P_LOG_ERROR, "find_neighbor(): cannot be occurred\n");
    }
  } else {
    *r = *r - 1;
    if (find_tunnel(*r, conn)) {
      p2p_log(P2P_LOG_DEBUG, "find_neighbor(): case5 (i am the tunnel)\n");
      return find_neighbor(newbee_uuid, r, conn);
    }
    p2p_log(P2P_LOG_DEBUG, "find_neighbor(): case6 (delegate to a tunnel in cluster)\n");
  }
  p2p_log(P2P_LOG_DEBUG, "find_neighbor(): end with r=%d, selected peer = %s\n", *r,
	  *conn == NULL ? "none" : (*conn)->peer_uuid);
  return 0;
}

void select_broad_connections_aux
(p2p_destinations_t *dst, p2p_connection_link_t *lst, p2p_connection_t *ex_conn)
{
#if 0
  /* send msg to all connections */
  p2p_connection_t *conn, *cpy;
  apr_hash_index_t *i;
  apr_hash_t *cluster;

  APR_RING_INIT(lst, p2p_connection_s, link);
  cluster = get_cluster(0);
  for (i = apr_hash_first(mypool, cluster); i; i = apr_hash_next(i)) {
    apr_hash_this(i, NULL, NULL, (void **)&(conn));
    if (conn != ex_conn) {
      cpy = (p2p_connection_t *)apr_pcalloc(mypool, sizeof(p2p_connection_t));
      cpy->sock = conn->sock;
      APR_RING_INSERT_TAIL(lst, cpy, p2p_connection_s, link);
    }
  }
#else
  /* relay */
  p2p_connection_t *conn, *cpy;
  apr_hash_index_t *i, *j;
  apr_hash_t *cluster;
  int r;
  int *rptr = &r;

  p2p_log(P2P_LOG_DEBUG, "select_broad_connections_aux(): start\n");
  APR_RING_INIT(lst, p2p_connection_s, link);
  for (i = apr_hash_first(mypool, basic_clusters); i; i = apr_hash_next(i)) {
    apr_hash_this(i, (void *)&rptr, NULL, (void **)&(cluster));
    if (ex_conn != 0) {
      if (*rptr == ex_conn->r)
	continue;
      if (ex_conn->r == -1)
	continue;
      for (j = apr_hash_first(mypool, cluster); j; j = apr_hash_next(j)) {
	apr_hash_this(j, NULL, NULL, (void **)&(conn));
	if (conn != ex_conn) {
	  cpy = (p2p_connection_t *)apr_pcalloc(mypool, sizeof(p2p_connection_t));
	  cpy->sock = conn->sock;
	  APR_RING_INSERT_TAIL(lst, cpy, p2p_connection_s, link);
	  p2p_log(P2P_LOG_DEBUG, "select_broad_connections_aux():   %s added\n", conn->peer_uuid);
	}
      }
    } else {
      for (j = apr_hash_first(mypool, cluster); j; j = apr_hash_next(j)) {
	apr_hash_this(j, NULL, NULL, (void **)&(conn));
	cpy = (p2p_connection_t *)apr_pcalloc(mypool, sizeof(p2p_connection_t));
	cpy->sock = conn->sock;
	APR_RING_INSERT_TAIL(lst, cpy, p2p_connection_s, link);
	p2p_log(P2P_LOG_DEBUG, "select_broad_connections_aux():   %s added\n", conn->peer_uuid);
      }
    }
  }
  p2p_log(P2P_LOG_DEBUG, "select_broad_connections_aux(): end\n");
#endif
}

void select_broad_connections
(p2p_destinations_t *dst, p2p_connection_link_t *lst, p2p_connection_t *ex_conn)
{
  select_broad_connections_aux(dst, lst, ex_conn);
}

int find_node(char *dst_uuid, int *r, p2p_connection_t **conn)
{
/*
let rec find_node n1 n2 (r:int) =
  if (heq n1 n2 r) = true then (
    match (n1#neighbor_heq n2 (r + 1)) with
      None -> None
    | Some (n3) -> find_node n3 n2 (r + 1);
  ) else (
    if (heq n1 n2 (r - 1)) = false then (
      find_node (n1#find_tunnel ~low:(r - 1) ~heigh:r) n2 (r - 1)
    ) else
       if n1 = n2 then Some (n1)
       else
         match (n1#neighbor_heq n2 r) with
           None -> None
         | Some (n3) -> find_node n3 n2 r
   )
*/
  char my_uuid[APR_UUID_FORMATTED_LENGTH + 1];

  p2p_log(P2P_LOG_DEBUG, "find_node(): start with r=%d\n", *r);
  apr_uuid_format(my_uuid, &uuid);
  if (strncmp(my_uuid, dst_uuid, APR_UUID_FORMATTED_LENGTH) == 0) {
    p2p_log(P2P_LOG_DEBUG, "find_node(): case1 (i am the destination. so, nothing to be done)\n", *r);
    *conn = NULL;
    return 0;
  }
  if (heq(my_uuid, dst_uuid, *r)) {
    *r = *r + 1;
    if (neighbor_heq(dst_uuid, *r, conn)) {
      p2p_log(P2P_LOG_DEBUG, "find_node(): case2\n");
      return find_node(dst_uuid, r, conn);
    }
    if (conn != NULL) {
      p2p_log(P2P_LOG_DEBUG, "find_neighbor(): case3 (send to a node in cluster)\n");
    } else {
      p2p_log(P2P_LOG_DEBUG, "find_neighbor(): case4 (must not occurred)\n");
    }
  } else if (heq(my_uuid, dst_uuid, *r - 1)) {
    p2p_log(P2P_LOG_DEBUG, "find_node(): case5\n");
#if 0
    if (neighbor_exactly_eq(dst_uuid, *r, conn)) {
      return 0;
    }
#endif
    neighbor_heq(dst_uuid, *r, conn);
  } else {
#if 0
    *r = *r - 1;
#else
    apr_hash_t *cluster;
    int r_orig = *r - 1;

    for (*r = *r - 1; (cluster = get_cluster(basic_clusters, *r)) == 0 && *r < resolution; (*r)++);
#endif
#if 1
    if (neighbor_exactly_eq(dst_uuid, *r, conn)) {
      return 0;
    }
#endif
    if (find_tunnel(*r, conn)) {
#if 1
      *r = r_orig;
#endif
      p2p_log(P2P_LOG_DEBUG, "find_node(): case6\n");
      return find_node(dst_uuid, r, conn);
    }
    p2p_log(P2P_LOG_DEBUG, "find_node(): case7 (send to a tunnel in cluster)\n");
  }
  p2p_log(P2P_LOG_DEBUG, "find_node(): end with r=%d, selected peer = %s\n", *r,
	  *conn == NULL ? "none" : (*conn)->peer_uuid);
  return 0;
}

void select_uni_connections(p2p_destinations_t *dst, int i, apr_socket_t **selected_sock, char **selected_uuid)
{
  p2p_connection_t *conn;
  int r;	/* resolution */

  r = resolution;
  find_node(dst->uuids[i], &r, &conn);
  if (conn == NULL) {
    *selected_uuid = NULL;
    *selected_sock = NULL;
  } else {
    *selected_uuid = conn->peer_uuid;
    *selected_sock = conn->sock;
  }
}

static int not_contained_in(char *tmp_uuid, p2p_connection_link_t *lst)
{
  p2p_connection_t *tmp;

  APR_RING_FOREACH(tmp, lst, p2p_connection_s, link) {
    if (strncmp(tmp_uuid, tmp->peer_uuid, APR_UUID_FORMATTED_LENGTH) == 0)
      return 0;
  }
  return 1;
}

static int not_bounce(char *selected_uuid, p2p_connection_t *ex_conn)
{
  if (ex_conn == 0)
    return 1;
  return strncmp(selected_uuid, ex_conn->peer_uuid, APR_UUID_FORMATTED_LENGTH) != 0;
}

void select_connections(char *kind, p2p_destinations_t *dst, p2p_connection_link_t *lst,
			p2p_connection_t *ex_conn)
{
  if (strncmp(kind, P2P_KIND_BROAD, strlen(P2P_KIND_BROAD)) == 0) {
    if (ex_conn == 0)	/* original sender */
      select_broad_connections(dst, lst, ex_conn);
    else		/* relay */
      select_broad_connections_aux(dst, lst, ex_conn);
  } else if (strncmp(kind, P2P_KIND_MULTI, strlen(P2P_KIND_MULTI)) == 0
	     /* select closest connection for each destination and send msg */
	     || strncmp(kind, P2P_KIND_UNI, strlen(P2P_KIND_UNI)) == 0
	     /* select closest connection for the destination and send msg */) {
    int i;
    p2p_connection_t *cpy, *tmp;
    char *selected_uuid = 0;
    apr_socket_t *selected_sock;

    APR_RING_INIT(lst, p2p_connection_s, link);
    p2p_log(P2P_LOG_DEBUG, "select_connections(): dst->n_dst = %d\n", dst->n_dst);
    for (i = 0; i < dst->n_dst; i++) {
      select_uni_connections(dst, i, &selected_sock, &selected_uuid);
      if (selected_uuid != 0 && not_contained_in(selected_uuid, lst) && not_bounce(selected_uuid, ex_conn)) {
	cpy = (p2p_connection_t *)apr_pcalloc(mypool, sizeof(p2p_connection_t));
	apr_cpystrn(cpy->peer_uuid, selected_uuid, APR_UUID_FORMATTED_LENGTH + 1);
	cpy->sock = selected_sock;
	APR_RING_INSERT_TAIL(lst, cpy, p2p_connection_s, link);
      }
    }
    p2p_log(P2P_LOG_DEBUG, "select_connections(): result start\n");
    APR_RING_FOREACH(tmp, lst, p2p_connection_s, link) {
      p2p_log(P2P_LOG_DEBUG, "select_connections():   %s\n", tmp->peer_uuid);
    }
    p2p_log(P2P_LOG_DEBUG, "select_connections(): result end\n");
  }
}
