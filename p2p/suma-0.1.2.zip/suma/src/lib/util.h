#if !defined(_UTIL_H_)
#define _UTIL_H_

#define EPS_FILENAME	"eps.file"

int read_msg(apr_socket_t *sock, char **buf);
void split_ipaddr_string(char *str, char **ip_addr, int *port, int default_port);
char **read_eps_from_file(char *eps_filename);
void dump_connection(apr_socket_t *sock);

#endif	/* _UTIL_H_ */

