#if !defined(_CB_H_)
#define _CB_H_

#include "internal.h"

typedef struct p2p_callback_s p2p_callback_t;

typedef struct p2p_callback_link_s p2p_callback_link_t;
struct p2p_callback_link_s {
  p2p_callback_t *prev;
  p2p_callback_t *next;
};

struct p2p_callback_s {
  int port;
  int (*handler)(p2p_channel_t *);
  p2p_callback_link_t link;
};

void init_callbacks();

#endif	/* _CB_H_ */
