#include <apr.h>
#include <apr_ring.h>
#include "cb.h"
#include "msg.h"
#include "chann.h"

apr_pool_t *mypool;
static p2p_callback_link_t response_callbacks;
static p2p_callback_link_t shutdown_callbacks;

void init_callbacks()
{
  APR_RING_INIT(&response_callbacks, p2p_callback_s, link);
  APR_RING_INIT(&shutdown_callbacks, p2p_callback_s, link);
}

int p2p_register_response_callback(int service_port, int (*handler)(p2p_channel_t *))
{
  p2p_callback_t *cb = (p2p_callback_t *)apr_pcalloc(mypool, sizeof(p2p_callback_t));
  cb->port = service_port;
  cb->handler = handler;
  APR_RING_INSERT_TAIL(&response_callbacks, cb, p2p_callback_s, link);
  return 0;
}

int p2p_register_shutdown_callback(int service_port,
				   int (*handler)(p2p_channel_t *)	/* channel might be null */
				   )
{
  p2p_callback_t *cb = (p2p_callback_t *)apr_pcalloc(mypool, sizeof(p2p_callback_t));
  cb->port = service_port;
  cb->handler = handler;
  APR_RING_INSERT_TAIL(&shutdown_callbacks, cb, p2p_callback_s, link);
  return 0;
} 

typedef struct {
  int (*handler)(p2p_channel_t *);
  p2p_channel_t *channel;
} p2p_cb_context_t;

static void * APR_THREAD_FUNC cb_executor(apr_thread_t *t, void *data)
{
  p2p_cb_context_t *ctx = (p2p_cb_context_t *)data;

  (ctx->handler)(ctx->channel);
  return (void *)0;
}

static int contain_dst(p2p_destinations_t *dst, char *uuidstr)
{
  int i, found = 0;

  if (dst == 0) {
    return 1;
  } else {
    for (i = 0; i < dst->n_dst; i++) {
      if (strncmp(uuidstr, dst->uuids[i], APR_UUID_FORMATTED_LENGTH) == 0) {
	found = 1;
      }
    }
    return found;
  }
}

void exec_callback(p2p_msg_common_t *header, int port, char *body)
{
  p2p_callback_t *cb = 0, *tmp_cb;
  p2p_channel_t *chann = 0, *tmp_chann;
  int len;

  p2p_log(P2P_LOG_DEBUG, "exec_callback(): start with port = %d\n", port);
  len = header->length - sizeof(p2p_msg_common_t);
  APR_RING_FOREACH(tmp_cb, &response_callbacks, p2p_callback_s, link) {
    if (tmp_cb->port == port) {
      cb = tmp_cb;
      break;
    }
  }
  APR_RING_FOREACH(tmp_chann, &channels, p2p_channel_s, link) {
    if (tmp_chann->done == 0 &&	tmp_chann->port == port
	&& contain_dst(tmp_chann->dst, header->src_uuid)) {
      chann = tmp_chann;
      chann->done = 1;
      break;
    }
  }
  if (cb == 0 && chann == 0) {
    p2p_log(P2P_LOG_DEBUG, "exec_callback(): no cb, no chann\n");
  }
  if (cb == 0 && chann != 0) {
    p2p_log(P2P_LOG_DEBUG, "exec_callback(): no cb, some chann\n");
    signal_channel(chann, body, len);
  }
  if (cb != 0 && chann == 0) {
    p2p_log(P2P_LOG_DEBUG, "exec_callback(): some cb, no chann\n");
    chann = create_channel_from_msg((char *)header);
  }
  if (cb != 0 && chann != 0) {
    p2p_cb_context_t *ctx = (p2p_cb_context_t *)apr_pcalloc(mypool, sizeof(p2p_cb_context_t));
    apr_threadattr_t *attr;

    p2p_log(P2P_LOG_DEBUG, "exec_callback(): some cb, some chann\n");
    ctx->handler = cb->handler;
    ctx->channel = chann;
    apr_threadattr_create(&attr, mypool);
    apr_thread_create(&(chann->thread), attr, cb_executor, (void *)ctx, mypool);
    signal_channel(chann, body, len);
  }
}

