#if !defined(_RELAY_H_)
#define _RELAY_H_

#include "sumalib.h"
#include "internal.h"

int find_neighbor(char *newbee_uuid, int *r, p2p_connection_t **conn);

void select_broad_connections_aux
(p2p_destinations_t *dst, p2p_connection_link_t *lst, p2p_connection_t *ex_conn);

void select_broad_connections
(p2p_destinations_t *dst, p2p_connection_link_t *lst, p2p_connection_t *ex_conn);

void select_uni_connections
(p2p_destinations_t *dst, int i, apr_socket_t **closer_sock, char **closer_uuid);

void select_connections(char *kind, p2p_destinations_t *dst, p2p_connection_link_t *lst,
			p2p_connection_t *ex_conn);

#endif	/* _RELAY_H_ */
