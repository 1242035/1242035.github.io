#include <apr.h>
#include <apr_hash.h>
#include <apr_strings.h>
#include <apr_network_io.h>
#include <apr_ring.h>
#include "internal.h"
#include "sumalib.h"
#include "clusters.h"
#include "mystream.h"

#if defined(CLUSTERS_TEST)
/* -------------------- stubs start -------------------- */
#include <stdarg.h>
#define P2P_LOG_ERROR		1
#define P2P_LOG_INFO		2
#define P2P_LOG_DEBUG		3
void p2p_log(int level, char *fmt, ...)
{
  char str[2048];
  va_list ap;

  va_start(ap, fmt);
  vsnprintf(str, 2048, fmt, ap);
  va_end(ap);
  printf("%s", str);
}
static apr_pool_t *mypool;
apr_uuid_t uuid;
/* -------------------- stubs end   -------------------- */
#else
extern apr_pool_t *mypool;
#endif	/* CLUSTERS_TEST */

apr_hash_t *basic_clusters;
#if !defined(PROHIBIT_LOCAL_CONNECTION)
apr_hash_t *adhoc_clusters;
#endif	/* !PROHIBIT_LOCAL_CONNECTION */

void init_clusters(apr_hash_t **clusters)
{
  *clusters = apr_hash_make(mypool);
}

apr_hash_t *get_cluster(apr_hash_t *clusters, unsigned long r)
{
  return (apr_hash_t *)apr_hash_get(clusters, &r, sizeof(unsigned long));
}

static void add_cluster(apr_hash_t *clusters, unsigned long r)
{
  apr_hash_t *cluster = get_cluster(clusters, r);

  if (cluster == NULL) {
    unsigned long *tmp = (unsigned long *)apr_pcalloc(mypool, sizeof(unsigned long));

    memcpy(tmp, &r, sizeof(unsigned long));
    cluster = apr_hash_make(mypool);
    apr_hash_set(clusters, tmp, sizeof(unsigned long), cluster);
  }
}

static void remove_cluster(apr_hash_t *clusters, unsigned long r)
{
  unsigned long *tmp = (unsigned long *)apr_pcalloc(mypool, sizeof(unsigned long));

  memcpy(tmp, &r, sizeof(unsigned long));
  apr_hash_set(clusters, tmp, sizeof(unsigned long), NULL);
}

p2p_connection_t *get_connection(apr_hash_t *clusters, unsigned long r, char *uuid)
{
  apr_hash_t *cluster = get_cluster(clusters, r);

  if (cluster == NULL) {
    p2p_log(P2P_LOG_DEBUG, "get_connection(): no cluster with r=%d\n", r);
    return NULL;
  } else {
    return (p2p_connection_t *)apr_hash_get(cluster, uuid, APR_HASH_KEY_STRING);
  }
}

void add_connection(apr_hash_t *clusters, unsigned long r, p2p_connection_t *conn)
{
  p2p_connection_t *tmp = (p2p_connection_t *)get_connection(clusters, r, conn->peer_uuid);

  p2p_log(P2P_LOG_DEBUG, "add_connection(): r = %d, uuid = %s, ipaddr = %s, port = %d\n",
	  r, conn->peer_uuid, conn->ipaddr, conn->port);
  if (tmp == NULL) {
    apr_hash_t *cluster;
    char *tmp_uuid = (char *)apr_pcalloc(mypool, P2P_UUID_FORMATTED_LENGTH + 1);

    add_cluster(clusters, r);
    cluster = get_cluster(clusters, r);
    apr_cpystrn(tmp_uuid, conn->peer_uuid, P2P_UUID_FORMATTED_LENGTH + 1);
    apr_hash_set(cluster, tmp_uuid, APR_HASH_KEY_STRING, conn);
  }
}

void remove_connection(apr_hash_t *clusters, unsigned long r, p2p_connection_t *conn)
{
  p2p_connection_t *tmp = (p2p_connection_t *)get_connection(clusters, r, conn->peer_uuid);

  p2p_log(P2P_LOG_DEBUG, "remove_connection(): r = %d, uuid = %s\n", r, conn->peer_uuid);
  if (tmp != NULL) {
    apr_hash_t *cluster;
    char *tmp_uuid = (char *)apr_pcalloc(mypool, P2P_UUID_FORMATTED_LENGTH + 1);
    apr_hash_index_t *i;
    int c;

    cluster = get_cluster(clusters, r);
#if 0
    if (conn->reader != 0)
      apr_thread_exit(conn->reader, APR_SUCCESS);
#endif
    if (conn->sock != 0)
      apr_socket_close(conn->sock);
    apr_cpystrn(tmp_uuid, conn->peer_uuid, P2P_UUID_FORMATTED_LENGTH + 1);
    apr_hash_set(cluster, tmp_uuid, APR_HASH_KEY_STRING, NULL);
    for (i = apr_hash_first(mypool, cluster), c = 0; i; i = apr_hash_next(i), c++);
    if (c == 0)
      remove_cluster(clusters, r);
  }
}

void dump_clusters(mystream_t *mystream, apr_hash_t *clusters)
{
  apr_hash_index_t *i, *j;
  apr_hash_t *cluster;
  int r;
  int *rptr = &r;
  char buf[P2P_UUID_FORMATTED_LENGTH + 1];
  char *bptr = buf;
  p2p_connection_t *conn;

  mystream_printf(mystream, "--------- clusters dump start ---------\n");
  for (i = apr_hash_first(mypool, clusters); i; i = apr_hash_next(i)) {
    apr_hash_this(i, (void *)&rptr, NULL, (void **)&(cluster));
    mystream_printf(mystream, "cluster (0x%08x) with r=%d\n", cluster, *rptr);
    for (j = apr_hash_first(mypool, cluster); j; j = apr_hash_next(j)) {
      apr_hash_this(j, (void *)&bptr, NULL, (void **)&(conn));
      mystream_printf(mystream, "  %d: %s (key=%s) [%s:%d] %s\n",
		      *rptr, conn->peer_uuid, bptr, conn->ipaddr, conn->port, conn->is_tunnel == 1 ? "t" : " ");
    }
  }
  mystream_printf(mystream, "--------- clusters dump end   ---------\n");
}

void remove_all_connections(apr_hash_t *clusters)
{
  apr_hash_index_t *i, *j;
  apr_hash_t *cluster;
  p2p_connection_t *conn;
  int r;
  int *rptr = &r;

  p2p_log(P2P_LOG_DEBUG, "remove_all_connections(): start\n");
  for (i = apr_hash_first(mypool, clusters); i; i = apr_hash_next(i)) {
    apr_hash_this(i, NULL, (void *)&rptr, (void **)&(cluster));
    for (j = apr_hash_first(mypool, cluster); j; j = apr_hash_next(j)) {
      char *tmp_uuid = (char *)apr_pcalloc(mypool, P2P_UUID_FORMATTED_LENGTH + 1);

      apr_hash_this(j, NULL, NULL, (void **)&(conn));
      p2p_log(P2P_LOG_DEBUG, "remove_all_connections(): removing %s\n", conn->peer_uuid);
      if (conn->sock != 0)
	apr_socket_close(conn->sock);
      apr_cpystrn(tmp_uuid, conn->peer_uuid, P2P_UUID_FORMATTED_LENGTH + 1);
      apr_hash_set(cluster, tmp_uuid, APR_HASH_KEY_STRING, NULL);
    }
    remove_cluster(clusters, *rptr);
  }
  p2p_log(P2P_LOG_DEBUG, "remove_all_connections(): end\n");
}

int is_in_cluster(int r, char *target_uuid)
{
  apr_hash_t *cluster;

  if ((cluster = get_cluster(basic_clusters, r)) != NULL) {
    apr_hash_index_t *i;
    p2p_connection_t *cc;

    for (i = apr_hash_first(mypool, cluster); i; i = apr_hash_next(i)) {
      apr_hash_this(i, NULL, NULL, (void **)&(cc));
      if (strncmp(cc->peer_uuid, target_uuid, APR_UUID_FORMATTED_LENGTH) == 0) {
	return 1;
      }
    }
  }
  return 0;
}

int send_msg_to_connections(p2p_connection_link_t *lst, apr_size_t *length, char *msg)
{
  p2p_connection_t *conn;
  apr_status_t stat;
  char msgbuf[80];

  APR_RING_FOREACH(conn, lst, p2p_connection_s, link) {
    p2p_log(P2P_LOG_DEBUG, "send_msg_to_connections(): sending!!!\n");
    if ((stat = apr_send(conn->sock, msg, length) != APR_SUCCESS)) {
      apr_socket_close(conn->sock);
#if !defined(PROHIBIT_LOCAL_CONNECTION)
      if (conn->is_local)
	remove_connection(adhoc_clusters, conn->r, conn);
      else
	remove_connection(basic_clusters, conn->r, conn);
#else
      remove_connection(basic_clusters, conn->r, conn);
#endif	/* !PROHIBIT_LOCAL_CONNECTION */
      p2p_log(P2P_LOG_ERROR, "Problem sending data: %s (%d)\n",
	  apr_strerror(stat, msgbuf, sizeof(msgbuf)), stat);
      return -1;
    }
    p2p_log(P2P_LOG_DEBUG, "send_msg_to_connections(): done!!!\n");
  }
  /* FIXME: free all elements in lst */
  return strlen(msg);	/* FIXME: non-sence? */
}

int is_tunnel(unsigned long r)
{
  apr_hash_t *cluster;

  if ((cluster = get_cluster(basic_clusters, r)) != 0) {
    apr_hash_index_t *i;
    p2p_connection_t *cc;

    for (i = apr_hash_first(mypool, cluster); i; i = apr_hash_next(i)) {
      apr_hash_this(i, NULL, NULL, (void **)&(cc));
      if (cc->is_tunnel) {
	p2p_log(P2P_LOG_DEBUG, "is_tunnel(): no\n");
	return 0;
      }
    }
  }
  p2p_log(P2P_LOG_DEBUG, "is_tunnel(): yes\n");
  return 1;
}

extern void * APR_THREAD_FUNC message_reader(apr_thread_t *t, void *data);

p2p_connection_t *create_connection
(apr_socket_t *sock, char *uuidstr, char *ipaddr, int port, int is_tunnel, int r)
{
  p2p_connection_t *conn = (p2p_connection_t *)apr_pcalloc(mypool, sizeof(p2p_connection_t));
  apr_threadattr_t *attr;

  conn->sock = sock;
  apr_cpystrn(conn->peer_uuid, uuidstr, strlen(uuidstr) + 1);
  apr_cpystrn(conn->ipaddr, ipaddr, strlen(ipaddr) + 1);
  conn->port = port;
  conn->is_tunnel = is_tunnel;
  apr_threadattr_create(&attr, mypool);
  apr_thread_create(&(conn->reader), attr, message_reader, (void *)conn, mypool);
  conn->r = r;
  return conn;
}

void p2p_list_connections(mystream_t *mystream, char **argv, char *rest)
{
  dump_clusters(mystream, basic_clusters);
#if !defined(PROHIBIT_LOCAL_CONNECTION)
  dump_clusters(mystream, adhoc_clusters);
#endif	/* !PROHIBIT_LOCAL_CONNECTION */
}

#if defined(CLUSTERS_TEST)
static p2p_connection_t *create_connection(apr_uuid_t *uuidbuf, char *addr, int port)
{
  p2p_connection_t *conn = (p2p_connection_t *)apr_pcalloc(mypool, sizeof(p2p_connection_t));
  apr_uuid_get(uuidbuf);
  apr_uuid_format(conn->peer_uuid, uuidbuf);
  apr_cpystrn(conn->ipaddr, addr, strlen(addr) + 1);
  conn->port = port;
  printf("create_connection(): uuid   = %s\n", conn->peer_uuid);
  printf("create_connection(): ipaddr = %s\n", conn->ipaddr);
  printf("create_connection(): port   = %d\n", conn->port);
  return conn;
}

static void fetch_test(apr_hash_t *clusters, int r, p2p_connection_t *conn)
{
  p2p_connection_t *tmp;

  printf("fetch_test(): fetching r = %d, uuid = %s\n", r, conn->peer_uuid);
  tmp = get_connection(clusters, r, conn->peer_uuid);
  if (tmp == NULL)
    printf("no such connection\n");
  else
    printf("fetch_test(): uuid = %s found\n", conn->peer_uuid);
}

int main()
{
  p2p_connection_t *c1, *c2, *c3;
  apr_uuid_t uuid1, uuid2, uuid3;
  char *addr1 = "192.168.0.100", *addr2 = "192.168.0.101", *addr3 = "192.168.0.102";
  int port1 = 10001, port2 = 10002, port3 = 10003;

  apr_initialize();
  apr_pool_initialize();
  apr_pool_create(&mypool, 0);

  init_clusters(&basic_clusters);

  c1 = create_connection(&uuid1, addr1, port1);
  c2 = create_connection(&uuid2, addr2, port2);
  c3 = create_connection(&uuid3, addr3, port3);
  add_connection(basic_clusters, NO_RESOLUTION, c1);
  add_connection(basic_clusters, 1, c2);
  add_connection(basic_clusters, 1, c3);
  dump_clusters(basic_clusters);
  fetch_test(basic_clusters, NO_RESOLUTION, c1);
  fetch_test(basic_clusters, 1, c2);
  fetch_test(basic_clusters, 1, c3);
  remove_connection(basic_clusters, 1, c2);
  dump_clusters(basic_clusters);
  remove_connection(basic_clusters, 1, c3);
  dump_clusters(basic_clusters);
  remove_connection(basic_clusters, NO_RESOLUTION, c1);
  dump_clusters(basic_clusters);

  apr_pool_terminate();
  apr_terminate();

  return(1);
}
#endif	/* CLUSTERS_TEST */

