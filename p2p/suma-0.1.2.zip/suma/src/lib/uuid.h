#if !defined(_UUID_H_)
#define _UUID_H_

#include <openssl/bn.h>

#define UUID_LENGTH	16
#if !defined(XML_SETTINGS)
#define UUID_FILENAME	"uuid.file"
#endif	/* !XML_SETTINGS */

void p2p_hash(BIGNUM id, unsigned long r, unsigned long *x, unsigned long *y);
#if !defined(XML_SETTINGS)
void set_uuid(char *uuid_filename);
#endif	/* !XML_SETTINGS */

#endif	/* _UUID_H_ */
