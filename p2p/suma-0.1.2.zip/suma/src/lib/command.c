#include <apr.h>
#include <apr_thread_proc.h>
#include <string.h>
#include "sumalib.h"
#include "command.h"

extern apr_pool_t *mypool;

int dispatch(mystream_t *mystream, char *buf, int n_commands, command_t commands[])
{
  int i, j;
  char **argv;
  char *rest;
  command_t *cmd = 0, *tmp_cmd;

  for (i = 0; i < n_commands; i++) {
    tmp_cmd = &(commands[i]);
    if (strncmp(buf, tmp_cmd->name, strlen(tmp_cmd->name)) == 0) {
      cmd = tmp_cmd;
      argv = (char **)apr_pcalloc(mypool, sizeof(char *));
      /* FIXME: rewrite with apr_strtok(). */
      for (j = 1; j <= cmd->argc; j++) {
	buf = argv[j - 1] = strchr(buf, ' ') + 1;
	*(buf - 1) = 0;
      }
      if (cmd->need_rest == 1) {
	buf = rest = strchr(buf, ' ') + 1;
	*(buf - 1) = 0;
      }
      break;
    }
  }
  if (cmd != 0) {	/* dump args and execute handler */
    p2p_log(P2P_LOG_DEBUG, "dispatch: command = %s\n", cmd->name);
    for (i = 0; i < cmd->argc; i++) {
      p2p_log(P2P_LOG_DEBUG, "dispatch: argv[%d] = %s\n", i, argv[i]);
    }
    if (cmd->need_rest == 1)
      p2p_log(P2P_LOG_DEBUG, "dispatch: rest = %s\n", rest);
    (cmd->handler)(mystream, argv, rest);
  } else {
    p2p_log(P2P_LOG_ERROR, "no such command\n");
  }
  return 0;
}
