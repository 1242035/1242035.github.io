#if !defined(_SUMALIB_H_)
#define _SUMALIB_H_

#include <stdarg.h>
#include <apr_uuid.h>
#include "mystream.h"

#define P2P_LOG_ERROR		1
#define P2P_LOG_INFO		2
#define P2P_LOG_DEBUG		3

/*#define PROHIBIT_LOCAL_CONNECTION*/

void p2p_log(int level, char *fmt, ...);
void p2p_show_loglevel(mystream_t *mystream, char **argv, char *rest);
void p2p_set_loglevel(mystream_t *mystream, char **argv, char *rest);

#define P2P_UUID_FORMATTED_LENGTH	APR_UUID_FORMATTED_LENGTH
typedef apr_uuid_t p2p_uuid_t;
extern p2p_uuid_t uuid;
void p2p_uuid_format(char *buffer, const p2p_uuid_t *uuid);

typedef struct {
  unsigned int n_dst;
  char uuids[0][P2P_UUID_FORMATTED_LENGTH + 1];
} p2p_destinations_t;

typedef struct p2p_channel_s p2p_channel_t;

p2p_channel_t *p2p_create_broadcast_channel(unsigned int service_port);
p2p_channel_t *p2p_create_multicast_channel(unsigned int service_port, p2p_destinations_t *dst);
p2p_channel_t *p2p_create_unicast_channel(unsigned int service_port, char* dst_uuid);
int p2p_init(int argc, char *argv[], char *entry_points_ip_addrs[]);
int p2p_write(p2p_channel_t *chann, char *body, int len);
int p2p_read(p2p_channel_t *chann, char *msg, int len);
int p2p_close_channel(p2p_channel_t *chann);
int p2p_register_response_callback(int service_port, int (*handler)(p2p_channel_t *));
int p2p_register_shutdown_callback
(int service_port,
 int (*handler)(p2p_channel_t *)	/* channel might be null */
 );
void p2p_list_connections(mystream_t *mystream, char **argv, char *rest);
void p2p_list_channels(mystream_t *mystream, char **argv, char *rest);
int p2p_shutdown();

#endif	/* _SUMALIB_H_ */
