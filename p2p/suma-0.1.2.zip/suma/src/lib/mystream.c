#include <apr_pools.h>
#include <apr_file_io.h>
#include <apr_network_io.h>
#include <apr_strings.h>
#include <stdarg.h>
#include "mystream.h"

typedef enum {
  MYSTREAM_FILE,
  MYSTREAM_SOCK
} mystream_type_t;

struct mystream_s {
  mystream_type_t type;
  union {
    apr_file_t *file;
    apr_socket_t *sock;
  } strm;
};

mystream_t *file2mystream(apr_pool_t *pool, apr_file_t *file)
{
  mystream_t *mystream = (mystream_t *)apr_pcalloc(pool, sizeof(mystream_t));

  mystream->type = MYSTREAM_FILE;
  mystream->strm.file = file;
  return mystream;
}

mystream_t *sock2mystream(apr_pool_t *pool, apr_socket_t *sock)
{
  mystream_t *mystream = (mystream_t *)apr_pcalloc(pool, sizeof(mystream_t));

  mystream->type = MYSTREAM_SOCK;
  mystream->strm.sock = sock;
  return mystream;
}

void mystream_printf(mystream_t *mystream, char *fmt, ...)
{
  char str[2048];
  va_list ap;

  va_start(ap, fmt);
  apr_vsnprintf(str, 2048, fmt, ap);
  va_end(ap);
  switch (mystream->type) {
  case MYSTREAM_FILE:
    apr_file_printf(mystream->strm.file, "%s", str);
    break;
  case MYSTREAM_SOCK:
    {
      apr_status_t stat;
      char msgbuf[80];
      int len;
      apr_socket_t *sock = mystream->strm.sock;

      len = strlen(str) + 1;
      if ((stat = apr_send(sock, str, &len) != APR_SUCCESS)) {
	apr_socket_close(sock);
	printf("Problem sending data: %s (%d)\n",
	       apr_strerror(stat, msgbuf, sizeof(msgbuf)), stat);
      }
    }
    break;
  }
}
