#if !defined(_SETTINGS_H_)
#define _SETTINGS_H_

#include <apr_xml.h>
#include "sumalib.h"

typedef struct str_elem_s str_elem_t;

typedef struct str_elem_link_s str_elem_link_t;
struct str_elem_link_s {
  str_elem_t *prev;
  str_elem_t *next;
};

struct str_elem_s {
  char *strval;
  str_elem_link_t link;
};

typedef struct {
  char *uuid;
  int is_listening;
  int basic_port;
  str_elem_link_t entry_points;
} general_settings_t;

typedef struct {
  int is_entry_point;
  str_elem_link_t allow_list;
  str_elem_link_t deny_list;
} entry_point_settings_t;

typedef struct {
  int is_listening;
  int debug_port;
} debug_settings_t;

typedef struct {
  int level;
} logger_settings_t;

typedef struct {
  general_settings_t general_settings;
  entry_point_settings_t entry_point_settings;
  debug_settings_t debug_settings;
  logger_settings_t logger_settings;
} settings_t;

extern settings_t settings;

int init_settings(char *filename);
#if defined(XML_SETTINGS)
void set_uuid_slot(p2p_uuid_t *uuid);
#endif	/* XML_SETTINGS */
int save_settings(char *filename);

#endif	/* _SETTINGS_H_ */
