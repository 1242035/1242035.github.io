#include <apr.h>
#include <apr_pools.h>
#include <apr_network_io.h>
#include <apr_strings.h>
#include <apr_file_io.h>
#include <string.h>
#include <stdlib.h>
#include "internal.h"
#include "msg.h"
#include "clusters.h"
#include "sumalib.h"

#if defined(TEST_UTIL)
/* -------------------- stubs start -------------------- */
#include <stdarg.h>
#define P2P_LOG_ERROR		1
#define P2P_LOG_INFO		2
#define P2P_LOG_DEBUG		3
void p2p_log(int level, char *fmt, ...)
{
  char str[2048];
  va_list ap;

  va_start(ap, fmt);
  vsnprintf(str, 2048, fmt, ap);
  va_end(ap);
  printf("%s", str);
}
#define P2P_PORT		10001		/* tcp/ip service port */
static apr_pool_t *mypool;
/* -------------------- stubs end   -------------------- */
#else
extern apr_pool_t *mypool;
#endif	/* TEST_UTIL */

#if !defined(TEST_UTIL)
int read_msg(apr_socket_t *sock, char **buf)
{
  apr_size_t length;
  apr_status_t stat;
  char msgbuf[80];

  length = LENGTH_SIZE;
  *buf = (char *)apr_pcalloc(mypool, 2048);	/* FIXME: 2048? */
  p2p_log(P2P_LOG_DEBUG, "read_msg(): reading length!!!\n");
  if ((stat = apr_recv(sock, *buf, &length)) != APR_SUCCESS) {
    apr_socket_close(sock);
    p2p_log(P2P_LOG_ERROR, "read_msg(): Problem receiving data: %s (%d)\n", 
	    apr_strerror(stat, msgbuf, sizeof(msgbuf)), stat);
    /* FIXME: error handling is needed. */
    return -1;
  }
  p2p_log(P2P_LOG_DEBUG, "read_msg(): done!!!\n");
  length = *((unsigned int *)(*buf)) - LENGTH_SIZE;
  p2p_log(P2P_LOG_DEBUG, "read_msg(): reading rest (%d bytes)!!!\n", length);
  /* FIXME: make a read loop. */
  if ((stat = apr_recv(sock, (*buf) + LENGTH_SIZE, &length)) != APR_SUCCESS) {
    apr_socket_close(sock);
    p2p_log(P2P_LOG_ERROR, "read_msg(): Problem receiving data: %s (%d)\n", 
	    apr_strerror(stat, msgbuf, sizeof(msgbuf)), stat);
    /* FIXME: error handling is needed. */
    return -1;
  }
  p2p_log(P2P_LOG_DEBUG, "read_msg(): done!!!\n");
  return 0;
}
#endif	/* TEST_UTIL */

void split_ipaddr_string(char *str, char **ip_addr, int *port, int default_port)
{
  char *port_str = strchr(str, ':');
  int len;

  if (port_str != NULL) {
    len = port_str - str + 1;
    port_str++;
    *port = atoi(port_str);
  } else {
    *port = default_port;
    len = strlen(str) + 1;
  }
  *ip_addr = (char *)apr_pcalloc(mypool, len);
  apr_cpystrn(*ip_addr, str, len);
  p2p_log(P2P_LOG_DEBUG, "split_ipaddr_string(): str = %s, ip_addr = %s, port = %d\n", str, *ip_addr, *port);
}

#if !defined(XML_SETTINGS)
char **read_eps_from_file(char *eps_filename)
{
  apr_file_t *f = NULL;
  char buf[64];
  apr_status_t stat;
  int c, i, len;
  char **argv;

  p2p_log(P2P_LOG_DEBUG, "read_eps_from_file(): start\n");
  stat = apr_file_open(&f, eps_filename, APR_READ, APR_OS_DEFAULT, mypool);
  if (stat != APR_SUCCESS) {
    p2p_log(P2P_LOG_ERROR, "read_eps_from_file(): cannot open\n");
    return 0;
  } else {
    p2p_log(P2P_LOG_DEBUG, "read_eps_from_file(): opened successfully. \n");
    for (c = 0; (stat = apr_file_gets(buf, APR_UUID_FORMATTED_LENGTH + 1, f) == APR_SUCCESS); c++);
#if 0
    apr_file_seek(f, APR_SET, 0);	/* won't work! */
#else
    apr_file_close(f);
    stat = apr_file_open(&f, eps_filename, APR_READ, APR_OS_DEFAULT, mypool);
#endif
    p2p_log(P2P_LOG_DEBUG, "read_eps_from_file(): %d records\n", c);
    argv = (char **)apr_pcalloc(mypool, sizeof(char *) * (c + 1));
    memset(buf, 0, 64);
    for (i = 0; (stat = apr_file_gets(buf, APR_UUID_FORMATTED_LENGTH + 1, f) == APR_SUCCESS); i++) {
      *(buf + strlen(buf) - 1) = 0;
      p2p_log(P2P_LOG_DEBUG, "read_eps_from_file(): record = %s\n", buf);
      if ((len = strlen(buf)) > 0) {
	argv[i] = (char *)apr_pcalloc(mypool, len + 1);
	apr_cpystrn(argv[i], buf, len + 1);
      }
    }
    apr_file_close(f);
    p2p_log(P2P_LOG_DEBUG, "read_eps_from_file(): ...done\n");
  }
  return argv;
}
#endif	/* !XML_SETTINGS */

void dump_connection(apr_socket_t *sock)
{
  apr_sockaddr_t *localsa, *remotesa;
  char *local_ipaddr, *remote_ipaddr;
  apr_port_t local_port, remote_port;

  apr_socket_addr_get(&remotesa, APR_REMOTE, sock);
  apr_sockaddr_ip_get(&remote_ipaddr, remotesa);
  apr_sockaddr_port_get(&remote_port, remotesa);
  apr_socket_addr_get(&localsa, APR_LOCAL, sock);
  apr_sockaddr_ip_get(&local_ipaddr, localsa);
  apr_sockaddr_port_get(&local_port, localsa);
  p2p_log(P2P_LOG_DEBUG, "Server socket: %s:%u -> %s:%u\n", local_ipaddr,
      local_port, remote_ipaddr, remote_port);
}

#if defined(TEST_UTIL)
void print_argv(char **argv)
{
  int i;

  for (i = 0; argv[i] != NULL; i++) {
    printf("argv[%d] = %s\n", i, argv[i]);
  }
}

int main()
{
  apr_initialize();
  apr_pool_initialize();
  apr_pool_create(&mypool, 0);

  {
    char *str[] = {"127.0.0.1:10002", "127.0.0.2", "127.0.0.3:99999", 0};
    int i;

    for (i = 0; ; i++) {
      char *ip_addr;
      int port;

      if (str[i] == 0) break;
      split_ipaddr_string(str[i], &ip_addr, &port);
    }
  }
  {
    char **argv = read_eps_from_file("eps.file");

    if (argv != 0)
      print_argv(argv);
  }

  apr_pool_terminate();
  apr_terminate();
}
#endif	/* TEST_UTIL */
