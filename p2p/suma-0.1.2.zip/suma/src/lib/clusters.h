#if !defined(_CLUSTERS_H_)
#define _CLUSTERS_H_

#include <apr.h>
#include <apr_hash.h>
#include <apr_network_io.h>
#include "internal.h"
#include "mystream.h"

#define NO_RESOLUTION		-1

extern apr_hash_t *basic_clusters;
extern apr_hash_t *adhoc_clusters;

void init_clusters(apr_hash_t **clusters);
apr_hash_t *get_cluster(apr_hash_t *clusters, unsigned long r);
p2p_connection_t *get_connection(apr_hash_t *clusters, unsigned long r, char *uuid);
void add_connection(apr_hash_t *clusters, unsigned long r, p2p_connection_t *conn);
void remove_connection(apr_hash_t *clusters, unsigned long r, p2p_connection_t *conn);
void dump_clusters(mystream_t *mystream, apr_hash_t *clusters);
void remove_all_connections(apr_hash_t *clusters);
int is_in_cluster(int r, char *target_uuid);
int send_msg_to_connections(p2p_connection_link_t *lst, apr_size_t *length, char *msg);
int is_tunnel(unsigned long r);
p2p_connection_t *create_connection
(apr_socket_t *sock, char *uuidstr, char *ipaddr, int port, int is_tunnel, int r);

#endif	/* _CLUSTERS_H_ */
