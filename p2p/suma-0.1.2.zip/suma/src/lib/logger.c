#include <stdarg.h>
#include <apr_strings.h>
#include <apr_time.h>
#include <stdlib.h>
#include <stdio.h>
#include "sumalib.h"
#include "mystream.h"

int loglevel = P2P_LOG_DEBUG;

void p2p_log(int level, char *fmt, ...)
{
  if (loglevel >= level) {
    char str[2048];
    char *levelstr;
    apr_time_t now;
    apr_time_exp_t xt;
    char tstr[50];
    apr_size_t sz;

    va_list ap;
    va_start(ap, fmt);
#if 0
    vsnprintf(str, 2048, fmt, ap);
#else
    apr_vsnprintf(str, 2048, fmt, ap);
#endif
    va_end(ap);
    switch (level) {
    case P2P_LOG_ERROR:	levelstr = "[-- error --]"; break;
    case P2P_LOG_INFO:	levelstr = "[-- info  --]"; break;
    case P2P_LOG_DEBUG:	levelstr = "[-- debug --]"; break;
    }
    now = apr_time_now();
    apr_time_exp_lt(&xt, now);
    apr_strftime((char *)&tstr, &sz, 50, "%Y %b %d %X", &xt);
    fprintf(stderr, "%s %s %s", tstr, levelstr, str);
  }
}

void p2p_show_loglevel(mystream_t *mystream, char **argv, char *rest)
{
  mystream_printf(mystream, "%d (error:%d, info:%d, debug:%d)\n",
		  loglevel, P2P_LOG_ERROR, P2P_LOG_INFO, P2P_LOG_DEBUG);
}

void p2p_set_loglevel(mystream_t *mystream, char **argv, char *rest)
{
  loglevel = atoi(argv[0]);
}

#if defined(TEST_LOGGER)

int main()
{
  p2p_log(P2P_LOG_DEBUG, "test test test.\n");
}

#endif	/* TEST_LOGGER */
