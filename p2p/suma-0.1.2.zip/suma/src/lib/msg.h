#if !defined(_MSG_H_)
#define _MSG_H_

/**
 * @file msg.h
 * @brief p2p basic message formats and their handlers
 */
/**
 * @defgroup msg msg
 * @{
 */

#include <apr_uuid.h>
#include "sumalib.h"
#include "internal.h"
#if defined(XML_SETTINGS)
#include "settings.h"
#endif	/* XML_SETTINGS */

#define P2P_KIND_HELLO1		"HELLO1"
#define P2P_KIND_REPLY1		"REPLY1"
#define P2P_KIND_HELLO2		"HELLO2"
#define P2P_KIND_REPLY2		"REPLY2"
#define P2P_KIND_BROAD		"BROAD"
#define P2P_KIND_MULTI		"MULTI"
#define P2P_KIND_UNI		"UNI"

#define LENGTH_SIZE	(sizeof(unsigned int))
/**
 * common part of p2p_msg_*
 */
typedef struct {
  unsigned int length;
  char kind[8];
  char src_uuid[APR_UUID_FORMATTED_LENGTH + 1];
} p2p_msg_common_t;

typedef struct {
  p2p_msg_common_t common;
  char ipaddr[16];
  unsigned long port;
  unsigned long r;	/* resolution */
  char ep_uuid[APR_UUID_FORMATTED_LENGTH + 1];
#if !defined(PROHIBIT_LOCAL_CONNECTION)
  int is_local;
  char your_ipaddr[16];
#endif	/* !PROHIBIT_LOCAL_CONNECTION */
} p2p_msg_hello_t;

typedef struct {
  char ipaddr[16];
  unsigned long port;
  int is_tunnel;
  char uuid[APR_UUID_FORMATTED_LENGTH + 1];
} p2p_cmem_t;

typedef struct {
  p2p_msg_common_t common;
  unsigned long r;	/* resolution */
  char newbee_uuid[APR_UUID_FORMATTED_LENGTH + 1];
  unsigned int n_mem;
  p2p_cmem_t mem[0];
} p2p_msg_reply_t;

typedef struct {
  p2p_msg_common_t common;
  unsigned int port;
} p2p_msg_broadcast_header_t;

typedef struct {
  p2p_msg_common_t common;
  unsigned int port;
  unsigned int n_dst;
  char dst_uuids[0][APR_UUID_FORMATTED_LENGTH + 1];
} p2p_msg_multicast_header_t;

typedef struct {	/* this is used as a reply */
  p2p_msg_common_t common;
  unsigned int port;
  char dst_uuid[APR_UUID_FORMATTED_LENGTH + 1];
  unsigned int length;
} p2p_msg_unicast_header_t;

/**
 * msg 'reply1' handler
 */
int process_reply1(p2p_connection_t *conn, char *buf);
int reply1_cb(p2p_channel_t *chann);
int process_hello1(p2p_connection_t *tmp, char *buf);
int process_hello2(p2p_connection_t *conn, char *buf);
int process_broad(p2p_connection_t *conn, char *buf);
int process_multi(p2p_connection_t *conn, char *buf);
int process_uni(p2p_connection_t *conn, char *buf);
char *construct_msg(p2p_channel_t *chann, char *body, int len);
void establish_basic_connection(
#if defined(XML_SETTINGS)
				str_elem_link_t *entry_points
#else
				char *entry_points_ip_addrs[]
#endif
				);
p2p_destinations_t *construct_destinations_from_msg(char *buf);
void exec_callback_if_possible(char *buf, p2p_destinations_t *dst);
int relay_local(char *msg);

/** @} */

#endif	/* _MSG_H_ */
