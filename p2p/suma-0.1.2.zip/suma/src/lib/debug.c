#include <apr.h>
#include <apr_pools.h>
#include <apr_network_io.h>
#include <apr_thread_proc.h>
#include <apr_signal.h>
#include <stdlib.h>
#include <signal.h>
#include "sumalib.h"
#include "command.h"
#include "util.h"

#if defined(TEST_DEBUG)
/* -------------------- stubs start -------------------- */
#include <stdarg.h>
#define P2P_LOG_ERROR		1
#define P2P_LOG_INFO		2
#define P2P_LOG_DEBUG		3
void p2p_log(int level, char *fmt, ...)
{
  char str[2048];
  va_list ap;

  va_start(ap, fmt);
  vsnprintf(str, 2048, fmt, ap);
  va_end(ap);
  printf("%s", str);
}
void p2p_show_loglevel(mystream_t *mystream, char **argv, char *rest)
{
  printf("p2p_show_loglevel(): called\n");
}
void p2p_set_loglevel(mystream_t *mystream, char **argv, char *rest)
{
  printf("p2p_set_loglevel(): called\n");
}
void p2p_list_connections(mystream_t *mystream, char **argv, char *rest)
{
  printf("p2p_list_connections(): called\n");
  mystream_printf(mystream, "aaa %s\n", "xxx");
  mystream_printf(mystream, "bbb %s\n", "yyy");
  mystream_printf(mystream, "ccc %s\n", "zzz");
}
void p2p_list_channels(mystream_t *mystream, char **argv, char *rest)
{
  printf("p2p_list_channels(): called\n");
}
apr_pool_t *mypool;
static int exit_flag = 0;
/* -------------------- stubs end   -------------------- */
#else
extern apr_pool_t *mypool;
extern int exit_flag;
#endif	/* TEST_DEBUG */

apr_socket_t *debug_sock;
static apr_thread_t *listener;

#define N_SHELL_COMMANDS	4
command_t debug_commands[] = {
  /* basic commands */
  {"conn",  0, 0, p2p_list_connections},
  {"chann", 0, 0, p2p_list_channels},
  {"log?",  0, 0, p2p_show_loglevel},
  {"log=",  1, 0, p2p_set_loglevel},
};

static void debugger(apr_socket_t *sock)
{
  char buf[2048];
  int len;
  apr_status_t stat;
  char msgbuf[80];
  mystream_t *mystream;

  p2p_log(P2P_LOG_DEBUG, "debugger(): start\n");
  memset(buf, 0, len = 2048);
  if ((stat = apr_recv(sock, buf, &len)) != APR_SUCCESS) {
    apr_socket_close(sock);
    printf("Problem receiving data: %s (%d)\n", 
	   apr_strerror(stat, msgbuf, sizeof(msgbuf)), stat);
    exit(-1);
  }
  mystream = sock2mystream(mypool, sock);
  dispatch(mystream, buf, N_SHELL_COMMANDS, debug_commands);
  mystream_printf(mystream, "byebye\n");
  p2p_log(P2P_LOG_DEBUG, "debugger(): end\n");
}

static void * APR_THREAD_FUNC debug_listener(apr_thread_t *t, void *data)
{
  apr_socket_t *accepted_sock;
  apr_sockaddr_t *localsa;

  apr_socket_create(&debug_sock, AF_INET, SOCK_STREAM, mypool);
  apr_socket_addr_get(&localsa, APR_LOCAL, debug_sock);
  apr_sockaddr_port_set(localsa, (apr_port_t)(int)data);
  apr_bind(debug_sock, localsa);
  apr_listen(debug_sock, 5);
  while (1) {
    apr_accept(&accepted_sock, debug_sock, mypool);
    if (exit_flag)
      break;
    p2p_log(P2P_LOG_DEBUG, "debug_listener(): accepted\n");
    dump_connection(accepted_sock);
    debugger(accepted_sock);
  }
  apr_socket_close(debug_sock);
  p2p_log(P2P_LOG_DEBUG, "debug_listener(): end\n");
  return (void *)0;
}

void init_debug(int port)
{
  apr_threadattr_t *attr;

  apr_threadattr_create(&attr, mypool);
  apr_thread_create(&listener, attr, debug_listener, (void *)port, mypool);
}

void join_debug_listener(apr_status_t *rval)
{
  apr_thread_join(rval, listener);
}

#if defined(TEST_DEBUG)
int main()
{
  apr_threadattr_t *attr;
  apr_status_t rval;

  apr_initialize();
  apr_pool_initialize();
  apr_pool_create(&mypool, 0);

  init_debug();
  join_debug_listener(&rval);

  apr_pool_terminate();
  apr_terminate();
}
#endif	/* TEST_DEBUG */
