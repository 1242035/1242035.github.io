#if !defined(_COMMAND_H_)
#define _COMMAND_H_

#include "mystream.h"

typedef struct {
  char *name;
  int argc;
  int need_rest;
  void (*handler)(mystream_t *mystream, char **, char *);
} command_t;

int dispatch(mystream_t *mystream, char *buf, int n_commands, command_t commands[]);

#endif	/* _COMMAND_H_ */
