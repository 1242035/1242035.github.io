#if !defined(_INTERNAL_H_)
#define _INTERNAL_H_

#include <apr_network_io.h>
#include <apr_thread_proc.h>
#include <apr_uuid.h>
#if 1
#include <apr_thread_cond.h>
#include <apr_thread_mutex.h>
#endif
#include "sumalib.h"

#define P2P_PORT			10001		/* tcp/ip service port */
#define SUMA_CORE_PORT			0		/* suma service port */

#if !defined(XML_SETTINGS)
#define P2P_INIT_CLIENT			1
#define P2P_INIT_SERVER			2
#define P2P_INIT_INSIDE_FIREWALL	4		/* not used */
#endif	/* !XML_SETTINGS */

typedef struct p2p_connection_s p2p_connection_t;

typedef struct p2p_connection_link_s p2p_connection_link_t;
struct p2p_connection_link_s {
  p2p_connection_t *prev;
  p2p_connection_t *next;
};

struct p2p_connection_s {
  apr_socket_t *sock;
  apr_thread_t *reader;
  char peer_uuid[APR_UUID_FORMATTED_LENGTH + 1];
  char ipaddr[16];
  int port;		/* FIXME: use this */
  int is_tunnel;
#if !defined(PROHIBIT_LOCAL_CONNECTION)
  int is_local;
#endif	/* !PROHIBIT_LOCAL_CONNECTION */
  unsigned long r;	/* resolution */
  p2p_connection_link_t link;
};

#endif	/* _INTERNAL_H_ */
