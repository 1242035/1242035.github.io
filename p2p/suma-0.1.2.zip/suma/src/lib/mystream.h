#if !defined(_MYSTREAM_H_)
#define _MYSTREAM_H_

#include <apr_pools.h>
#include <apr_file_io.h>
#include <apr_network_io.h>
#include <stdarg.h>

typedef struct mystream_s mystream_t;

mystream_t *file2mystream(apr_pool_t *pool, apr_file_t *file);
mystream_t *sock2mystream(apr_pool_t *pool, apr_socket_t *sock);
void mystream_printf(mystream_t *mystream, char *fmt, ...);

#endif	/* _MYSTREAM_H_ */
