#include <apr.h>
#include <apr_general.h>
#include <apr_xml.h>
#include <apr_ring.h>
#if APR_HAVE_STDLIB_H
#include <stdlib.h>  /* for exit() */
#endif
#include "sumalib.h"
#include "settings.h"

#if defined(TEST_SETTINGS)
/* -------------------- stubs start -------------------- */
#include <stdarg.h>
#define P2P_LOG_ERROR		1
#define P2P_LOG_INFO		2
#define P2P_LOG_DEBUG		3
void p2p_log(int level, char *fmt, ...)
{
  char str[2048];
  va_list ap;

  va_start(ap, fmt);
  vsnprintf(str, 2048, fmt, ap);
  va_end(ap);
  printf("%s", str);
}
static apr_pool_t *mypool;
/* -------------------- stubs end   -------------------- */
#else
#include "sumalib.h"
extern apr_pool_t *mypool;
#endif	/* TEST_SETTINGS */
settings_t settings;
apr_xml_doc *doc;

static void dump_xml(apr_xml_elem *e, int level)
{
  apr_xml_attr *a;
  apr_xml_elem *ec;

  printf("%d: element %s (%s)\n", level, e->name, e->first_cdata.first->text);
  if (e->attr) {
    a = e->attr;
    printf("%d:\tattrs\t", level);
    while (a) {
      printf("%s=%s\t", a->name, a->value);
      a = a->next;
    }
    printf("\n");
  }
  if (e->first_child) {
    ec = e->first_child;
    while (ec) {
      dump_xml(ec, level + 1);
      ec = ec->next;
    }
  }
}

static void set_general_settings_slots(apr_xml_elem *ec)
{
  p2p_log(P2P_LOG_DEBUG, "set_general_settings_slots(): called\n");
  while (ec) {
    if (strcmp(ec->name, "isListening") == 0) {
      char *tmp = (char *)ec->first_cdata.first->text;
      int is_listening = 0;

      if (strcmp(tmp, "yes") == 0
	  || strcmp(tmp, "y") == 0
	  || strcmp(tmp, "1") == 0)
	is_listening = 1;
      settings.general_settings.is_listening = is_listening;
    } else if (strcmp(ec->name, "uuid") == 0)
      settings.general_settings.uuid = (char *)ec->first_cdata.first->text;
    else if (strcmp(ec->name, "basicPort") == 0)
      settings.general_settings.basic_port = atoi(ec->first_cdata.first->text);
    else if (strcmp(ec->name, "entryPoint") == 0) {
      str_elem_t *elem = (str_elem_t *)apr_pcalloc(mypool, sizeof(str_elem_t));

      elem->strval = (char *)ec->first_cdata.first->text;
      APR_RING_INSERT_TAIL(&settings.general_settings.entry_points, elem, str_elem_s, link);
    }
    ec = ec->next;
  }
}

static void set_entry_point_settings_slots(apr_xml_elem *ec)
{
  p2p_log(P2P_LOG_DEBUG, "set_entry_point_settings_slots(): called\n");
  while (ec) {
    if (strcmp(ec->name, "isEntryPoint") == 0) {
      char *tmp = (char *)ec->first_cdata.first->text;
      int is_entry_point = 0;

      if (strcmp(tmp, "yes") == 0
	  || strcmp(tmp, "y") == 0
	  || strcmp(tmp, "1") == 0) {
	is_entry_point = 1;
	settings.general_settings.is_listening = 1;	/* to avoid contradiction (too) easily */
      }
      settings.entry_point_settings.is_entry_point = is_entry_point;
    } else if (strcmp(ec->name, "allow") == 0) {
      str_elem_t *elem = (str_elem_t *)apr_pcalloc(mypool, sizeof(str_elem_t));

      elem->strval = (char *)ec->first_cdata.first->text;
      APR_RING_INSERT_TAIL(&settings.entry_point_settings.allow_list, elem, str_elem_s, link);
    } else if (strcmp(ec->name, "deny") == 0) {
      str_elem_t *elem = (str_elem_t *)apr_pcalloc(mypool, sizeof(str_elem_t));

      elem->strval = (char *)ec->first_cdata.first->text;
      APR_RING_INSERT_TAIL(&settings.entry_point_settings.deny_list, elem, str_elem_s, link);
    }
    ec = ec->next;
  }
}

static void set_debug_settings_slots(apr_xml_elem *ec)
{
  p2p_log(P2P_LOG_DEBUG, "set_debug_settings_slots(): called\n");
  while (ec) {
    if (strcmp(ec->name, "isListening") == 0) {
      char *tmp = (char *)ec->first_cdata.first->text;
      int is_listening = 0;

      if (strcmp(tmp, "yes") == 0
	  || strcmp(tmp, "y") == 0
	  || strcmp(tmp, "1") == 0)
	is_listening = 1;
      settings.debug_settings.is_listening = is_listening;
    } else if (strcmp(ec->name, "debugPort") == 0)
      settings.debug_settings.debug_port = atoi(ec->first_cdata.first->text);
    ec = ec->next;
  }
}

static void set_logger_settings_slots(apr_xml_elem *ec)
{
  p2p_log(P2P_LOG_DEBUG, "set_logger_settings_slots(): called\n");
  while (ec) {
    if (strcmp(ec->name, "level") == 0) {
      char *tmp = (char *)ec->first_cdata.first->text;
      int level = P2P_LOG_ERROR;

      if (strcmp(tmp, "error") == 0)
	level = P2P_LOG_ERROR;
      else if (strcmp(tmp, "info") == 0)
	level = P2P_LOG_INFO;
      else if (strcmp(tmp, "debug") == 0)
	level = P2P_LOG_DEBUG;
      settings.logger_settings.level = level;
    }
    ec = ec->next;
  }
}

int init_settings(char *filename)
{
  apr_file_t *fd;
  apr_xml_parser *parser;
  apr_status_t rv;
  char errbuf[2000];
  char errbufXML[2000];
  apr_xml_elem *ec;

  p2p_log(P2P_LOG_DEBUG, "init_settings(): start\n");
  memset(&settings, 0, sizeof(settings_t));
  APR_RING_INIT(&settings.general_settings.entry_points, str_elem_s, link);
  APR_RING_INIT(&settings.entry_point_settings.allow_list, str_elem_s, link);
  APR_RING_INIT(&settings.entry_point_settings.deny_list, str_elem_s, link);
  rv = apr_file_open(&fd, filename, APR_READ, APR_OS_DEFAULT, mypool);
  if (rv != APR_SUCCESS) {
    p2p_log(P2P_LOG_ERROR, "cannot open: %s", filename);
    return -1;
  }
  rv = apr_xml_parse_file(mypool, &parser, &doc, fd, 2000);
  if (rv != APR_SUCCESS) {
    p2p_log(P2P_LOG_ERROR, "APR Error %s\nXML Error: %s\n",
	    apr_strerror(rv, errbuf, sizeof(errbuf)),
	    apr_xml_parser_geterror(parser, errbufXML, sizeof(errbufXML)));
    return -1;
  }
#if 0
  dump_xml(doc->root, 0);
#endif
  apr_file_close(fd);
  if (doc->root->first_child) {
    ec = doc->root->first_child;
    while (ec) {
      if (strcmp(ec->name, "generalSettings") == 0)
	set_general_settings_slots(ec->first_child);
      else if (strcmp(ec->name, "entryPointSettings") == 0)
	set_entry_point_settings_slots(ec->first_child);
      else if (strcmp(ec->name, "loggerSettings") == 0)
	set_logger_settings_slots(ec->first_child);
      else if (strcmp(ec->name, "debugSettings") == 0)
	set_debug_settings_slots(ec->first_child);
      ec = ec->next;
    }
  }
  p2p_log(P2P_LOG_DEBUG, "init_settings(): end\n");
  return 0;
}

#if defined(XML_SETTINGS)
void set_uuid_slot(p2p_uuid_t *uuid)
{
  settings.general_settings.uuid = (char *)apr_pcalloc(mypool, APR_UUID_FORMATTED_LENGTH + 1);
  apr_uuid_format(settings.general_settings.uuid, uuid);
}
#endif	/* XML_SETTINGS */

void dump_general_settings(apr_file_t *f)
{
  str_elem_t *elem;

  apr_file_printf(f, "  <generalSettings>\n");
  if (settings.general_settings.is_listening == 1)
    apr_file_printf(f, "    <isListening>%s</isListening>\n", "yes");
  else if (settings.general_settings.is_listening == 0)
    apr_file_printf(f, "    <isListening>%s</isListening>\n", "no");
  if (settings.general_settings.uuid != 0)
    apr_file_printf(f, "    <uuid>%s</uuid>\n", settings.general_settings.uuid);
  if (settings.general_settings.basic_port != 0)
    apr_file_printf(f, "    <basicPort>%d</basicPort>\n", settings.general_settings.basic_port);
  APR_RING_FOREACH(elem, &settings.general_settings.entry_points, str_elem_s, link) {
    apr_file_printf(f, "    <entryPoint>%s</entryPoint>\n", elem->strval);
  }
  apr_file_printf(f, "  </generalSettings>\n");
}

void dump_entry_point_settings(apr_file_t *f)
{
  str_elem_t *elem;

  apr_file_printf(f, "  <entryPointSettings>\n");
  if (settings.entry_point_settings.is_entry_point == 1)
    apr_file_printf(f, "    <isEntryPoint>%s</isEntryPoint>\n", "yes");
  else if (settings.entry_point_settings.is_entry_point == 0)
    apr_file_printf(f, "    <isEntryPoint>%s</isEntryPoint>\n", "no");
  APR_RING_FOREACH(elem, &settings.entry_point_settings.allow_list, str_elem_s, link) {
    apr_file_printf(f, "    <allow>%s</allow>\n", elem->strval);
  }
  APR_RING_FOREACH(elem, &settings.entry_point_settings.deny_list, str_elem_s, link) {
    apr_file_printf(f, "    <deny>%s</deny>\n", elem->strval);
  }
  apr_file_printf(f, "  </entryPointSettings>\n");
}

void dump_debug_settings(apr_file_t *f)
{
  apr_file_printf(f, "  <debugSettings>\n");
  if (settings.debug_settings.is_listening == 1)
    apr_file_printf(f, "    <isListening>%s</isListening>\n", "yes");
  else if (settings.debug_settings.is_listening == 0)
    apr_file_printf(f, "    <isListening>%s</isListening>\n", "no");
  if (settings.debug_settings.debug_port != 0)
    apr_file_printf(f, "    <debugPort>%d</debugPort>\n", settings.debug_settings.debug_port);
  apr_file_printf(f, "  </debugSettings>\n");
}

void dump_logger_settings(apr_file_t *f)
{
  apr_file_printf(f, "  <loggerSettings>\n");
  if (settings.logger_settings.level == P2P_LOG_ERROR)
    apr_file_printf(f, "    <level>%s</level>\n", "error");
  else if (settings.logger_settings.level == P2P_LOG_INFO)
    apr_file_printf(f, "    <level>%s</level>\n", "info");
  else if (settings.logger_settings.level == P2P_LOG_DEBUG)
    apr_file_printf(f, "    <level>%s</level>\n", "debug");
  apr_file_printf(f, "  </loggerSettings>\n");
}

int save_settings(char *filename)
{
  apr_file_t *f = NULL;
  apr_status_t stat;

  p2p_log(P2P_LOG_DEBUG, "save_settings(): start\n");
  stat = apr_file_open(&f, filename, APR_WRITE, APR_OS_DEFAULT, mypool);
  if (stat != APR_SUCCESS) {
      p2p_log(P2P_LOG_ERROR, "save_settings(): cannot open settings file.\n");
      return -1;
  }
  apr_file_printf(f, "<?xml version=\"1.0\" ?>\n");
  apr_file_printf(f, "<settings>\n");
  dump_general_settings(f);
  dump_entry_point_settings(f);
  dump_debug_settings(f);
  dump_logger_settings(f);
  apr_file_printf(f, "</settings>\n");
  apr_file_close(f);
  p2p_log(P2P_LOG_DEBUG, "save_settings(): end\n");
  return 0;
}

#if defined(TEST_SETTINGS)
int main(int argc, const char *const * argv)
{
  (void)apr_initialize();
  apr_pool_create(&mypool, NULL);
#define FNAME	"test.xml"
  init_settings(FNAME);
#if defined(XML_SETTINGS)
  {
    p2p_uuid_t uuid;

    if (settings.general_settings.uuid == 0) {
      apr_uuid_get(&uuid);
      set_uuid_slot(&uuid);
    }
  }
#endif	/* XML_SETTINGS */
  save_settings(FNAME);
  apr_pool_destroy(mypool);
  apr_terminate();
  return 0;
}
#endif	/* TEST_SETTINGS */
