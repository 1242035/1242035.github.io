#include <apr.h>
#include <apr_uuid.h>
#include <apr_thread_proc.h>
#include <apr_network_io.h>
#include <apr_strings.h>
#include <apr_ring.h>
#include "sumalib.h"
#include "routing.h"
#include "internal.h"
#include "msg.h"
#include "clusters.h"
#include "util.h"
#include "chann.h"
#if defined(XML_SETTINGS)
#include "settings.h"
#endif	/* XML_SETTINGS */

extern apr_pool_t *mypool;
extern int myport;
extern unsigned long resolution;
extern void * APR_THREAD_FUNC message_reader(apr_thread_t *t, void *data);
extern void exec_callback(p2p_msg_common_t *header, int port, char *body);
extern void select_connections(char *kind, p2p_destinations_t *dst, p2p_connection_link_t *lst,
			       p2p_connection_t *ex_conn);
extern int send_msg_to_connections(p2p_connection_link_t *lst, apr_size_t *length, char *msg);
extern void dump_connection(apr_socket_t *sock);


int process_reply1(p2p_connection_t *conn, char *buf)
{
  /* for entry-point only */
  p2p_msg_reply_t *msg = (p2p_msg_reply_t *)buf;
  apr_status_t stat;
  char msgbuf[80];
  unsigned int length;

  /* reusing memory for msg */
  p2p_log(P2P_LOG_DEBUG, "process_reply1(): sending!!!, r=%d\n", msg->r);
  length = msg->common.length;
  if ((stat = apr_send(conn->sock, (char *)msg, &length) != APR_SUCCESS)) {
    apr_socket_close(conn->sock);
#if !defined(PROHIBIT_LOCAL_CONNECTION)
    if (conn->is_local)
      remove_connection(adhoc_clusters, conn->r, conn);
    else
      remove_connection(basic_clusters, conn->r, conn);
#else
    remove_connection(basic_clusters, conn->r, conn);
#endif	/* !PROHIBIT_LOCAL_CONNECTION */
    p2p_log(P2P_LOG_ERROR, "Problem sending data: %s (%d)\n",
	    apr_strerror(stat, msgbuf, sizeof(msgbuf)), stat);
    return -1;
  }
  p2p_log(P2P_LOG_DEBUG, "done!!!\n");
  apr_socket_close(conn->sock);		/* FIXME: dangerous? should i wait for ack? */
#if !defined(PROHIBIT_LOCAL_CONNECTION)
  if (conn->is_local)
    remove_connection(adhoc_clusters, conn->r, conn);
  else
    remove_connection(basic_clusters, conn->r, conn);
#else
  remove_connection(basic_clusters, conn->r, conn);
#endif	/* !PROHIBIT_LOCAL_CONNECTION */
  return 0;
}

int reply1_cb(p2p_channel_t *chann)
{
  char buf[2048];
  p2p_connection_t *conn;
  p2p_msg_reply_t *reply;

  p2p_read(chann, buf, 2048);	/* FIXME: 2048? */
  reply = (p2p_msg_reply_t *)buf;
  p2p_log(P2P_LOG_ERROR, "reply1_cb(): got reply for newbee = %s\n", reply->newbee_uuid);
  if ((conn = get_connection(basic_clusters, NO_RESOLUTION, reply->newbee_uuid)) != NULL) {
    return process_reply1(conn, buf);
  }
  p2p_log(P2P_LOG_ERROR, "reply1_cb(): no connection found with newbee\n");
  return -1;
}

static p2p_msg_reply_t *create_reply1(p2p_connection_t *conn, int r, char *newbee_uuid, char *my_uuidstr
#if !defined(PROHIBIT_LOCAL_CONNECTION)
				      , int is_local, char *your_ipaddr
#endif	/* !PROHIBIT_LOCAL_CONNECTION */
				      )
{
  p2p_msg_reply_t *reply;
  int c;
  apr_hash_index_t *i;
  apr_hash_t *cluster;
  unsigned int length;

  c = 0;
#if !defined(PROHIBIT_LOCAL_CONNECTION)
  if (!is_local)
#endif	/* !PROHIBIT_LOCAL_CONNECTION */
  {
    if ((cluster = get_cluster(basic_clusters, r)) != 0)
      for (i = apr_hash_first(mypool, cluster); i; i = apr_hash_next(i), c++);
  }
  length = sizeof(p2p_msg_reply_t) + (sizeof(p2p_cmem_t) * (c + 1));
  reply = (p2p_msg_reply_t *)apr_pcalloc(mypool, length);
  reply->n_mem = c + 1;
  reply->common.length = length;
  apr_cpystrn(reply->common.kind, P2P_KIND_REPLY1, strlen(P2P_KIND_REPLY1) + 1);
  apr_cpystrn(reply->newbee_uuid, newbee_uuid, APR_UUID_FORMATTED_LENGTH + 1);
  reply->r = r;
  c = 0;
#if 0
  apr_cpystrn(reply->mem[c].ipaddr, my_ipaddr, strlen(my_ipaddr) + 1);
#else
#if !defined(PROHIBIT_LOCAL_CONNECTION)
  apr_cpystrn(reply->mem[c].ipaddr, your_ipaddr, strlen(your_ipaddr) + 1);
#else
  {
    apr_sockaddr_t *localsa;
    char *local_ipaddr;

    apr_socket_addr_get(&localsa, APR_LOCAL, conn->sock);
    apr_sockaddr_ip_get(&local_ipaddr, localsa);
    apr_cpystrn(reply->mem[c].ipaddr, local_ipaddr, strlen(local_ipaddr) + 1);
  }
#endif	/* !PROHIBIT_LOCAL_CONNECTION */
#endif
  apr_cpystrn(reply->mem[c].uuid, my_uuidstr, strlen(my_uuidstr) + 1);
  reply->mem[c].port = myport;
  p2p_log(P2P_LOG_DEBUG, "create_reply1(): reply->mem[%d] uuid = %s, ipaddr = %s, port = %d\n", c,
	  reply->mem[c].uuid, reply->mem[c].ipaddr, reply->mem[c].port);
#if 0	/* is_tunnel has meaning at reply2 */
  reply->mem[c].is_tunnel = /*(cluster == 0 ? 1 : 0)*/is_tunnel(r);
#endif
#if !defined(PROHIBIT_LOCAL_CONNECTION)
  if (!is_local)
#endif	/* !PROHIBIT_LOCAL_CONNECTION */
  {
    if (cluster != 0) {
      p2p_connection_t *cc;

      for (i = apr_hash_first(mypool, cluster), c++; i; i = apr_hash_next(i), c++) {
	apr_hash_this(i, NULL, NULL, (void **)&(cc));
	apr_cpystrn(reply->mem[c].ipaddr, cc->ipaddr, strlen(cc->ipaddr) + 1);
	apr_cpystrn(reply->mem[c].uuid, cc->peer_uuid, strlen(cc->peer_uuid) + 1);
	reply->mem[c].port = cc->port;
	p2p_log(P2P_LOG_DEBUG, "create_reply1(): reply->mem[%d] uuid = %s, ipaddr = %s, port = %d\n", c,
		reply->mem[c].uuid, reply->mem[c].ipaddr, reply->mem[c].port);
	reply->mem[c].is_tunnel = cc->is_tunnel;
      }
    }
  }
  p2p_log(P2P_LOG_DEBUG, "create_reply1(): reply->n_mem = %d\n", reply->n_mem);
  return reply;
}

static void send_reply1_by_unicast(char *ep_uuid, p2p_msg_reply_t *reply)
{
  p2p_channel_t *chann = p2p_create_unicast_channel(SUMA_CORE_PORT, ep_uuid);

  p2p_write(chann, (char *)reply, reply->common.length);
}

int process_hello1(p2p_connection_t *tmp, char *buf)
{
  p2p_msg_hello_t *msg = (p2p_msg_hello_t *)buf;
  p2p_connection_t *conn;
  apr_status_t stat;
  char msgbuf[80];
  unsigned int length;
  int r;	/* resolution */
  char my_uuidstr[APR_UUID_FORMATTED_LENGTH + 1];

  tmp->r = NO_RESOLUTION;
#if 0
  dump_clusters();
#endif

  p2p_log(P2P_LOG_DEBUG, "process_hello1(): msg->r = %d\n", msg->r);
  if (msg->r == -1) {	/* i am entry-point */
    apr_cpystrn(tmp->peer_uuid, msg->common.src_uuid, strlen(msg->common.src_uuid) + 1);
    add_connection(basic_clusters, tmp->r, tmp);
    r = resolution;
    apr_uuid_format(msg->ep_uuid, &uuid);
  } else
    r = msg->r;
  find_neighbor(msg->common.src_uuid, &r, &conn);
  msg->r = r;
  if (conn == NULL) {	/* neighbor is me! */
    p2p_msg_reply_t *reply;

#if !defined(PROHIBIT_LOCAL_CONNECTION)
    if (!(msg->is_local))
      resolution = msg->r;
#else
    resolution = msg->r;
#endif	/* !PROHIBIT_LOCAL_CONNECTION */
    apr_uuid_format(my_uuidstr, &uuid);
    reply = create_reply1(tmp, r, msg->common.src_uuid, my_uuidstr
#if !defined(PROHIBIT_LOCAL_CONNECTION)
			  , msg->is_local, msg->your_ipaddr
#endif	/* !PROHIBIT_LOCAL_CONNECTION */
			  );
    p2p_log(P2P_LOG_DEBUG, "process_hello1(): my uuid = %s\n", my_uuidstr);
    p2p_log(P2P_LOG_DEBUG, "process_hello1(): ep uuid = %s\n", msg->ep_uuid);
    if (strncmp(msg->ep_uuid, my_uuidstr, APR_UUID_FORMATTED_LENGTH) == 0) {
      if ((conn = get_connection(basic_clusters, NO_RESOLUTION, msg->common.src_uuid)) != NULL) {
	p2p_log(P2P_LOG_DEBUG, "process_hello1(): i am the entry-point\n");
	return process_reply1(conn, (char *)reply);
      }
      p2p_log(P2P_LOG_ERROR, "process_hello1(): no connection found with newbee\n");
      return -1;
    } else {
      p2p_log(P2P_LOG_DEBUG, "process_hello1(): i am NOT the entry point. send unicast to ep\n");
      send_reply1_by_unicast(msg->ep_uuid, reply);
      return 0;
    }
  }
  /* delegate */
  /* reusing memory for msg */
  p2p_log(P2P_LOG_DEBUG, "process_hello1(): delegate to %s\n", conn->peer_uuid);
  length = msg->common.length;
  if ((stat = apr_send(conn->sock, (char *)msg, &length) != APR_SUCCESS)) {
    apr_socket_close(conn->sock);
#if !defined(PROHIBIT_LOCAL_CONNECTION)
    if (conn->is_local)
      remove_connection(adhoc_clusters, 0, conn);
    else
      remove_connection(basic_clusters, 0, conn);
#else
    remove_connection(basic_clusters, 0, conn);
#endif	/* !PROHIBIT_LOCAL_CONNECTION */
    p2p_log(P2P_LOG_ERROR, "Problem sending data: %s (%d)\n",
	    apr_strerror(stat, msgbuf, sizeof(msgbuf)), stat);
    return -1;
  }
  p2p_log(P2P_LOG_DEBUG, "done!!!\n");
  return 0;
}

int process_hello2(p2p_connection_t *conn, char *buf)
{
  p2p_msg_hello_t *msg = (p2p_msg_hello_t *)buf;
  apr_status_t stat;
  char msgbuf[80];
  unsigned int length;
  p2p_msg_reply_t *reply;
  char my_uuidstr[APR_UUID_FORMATTED_LENGTH + 1];

  apr_cpystrn(conn->peer_uuid, msg->common.src_uuid, strlen(msg->common.src_uuid) + 1);
  apr_cpystrn(conn->ipaddr, msg->ipaddr, strlen(msg->ipaddr) + 1);
  conn->port = msg->port;
  conn->r = msg->r;
#if !defined(PROHIBIT_LOCAL_CONNECTION)
  conn->is_local = msg->is_local;
  if (conn->is_local)
    add_connection(adhoc_clusters, conn->r, conn);
  else {
    add_connection(basic_clusters, conn->r, conn);
  }
#else
  add_connection(basic_clusters, conn->r, conn);
#endif	/* !PROHIBIT_LOCAL_CONNECTION */
#if 0
  dump_clusters();
#endif

  length = sizeof(p2p_msg_reply_t) + sizeof(p2p_cmem_t);
  reply = (p2p_msg_reply_t *)apr_pcalloc(mypool, length);
  apr_cpystrn(reply->common.kind, P2P_KIND_REPLY2, strlen(P2P_KIND_REPLY2) + 1);
  apr_uuid_format(reply->common.src_uuid, &uuid);
  reply->common.length = length;
  reply->n_mem = 1;
  {
    apr_sockaddr_t *localsa;
    char *local_ipaddr;

    apr_socket_addr_get(&localsa, APR_LOCAL, conn->sock);
    apr_sockaddr_ip_get(&local_ipaddr, localsa);
    apr_cpystrn(reply->mem[0].ipaddr, local_ipaddr, strlen(local_ipaddr) + 1);
  }
  apr_cpystrn(reply->mem[0].uuid, my_uuidstr, strlen(my_uuidstr) + 1);
  reply->mem[0].port = myport;
  p2p_log(P2P_LOG_DEBUG, "process_hello2(): reply->mem[0].ipaddr = %s, reply->mem[0].port = %d\n",
	  reply->mem[0].ipaddr, reply->mem[0].port);
  reply->mem[0].is_tunnel = is_tunnel(conn->r);
  reply->r = conn->r;
  p2p_log(P2P_LOG_DEBUG, "process_hello2(): sending!!!, r=%d\n", reply->r);
  if ((stat = apr_send(conn->sock, (char *)reply, &length) != APR_SUCCESS)) {
    apr_socket_close(conn->sock);
#if !defined(PROHIBIT_LOCAL_CONNECTION)
    if (conn->is_local)
      remove_connection(adhoc_clusters, conn->r, conn);
    else
      remove_connection(basic_clusters, conn->r, conn);
#else
    remove_connection(basic_clusters, conn->r, conn);
#endif	/* !PROHIBIT_LOCAL_CONNECTION */
    p2p_log(P2P_LOG_ERROR, "Problem sending data: %s (%d)\n",
	apr_strerror(stat, msgbuf, sizeof(msgbuf)), stat);
    return -1;
  }
  p2p_log(P2P_LOG_DEBUG, "done!!!\n");
  return 0;
}

p2p_destinations_t *construct_destinations_from_msg(char *buf)
{
  p2p_destinations_t *dst;
  char *kind = ((p2p_msg_common_t *)buf)->kind;
  int i;

  if (strncmp(kind, P2P_KIND_BROAD, strlen(P2P_KIND_BROAD)) == 0) {
    dst = 0;
  } else if (strncmp(kind, P2P_KIND_MULTI, strlen(P2P_KIND_MULTI)) == 0) {
    p2p_msg_multicast_header_t *msg = (p2p_msg_multicast_header_t *)buf;
    dst = (p2p_destinations_t *)
      apr_pcalloc(mypool, sizeof(p2p_destinations_t) + (APR_UUID_FORMATTED_LENGTH + 1) * msg->n_dst);

    dst->n_dst = msg->n_dst;
    for (i = 0; i < msg->n_dst; i++) {
      apr_cpystrn(dst->uuids[i], msg->dst_uuids[i], APR_UUID_FORMATTED_LENGTH + 1);
    }
  } else if (strncmp(kind, P2P_KIND_UNI, strlen(P2P_KIND_UNI)) == 0) {
    p2p_msg_unicast_header_t *msg = (p2p_msg_unicast_header_t *)buf;

    dst = (p2p_destinations_t *)
      apr_pcalloc(mypool, sizeof(p2p_destinations_t) + (APR_UUID_FORMATTED_LENGTH + 1));
    dst->n_dst = 1;
    apr_cpystrn(dst->uuids[0], msg->dst_uuid, APR_UUID_FORMATTED_LENGTH + 1);
  }
  return dst;
}

void exec_callback_if_possible(char *buf, p2p_destinations_t *dst)
{
  int found = 0, i;

  if (dst == 0) {
    found = 1;
  } else {
    char uuidstr[APR_UUID_FORMATTED_LENGTH + 1];

    apr_uuid_format(uuidstr, &uuid);
    for (i = 0; i < dst->n_dst; i++) {
      if (strncmp(uuidstr, dst->uuids[i], APR_UUID_FORMATTED_LENGTH) == 0) {
	found = 1;
      }
    }
  }
  if (found) {
    char *kind = ((p2p_msg_common_t *)buf)->kind;
    char *ptr;
    unsigned int port;

    if (strncmp(kind, P2P_KIND_BROAD, strlen(P2P_KIND_BROAD)) == 0) {
      ptr = buf + sizeof(p2p_msg_broadcast_header_t);
      port = ((p2p_msg_broadcast_header_t *)buf)->port;
    } else if (strncmp(kind, P2P_KIND_MULTI, strlen(P2P_KIND_MULTI)) == 0) {
      ptr = buf + sizeof(p2p_msg_multicast_header_t) + (APR_UUID_FORMATTED_LENGTH + 1) * dst->n_dst;
      port = ((p2p_msg_multicast_header_t *)buf)->port;
    } else if (strncmp(kind, P2P_KIND_UNI, strlen(P2P_KIND_UNI)) == 0) {
      ptr = buf + sizeof(p2p_msg_unicast_header_t) + (APR_UUID_FORMATTED_LENGTH + 1);
      port = ((p2p_msg_unicast_header_t *)buf)->port;
    }
    exec_callback((p2p_msg_common_t *)buf, port, ptr);
  }
}

int process_broad(p2p_connection_t *conn, char *buf)
{
  p2p_msg_broadcast_header_t *msg = (p2p_msg_broadcast_header_t *)buf;
  p2p_connection_link_t dst_conn_list;
  apr_size_t length = msg->common.length;

  p2p_log(P2P_LOG_DEBUG, "got broadcast from %s (r = %d)\n", conn->peer_uuid, conn->r);
  exec_callback_if_possible(buf, 0);
  select_connections(msg->common.kind, 0, &dst_conn_list, conn);
  return send_msg_to_connections(&dst_conn_list, &length, buf);
}

void adjust_dst_conn_list(int r, p2p_connection_link_t *lst)
{
  p2p_connection_t *conn;

  APR_RING_FOREACH(conn, lst, p2p_connection_s, link) {
    if (!is_in_cluster(r, conn->peer_uuid)) {
      continue;
    } else {
      p2p_log(P2P_LOG_DEBUG, "adjust_dst_conn_list(): %s removed\n", conn->peer_uuid);
      APR_RING_REMOVE(conn, link);
    }
  }
}

int process_multi(p2p_connection_t *conn, char *buf)
{
  p2p_msg_multicast_header_t *msg = (p2p_msg_multicast_header_t *)buf;
  p2p_connection_link_t dst_conn_list;
  p2p_destinations_t *dst;
  apr_size_t length = msg->common.length;

  p2p_log(P2P_LOG_DEBUG, "got multicast from %s (r = %d)\n", conn->peer_uuid, conn->r);
  dst = construct_destinations_from_msg(buf);
  exec_callback_if_possible(buf, dst);
  select_connections(msg->common.kind, dst, &dst_conn_list, conn);
  adjust_dst_conn_list(conn->r, &dst_conn_list);
  return send_msg_to_connections(&dst_conn_list, &length, buf);
}

int process_uni(p2p_connection_t *conn, char *buf)
{
  p2p_msg_unicast_header_t *msg = (p2p_msg_unicast_header_t *)buf;
  char uuidstr[APR_UUID_FORMATTED_LENGTH + 1];
  p2p_connection_link_t dst_conn_list;
  p2p_destinations_t *dst;
  apr_size_t length = msg->common.length;

  p2p_log(P2P_LOG_DEBUG, "got unicast from %s (r = %d)\n", conn->peer_uuid, conn->r);
  apr_uuid_format(uuidstr, &uuid);
  p2p_log(P2P_LOG_DEBUG, "%s vs. %s\n", uuidstr, msg->dst_uuid);
  dst = construct_destinations_from_msg(buf);
  exec_callback_if_possible(buf, dst);
  select_connections(msg->common.kind, dst, &dst_conn_list, conn);
  return send_msg_to_connections(&dst_conn_list, &length, buf);
}

#if !defined(PROHIBIT_LOCAL_CONNECTION)
int relay_local(char *msg)
{
  p2p_connection_link_t dst_conn_list;
  p2p_destinations_t *dst = construct_destinations_from_msg(msg);
  apr_size_t length = ((p2p_msg_common_t *)msg)->length;
  int rval;

  p2p_log(P2P_LOG_DEBUG, "relay_local(): start\n");
  exec_callback_if_possible(msg, dst);
  select_connections(((p2p_msg_common_t *)msg)->kind, dst, &dst_conn_list, 0);
  rval = send_msg_to_connections(&dst_conn_list, &length, msg);
  p2p_log(P2P_LOG_DEBUG, "relay_local(): end\n");
  return rval;
}
#endif	/* !PROHIBIT_LOCAL_CONNECTION */

char *construct_msg(p2p_channel_t *chann, char *body, int len)
{
  apr_size_t length;

  if (strncmp(chann->kind, P2P_KIND_BROAD, strlen(P2P_KIND_BROAD)) == 0) {
    p2p_msg_broadcast_header_t *msg = (p2p_msg_broadcast_header_t *)
      apr_pcalloc(mypool, length = sizeof(p2p_msg_broadcast_header_t) + len);

    apr_cpystrn(msg->common.kind, P2P_KIND_BROAD, strlen(P2P_KIND_BROAD) + 1);
    apr_uuid_format(msg->common.src_uuid, &uuid);
    msg->common.length = length;
    msg->port = chann->port;
    memcpy(((char *)msg) + sizeof(p2p_msg_broadcast_header_t), body, len);
    return (char *)msg;
  } if (strncmp(chann->kind, P2P_KIND_MULTI, strlen(P2P_KIND_MULTI)) == 0) {
    p2p_msg_multicast_header_t *msg = (p2p_msg_multicast_header_t *)
      apr_pcalloc(mypool, length = (sizeof(p2p_msg_multicast_header_t)
				    + (APR_UUID_FORMATTED_LENGTH + 1) * chann->dst->n_dst
				    + len));
    int i;

    apr_cpystrn(msg->common.kind, P2P_KIND_MULTI, strlen(P2P_KIND_MULTI) + 1);
    apr_uuid_format(msg->common.src_uuid, &uuid);
    msg->common.length = length;
    msg->port = chann->port;
    msg->n_dst = chann->dst->n_dst;
    for (i = 0; i < msg->n_dst; i++) {
      apr_cpystrn(msg->dst_uuids[i], chann->dst->uuids[i], APR_UUID_FORMATTED_LENGTH + 1);
    }
    memcpy(((char *)msg) + (sizeof(p2p_msg_multicast_header_t)
			    + (APR_UUID_FORMATTED_LENGTH + 1) * chann->dst->n_dst),
	   body, len);
    return (char *)msg;
  } if (strncmp(chann->kind, P2P_KIND_UNI, strlen(P2P_KIND_UNI)) == 0) {
    p2p_msg_unicast_header_t *msg = (p2p_msg_unicast_header_t *)
      apr_pcalloc(mypool, length = (sizeof(p2p_msg_unicast_header_t)
				    + (APR_UUID_FORMATTED_LENGTH + 1)
				    + len));

    apr_cpystrn(msg->common.kind, P2P_KIND_UNI, strlen(P2P_KIND_UNI) + 1);
    apr_uuid_format(msg->common.src_uuid, &uuid);
    msg->common.length = length;
    msg->port = chann->port;
    apr_cpystrn(msg->dst_uuid, chann->dst->uuids[0], APR_UUID_FORMATTED_LENGTH + 1);
    memcpy(((char *)msg) + (sizeof(p2p_msg_unicast_header_t)
			    + (APR_UUID_FORMATTED_LENGTH + 1)),
	   body, len);
    return (char *)msg;
  }
  /* NOT REACHED */
  return 0;
}

#if !defined(PROHIBIT_LOCAL_CONNECTION)
extern unsigned int flags;
#endif	/* !PROHIBIT_LOCAL_CONNECTION */

int get_reply(char *ipaddr, int port, int r, char ** reply, apr_socket_t **rsock, char *kind)
{
  apr_socket_t *sock;
  apr_sockaddr_t *remote_sa;
  apr_status_t stat;
  char msgbuf[80];
  apr_size_t length;
  p2p_msg_hello_t *msg;

  if ((stat = apr_sockaddr_info_get(&remote_sa, ipaddr, APR_UNSPEC, port, 0, mypool)) != APR_SUCCESS) {
    p2p_log(P2P_LOG_ERROR, "Address resolution failed for %s: %s\n",
	ipaddr, apr_strerror(stat, msgbuf, sizeof(msgbuf)));
    return -1;
  }
  if (apr_socket_create(&sock, remote_sa->family, SOCK_STREAM, mypool) != APR_SUCCESS) {
    p2p_log(P2P_LOG_ERROR, "Couldn't create socket\n");
    return -1;
  }
  p2p_log(P2P_LOG_DEBUG, "get_reply(): connecting for %s!!!\n", kind);
  stat = apr_connect(sock, remote_sa);
  if (stat != APR_SUCCESS) {
    apr_socket_close(sock);
    p2p_log(P2P_LOG_ERROR, "Could not connect: %s (%d)\n", 
	apr_strerror(stat, msgbuf, sizeof(msgbuf)), stat);
    return -1;
  }
  dump_connection(sock);
  msg = (p2p_msg_hello_t *)apr_pcalloc(mypool, length = sizeof(p2p_msg_hello_t));
  msg->common.length = length;
  msg->r = r;
#if !defined(PROHIBIT_LOCAL_CONNECTION)
  msg->is_local =
#if defined(XML_SETTINGS)
    settings.general_settings.is_listening == 0
#else
    !(flags & P2P_INIT_SERVER)
#endif	/* XML_SETTINGS */
    ;
  p2p_log(P2P_LOG_DEBUG, "get_reply(): msg is %slocal\n", msg->is_local ? "" : "NOT ");
  {
    apr_sockaddr_t *remotesa;
    char *remote_ipaddr;

    apr_socket_addr_get(&remotesa, APR_REMOTE, sock);
    apr_sockaddr_ip_get(&remote_ipaddr, remotesa);
    apr_cpystrn(msg->your_ipaddr, remote_ipaddr, strlen(remote_ipaddr) + 1);
  }
#endif	/* !PROHIBIT_LOCAL_CONNECTION */
  apr_cpystrn(msg->common.kind, kind, strlen(kind) + 1);
  apr_uuid_format(msg->common.src_uuid, &uuid);
  apr_cpystrn(msg->ipaddr, ipaddr, strlen(ipaddr) + 1);
  msg->port = myport;
  p2p_log(P2P_LOG_DEBUG, "get_reply(): sending %s!!!\n", kind);
  if ((stat = apr_send(sock, (char *)msg, &length) != APR_SUCCESS)) {
    apr_socket_close(sock);
    p2p_log(P2P_LOG_ERROR, "Problem sending data: %s (%d)\n",
	apr_strerror(stat, msgbuf, sizeof(msgbuf)), stat);
    return -1;
  }
  p2p_log(P2P_LOG_DEBUG, "get_reply(): done!!!\n");
  if (read_msg(sock, reply) == -1) {
    return -1;
  }
  /* FIXME: check if reply->kind.id == REPLY* */
  *rsock = sock;
  return 0;
}

void establish_basic_connection(
#if defined(XML_SETTINGS)
				str_elem_link_t *entry_points
#else
				char *entry_points_ip_addrs[]
#endif
				)
{
  int i;
  p2p_msg_reply_t *reply;
  apr_socket_t *sock;
  p2p_connection_t *conn;
#if defined(XML_SETTINGS)
  str_elem_t *elem;

  APR_RING_FOREACH(elem, entry_points, str_elem_s, link) {
    char *ip_addr;
    int port;

    split_ipaddr_string(elem->strval, &ip_addr, &port, P2P_PORT);
#else

  for (i = 0; ; i++) {
    char *ip_addr;
    int port;

    if (entry_points_ip_addrs[i] == 0)
      break;
    split_ipaddr_string(entry_points_ip_addrs[i], &ip_addr, &port, P2P_PORT);
#endif
    p2p_log(P2P_LOG_DEBUG, "establish_basic_connection(): entry_points_ip_addrs[%d] = %s, port = %d\n", i, ip_addr, port);
    if (get_reply(ip_addr, port, NO_RESOLUTION, (char **)&reply, &sock, P2P_KIND_HELLO1) < 0)
      break;	/* FIXME: continue? */
    /* FIXME: send BYE msg */
    resolution = reply->r;
    apr_socket_close(sock);
    {
      int j;
      p2p_msg_reply_t *reply2;

      p2p_log(P2P_LOG_DEBUG, "establish_basic_connection(): reply->n_mem = %d\n", reply->n_mem);
      for (j = 0; j < reply->n_mem; j++) {
	p2p_log(P2P_LOG_DEBUG, "establish_basic_connection(): uuid = %s, ipaddr = %s, port = %d\n",
		reply->mem[j].uuid, reply->mem[j].ipaddr, reply->mem[j].port);
	if (get_reply(reply->mem[j].ipaddr, reply->mem[j].port, reply->r, (char **)&reply2, &sock, P2P_KIND_HELLO2) < 0)
	  break;	/* FIXME: should exit? */
	conn = create_connection(sock, reply2->common.src_uuid, reply2->mem[0].ipaddr, reply2->mem[0].port,
				 reply2->mem[0].is_tunnel, reply2->r);
#if !defined(PROHIBIT_LOCAL_CONNECTION)
	conn->is_local =
#if defined(XML_SETTINGS)
	  settings.general_settings.is_listening == 0
#else
	  !(flags & P2P_INIT_SERVER)
#endif	/* XML_SETTINGS */
	  ;
	if (conn->is_local)
	  add_connection(adhoc_clusters, conn->r, conn);
	else
	  add_connection(basic_clusters, conn->r, conn);
#else
	add_connection(basic_clusters, conn->r, conn);
#endif	/* !PROHIBIT_LOCAL_CONNECTION */
      }
      p2p_log(P2P_LOG_DEBUG, "establish_basic_connection(): established\n");
    }
    if (reply->n_mem > 0)
      break;
  }
  p2p_log(P2P_LOG_DEBUG, "establish_basic_connection(): finished\n");
}
