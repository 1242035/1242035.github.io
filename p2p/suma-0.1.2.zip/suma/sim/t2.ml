let nodes = Hashtbl.create 100

class node =
  object (self)
    val uuid = 0
    val neighbors = ref []
    method get_neighbors() = !neighbors
    method get_uuid() = uuid
    method add_neighbor (n:node) = neighbors := n :: !neighbors
    method aaa (n:node) = n#add_neighbor (Hashtbl.find nodes uuid)
  end

let gen_node() =
  let n = new node in
  Hashtbl.add nodes (n#get_uuid()) n
