open Printf;;

(* 1-d hash function
H(x,0) = 0
H(x,r) = H(x,r-1) * 2 + (x%(2^r) / 2^(r-1))
*)
let pow2 x = int_of_float (2.0 ** float_of_int x)
let rec h1 id r =
  if r = 0 then 0
  else
    (((h1 id (r-1)) * 2) + ((id mod (pow2 r)) / (pow2 (r - 1))))
let h1s r =
  for i = 0 to (pow2 r) - 1 do
    print_int (h1 i r); print_string " "
  done;
  print_newline()

(* n-tree hash function
H(n,x,0) = 0
H(n,x,r) = H(n,x,r-1) * n + (x%((2^n)^r) / (2^n)^(r-1))
*)
let pow2n n x = int_of_float ((2.0 ** (float_of_int n)) ** float_of_int x)
let rec hn n id r =
  if r = 0 then 0
  else
    (((hn n id (r-1)) * (pow2 n)) + ((id mod (pow2n n r)) / (pow2n n (r - 1))))
let hns n r =
  for i = 0 to (pow2n n r) - 1 do
    print_int (hn n i r); print_string " "
  done;
  print_newline()

(* 4-tree hash function
H(x,0) = 0
H(x,r) = H(x,r-1) * 4 + (x%(4^r) / 4^(r-1))
*)
let pow4 x = int_of_float (4.0 ** float_of_int x)
let rec t4 id r =
  if r = 0 then 0
  else
    (((t4 id (r-1)) * 4) + ((id mod (pow4 r)) / (pow4 (r - 1))))
let t4s r =
  for i = 0 to (pow4 r) - 1 do
    print_int (t4 i r); (* print_string " " *)print_newline()
  done(*;
  print_newline()
*)

(* 2-d hash function
H(x,0) = (0,0)
H(x,r) = H(x,r-1) * r + (dx, dy)
*)
let rec h2 id r =
  if r = 0 then (0,0)
  else
    let (x,y) = h2 (id / 4) (r-1) in
    let xx = x * 2 in
    let yy = y * 2 in
    match (id mod 4) with
      0 -> (xx,yy)
    | 1 -> (xx+1,yy)
    | 2 -> (xx,yy+1)
    | 3 -> (xx+1,yy+1)
let h2s r =
  for i = 0 to (pow4 r) - 1 do
    let u = t4 i r in
    let (x,y) = h2 u r in
    Printf.printf "%d\t->\t%d:\t(%d,%d)" i u x y; print_newline()
  done

