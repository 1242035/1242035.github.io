(* FIXME:
   o  maintain replica
   o  maintain minimul resolution
*)

open Tk

let cwidth = 400
let cheight = 400
let top = openTk ()
let fw = Frame.create top
let c = Canvas.create ~width: cwidth ~height: cheight fw
let max_tseqn = ref 0
let n_nodes = ref 0
let n_removed = ref 0
let nodes = Hashtbl.create 100
let max_seqn = ref 0

let log = Format.printf

let redraw() =
(*
  log "=============================================@.";
*)
  Canvas.delete c [`Tag "figures"];
  Hashtbl.iter (fun id n -> n#draw_node c) nodes;
  Hashtbl.iter (fun id n -> n#draw_clusters c) nodes

let gen_uuid() = Random.bits()

let incr_max_seqn() =
  let rval = !max_seqn in
  max_seqn := !max_seqn + 1;
  rval

let select_node_randomly() =
  let idx = Random.int (!n_nodes - !n_removed) in
  let i = ref 0 in
  let ep = ref 0 in
  Hashtbl.iter (fun id n -> if !i = idx then ep := (n#get_uuid()); i := !i + 1) nodes;
  (* log "ep = %d@." !ep; *)
  Hashtbl.find nodes !ep

let decide_entry_point = select_node_randomly

(* 4-tree hash function
H(x,0) = 0
H(x,r) = H(x,r-1) * 4 + (x%(4^r) / 4^(r-1))
*)
let pow4 x = int_of_float (4.0 ** float_of_int x)
let rec t4 id r =
  if r = 0 then 0
  else
    (((t4 id (r-1)) * 4) + ((id mod (pow4 r)) / (pow4 (r - 1))))
(* 2-d hash function
H(x,0) = (0,0)
H(x,r) = H(x,r-1) * r + (dx, dy)
*)
let rec h2 id r =
  if r = 0 then (0,0)
  else
    let (x,y) = h2 (id / 4) (r-1) in
    let xx = x * 2 in
    let yy = y * 2 in
    match (id mod 4) with
      0 -> (xx,yy)
    | 1 -> (xx+1,yy)
    | 2 -> (xx,yy+1)
    | 3 -> (xx+1,yy+1)
let p2p_hash id r =
  let u = t4 id r in
  h2 u r

let heq n1 n2 (r:int) =
  let uuid1 = n1#get_uuid() in
  let uuid2 = n2#get_uuid() in
  let seqn1 = n1#get_seqn() in
  let seqn2 = n2#get_seqn() in
  let (x1, y1) = p2p_hash uuid1 r in
  let (x2, y2) = p2p_hash uuid2 r in
  log "at r=%d [%d(%d) -> (%d,%d)], [%d(%d) -> (%d,%d)]@."
    r seqn1 uuid1 x1 y1 seqn2 uuid2 x2 y2;
  if x1 = x2 && y1 = y2 then true else false

let rec find_neighbor n1 n2 (r:int) =
  log "find_neighbor %d for %d@." (n1#get_seqn()) (n2#get_seqn());
  if (n1#get_uuid()) = (n2#get_uuid()) then (n1, 0)
  else
    if (heq n1 n2 r) = true then (
      match (n1#neighbor_heq n2 (r + 1)) with
	None ->
	  log "case1@.";
	  (n1, r + 1)
      | Some (n3) ->
	  log "case2@.";
	  find_neighbor n3 n2 (r + 1)
     ) else (
      if (heq n1 n2 (r - 1)) = false then (
	log "case3@.";
	find_neighbor (n1#find_tunnel ~low:(r - 1) ~heigh:r) n2 (r - 1)
       ) else
	match (n1#neighbor_heq n2 r) with
	  None ->
	    log "case4@.";
	    (n1, r)
	| Some (n3) ->
	    log "case5@.";
	    find_neighbor n3 n2 r
     )

let rec find_node n1 n2 (r:int) =
  log "find_node %d for %d@." (n1#get_seqn()) (n2#get_seqn());
  if (heq n1 n2 r) = true then (
    if n1 = n2 then (
      log "case1@.";
      Some (n1)
    ) else
      match (n1#neighbor_heq n2 (r + 1)) with
	None ->
	  log "something wrong occurred@.";
	  None
      | Some (n3) ->
	  log "case2@.";
	  find_node n3 n2 (r + 1);
   ) else (
     if (heq n1 n2 (r - 1)) = false then (
       log "case3@.";
       find_node (n1#find_tunnel ~low:(r - 1) ~heigh:r) n2 (r - 1)
      ) else
       if n1 = n2 then (
	 log "case4@.";
	 Some (n1)
	) else
	 match (n1#neighbor_heq n2 r) with
	   None ->
	     log "something wrong occurred@.";
	     None
	 | Some (n3) ->
	     log "case5@.";
	     find_node n3 n2 r
   )

exception Found
exception Funny
exception Removed
exception Not_tunnel

let broadcasted = ref (Hashtbl.create 100)

class cnt =
  object (self)
    val mutable cnt = 0
    method get() = cnt
    method incr() = cnt <- (cnt + 1)
  end

class node =
  object (self)
    val mutable removed = false
    val seqn = incr_max_seqn()
    val mutable uuid = gen_uuid()
    val mutable resolution = 0
    val clusters = Hashtbl.create 16
    method check_if_removed() = if removed then raise Removed
    method get_seqn() = self#check_if_removed(); seqn
    method get_uuid() = self#check_if_removed(); uuid
    method set_uuid id = self#check_if_removed(); uuid <- id
    method get_resolution() = self#check_if_removed(); resolution
    method set_resolution (r:int) =
      self#check_if_removed();
      if resolution < r then resolution <- r

    method replicate_exit (r1:int) (r2:int) (cluster_r:int) (n:node) =
      self#check_if_removed();
      log "trying to set secondary exit from %d to %d at node-%d@." r1 r2 seqn;
      try 
	Hashtbl.iter
	  (fun id (is_awake, tseqn, tcnt, nn) ->
	    if is_awake then begin
	      tcnt#incr();
	      nn#add_connection n cluster_r ~is_awake:false ~tseqn:(tcnt#get()) ~tcnt:tcnt;
	      n#add_connection nn cluster_r ~is_awake:false ~tseqn:(tcnt#get()) ~tcnt:tcnt;
	    end)
	  (Hashtbl.find clusters cluster_r);
	raise Exit
      with
	Not_found -> ()

    method replicate_exits (r:int) (n:node) =
      self#check_if_removed();
      log "replication start@.";
      (try
	for i = r downto 1 do
	  self#replicate_exit (i - 1) i (i - 1) n;
	done
      with
	Exit -> ());
      (try
	for i = r to resolution do
	  self#replicate_exit i (i + 1) (i + 1) n;
	done
      with
	Exit -> ());
      log "replication end@."

    method has_heigher_exit (r:int) =
      self#check_if_removed();
      log "has_heigher_exit: r=%d@." r;
      let rval = ref false in
      for i = r downto 0 do
	try
	  Hashtbl.iter
	    (fun id (is_awake, tseqn, tcnt, nn) ->
	      if !rval <> true then rval := is_awake)
	    (Hashtbl.find clusters i);
	with
	  Not_found -> ()
      done;
      if !rval <> true then raise Not_tunnel;
      !rval

    method find_tunnel_aux (r1:int) (r2:int) =
      self#check_if_removed();
      log "searching tunnel from %d to %d at node-%d@." r2 r1 seqn;
      let tunnel = ref (Hashtbl.find nodes uuid) in
      try
	if (self#has_heigher_exit r1) then Some (!tunnel) else None
      with
	Not_tunnel ->
	  log "node-%d is not a tunnel from %d to %d@." seqn r2 r1;
	  None

    method find_tunnel ~low:(r1:int) ~heigh:(r2:int) =
      self#check_if_removed();
      let tunnel = ref (Hashtbl.find nodes uuid) in
      match (self#find_tunnel_aux r1 r2) with
	Some (b) ->
	  log "tunnel = %d@." ((!tunnel)#get_seqn());
	  !tunnel
      |	None ->
	  try
	    Hashtbl.iter
	      (fun id (is_awake, tseqn, tcnt, nn) ->
		if is_awake then
		  match (nn#find_tunnel_aux r1 r2) with
		    Some (bb) -> tunnel := bb; raise Found
		  | None -> ())
	      (Hashtbl.find clusters r2);
	    log "something wrong occurred@.";
	    !tunnel (* dummy: must not occur *)
	  with
	    Found ->
	      log "tunnel = %d@." ((!tunnel)#get_seqn());
	      !tunnel

    method neighbor_heq (n:node) (r:int) =
      self#check_if_removed();
      if (heq self n r) = true then Some (Hashtbl.find nodes uuid)
      else
	let neighbor = ref n in
	try
	  Hashtbl.iter
	    (fun id (is_awake, tseqn, tcnt, nn) ->
	      if is_awake && (heq nn n r) = true then begin
		neighbor := nn;
		raise Found
	      end)
	    (Hashtbl.find clusters r);
	  None
	with
	  Found -> Some !neighbor
	| Not_found -> None

    method add_connection (n:node) (r:int) ~is_awake:(is_awake:bool) ~tseqn:(tseqn:int) ~tcnt:tcnt =
      self#check_if_removed();
      let neighbors =
	try
	  Hashtbl.find clusters r
	with
	  Not_found ->
	    Hashtbl.add clusters r (Hashtbl.create 16);
	    Hashtbl.find clusters r
      in
      log "add_connection: %d -> %d (r=%d, %s)@." seqn (n#get_seqn()) r (if is_awake then "awake" else "sleeping");
      Hashtbl.add neighbors (n#get_uuid()) (is_awake, tseqn, tcnt, n)

    method connect_with (n:node) (r:int) =
      self#check_if_removed();
      if n#get_seqn() = 0 then
	()
      else begin
	self#add_connection n r ~is_awake:true ~tseqn:0 ~tcnt:(new cnt);
	n#add_connection (Hashtbl.find nodes uuid) r ~is_awake:true ~tseqn:0 ~tcnt:(new cnt);
	Hashtbl.iter
	  (fun id (is_awake, tseqn, tcnt, nn) ->
	    if is_awake then
	      if (nn#get_uuid()) <> (n#get_uuid()) then begin
		n#add_connection nn r ~is_awake:true ~tseqn:0 ~tcnt:(new cnt);
		nn#add_connection n r ~is_awake:true ~tseqn:0 ~tcnt:(new cnt)
	      end)
	  (Hashtbl.find clusters r)
      end

    method send_broad_aux (n:node) (sending_cluster:int) =
      self#check_if_removed();
      log "send_broad_aux: got packet at %d@." seqn;
      try
	Hashtbl.add !broadcasted uuid true;
	let clusters_to_send = ref [] in
	Hashtbl.iter
	  (fun r tbl -> if sending_cluster <> r then clusters_to_send := r :: !clusters_to_send)
	  clusters;
	List.iter
	  (fun x ->
	    try
	      let tbl = (Hashtbl.find clusters x) in
	      Hashtbl.iter
		(fun id (is_awake, tseqn, tcnt, nn) ->
		  if is_awake then nn#send_broad_aux (Hashtbl.find nodes uuid) x)
		tbl
	    with
	      Not_found -> ()
	  )
	  !clusters_to_send
      with
	Funny -> log "send_broad_aux: NG@."

    method send_broad() =
      self#check_if_removed();
      broadcasted := Hashtbl.create 100;
      Hashtbl.add !broadcasted uuid true;
      Hashtbl.iter
	(fun r tbl ->
	  try
	    Hashtbl.iter
	      (fun id (is_awake, tseqn, tcnt, nn) -> if is_awake then nn#send_broad_aux (Hashtbl.find nodes uuid) r)
	      tbl
	  with
	    Not_found -> ()
	)
	clusters;
      (try
	Hashtbl.iter
	  (fun id not_used -> let _ = Hashtbl.find !broadcasted id in ())
	  nodes;
	log "created -> broadcasted: OK@."
      with
	Not_found -> log "created -> broadcasted: NG@.");
      (try
	Hashtbl.iter
	  (fun id not_used -> let _ = Hashtbl.find nodes id in ())
	  !broadcasted;
	log "broadcasted -> created: OK@."
      with
	Not_found -> log "broadcasted -> created: NG@.")

    method remove_connection r id =
      (* FIXME: remove table if no elem *)
      Hashtbl.remove (Hashtbl.find clusters r) id

    method remove_connections peer_uuid =
      let rlst = ref [] in
      Hashtbl.iter
	(fun r tbl ->
	  Hashtbl.iter
       	    (fun id (is_awake, tseqn, tcnt, nn) ->
	      if (nn#get_uuid()) = peer_uuid then rlst := (r, peer_uuid) :: !rlst)
	    tbl)
	clusters;
      List.iter	(fun (r, id) -> self#remove_connection r id) !rlst

    method wakeup_secondary_connection r peer_uuid =
      let tbl = (Hashtbl.find clusters r) in
      let is_awake, tseqn, tcnt, nn = Hashtbl.find tbl peer_uuid in
      Hashtbl.remove tbl peer_uuid;
      Hashtbl.add tbl peer_uuid (true, tseqn, tcnt, nn);

    method notify_node_deletion peer_seqn peer_uuid r peer_is_awake peer_tseqn =
      log "node:%d, conn:%d->%d (%s, %d, r=%d) disconnected@."
	seqn seqn peer_seqn (if peer_is_awake then "awake" else "sleeping") peer_tseqn r;
      let tbl = (Hashtbl.find clusters r) in
      let secondary_tunnel_uuid = ref 0 in
      let found = ref false in
      Hashtbl.iter
	(fun id (is_awake, tseqn, tcnt, nn) ->
	  log "  node:%d, conn:%d->%d (%s, %d)@."
	    (nn#get_seqn()) seqn (nn#get_seqn()) (if is_awake then "awake" else "sleeping") tseqn;
	  if tseqn = peer_tseqn + 1 then begin
	    secondary_tunnel_uuid := (nn#get_uuid());
	    found := true
	  end)
	tbl;
      if !found then begin
	log "  activating %d-th secondary %d...@." (peer_tseqn + 1) ((Hashtbl.find nodes !secondary_tunnel_uuid)#get_seqn());
	let is_awake, tseqn, tcnt, nn = Hashtbl.find tbl !secondary_tunnel_uuid in
	Hashtbl.remove tbl !secondary_tunnel_uuid;
	Hashtbl.add tbl !secondary_tunnel_uuid (true, tseqn, tcnt, nn);
	nn#wakeup_secondary_connection r uuid
      end;
      self#remove_connections peer_uuid

    method remove() =
      log "removing node:%d...@." seqn;
      Hashtbl.iter
	(fun r tbl ->
	  Hashtbl.iter
       	    (fun id (is_awake, tseqn, tcnt, nn) -> nn#notify_node_deletion seqn uuid r is_awake tseqn)
	    tbl)
	clusters;
      removed <- true

    method draw_node c =
      self#check_if_removed();
      let (x, y) = p2p_hash uuid resolution in
      let w = cwidth / int_of_float (2.0 ** (float_of_int resolution)) in
      let h = cheight / int_of_float (2.0 ** (float_of_int resolution)) in
      let ox = w * x in
      let oy = h * y in
      let x1 = ox in
      let y1 = oy in
      let x2 = ox + w in
      let y2 = oy + h in
(*
      log "%d: [uuid = %d, h=(%d, %d) at r = %d] " seqn uuid x y resolution;
      log "x1 = %d, y1 = %d, x2 = %d, y2 = %d" x1 y1 x2 y2;
      log "@.";
*)
      let _ = Canvas.create_oval ~x1:x1 ~y1:y1 ~x2:x2 ~y2:y2 ~tags:["figures"] ~outline: `Black ~width: 1 (*~fill: `White*) c in
      let _ = Canvas.create_text ~x:x1 ~y:y1 ~text:(string_of_int seqn) ~tags:["figures"] ~anchor:`Nw c in
      ()

    method draw_cluster c tbl ox oy cx cy r =
      self#check_if_removed();
      try
	Hashtbl.iter
	  (fun id (is_awake, tseqn, tcnt, nn) ->
	    let (nx, ny) = p2p_hash id (nn#get_resolution()) in
	    let nw = cwidth / int_of_float (2.0 ** (float_of_int (nn#get_resolution()))) in
	    let nh = cheight / int_of_float (2.0 ** (float_of_int (nn#get_resolution()))) in
	    let nox = nw * nx in
	    let noy = nh * ny in
	    let ncx = nox + nw / 2 in
	    let ncy = noy + nh / 2 in
	    let color = if is_awake then `Black
	    else
	      match tseqn with
	      	1 -> `Red
	      |	2 -> `Blue
	      |	3 -> `Green
	      |	_ -> `Yellow
	    in
(*
	    log "draw_cluster: connection %d -> %d, r=%d, %s, tseqn = %d@." seqn (nn#get_seqn()) r (if is_awake then "awake" else "sleeping") tseqn;
*)
	    if (*true*) tseqn <= !max_tseqn then (
	      let _ = Canvas.create_line ~xys:[cx,cy; ncx,ncy] ~tags:["figures"] ~fill:color ~width: 1 ~arrow:`Last c in
	      ()
	     ) else ())
	  tbl
      with
	Not_found -> ()

    method draw_clusters c =
      self#check_if_removed();
(*
      log "---------------------------------------------@.";
*)
      let (x, y) = p2p_hash uuid resolution in
      let w = cwidth / int_of_float (2.0 ** (float_of_int resolution)) in
      let h = cheight / int_of_float (2.0 ** (float_of_int resolution)) in
      let ox = w * x in
      let oy = h * y in
      let cx = ox + w / 2 in
      let cy = oy + h / 2 in
      Hashtbl.iter
	(fun rr tbl ->
	  try
	    self#draw_cluster c tbl ox oy cx cy rr
	  with
	    Not_found -> ()
	)
	clusters

  end

let gen_node() =
  log "=============================================@.";
  let n = new node in
  let ep = if !n_nodes > 0 then decide_entry_point() else n in
  Hashtbl.add nodes (n#get_uuid()) n;
  let (neighbor, r) = find_neighbor ep n (ep#get_resolution()) in
  log "found neighbor: node = %d, r = %d@." (neighbor#get_seqn()) r;
  (* following process should be define as 'put_into_cluster' *)
  n#set_resolution r;
  neighbor#set_resolution r;
  neighbor#replicate_exits r n;
  neighbor#connect_with n r;
  n_nodes := !n_nodes + 1;
  redraw()

let send_uni() =
  Hashtbl.iter
    (fun i n ->
      Hashtbl.iter
	(fun ii nn ->
	  log "---------------------------------------------@.";
	  log "send unicast from node-%d to node-%d@." (n#get_seqn()) (nn#get_seqn());
	  match (find_node n nn (n#get_resolution())) with
	    None ->
	      log "not found@.";
	  | Some (nnn) ->
	      log "node-%d found@." (nnn#get_seqn());
	)
	nodes
    )
    nodes

let send_broad() =
  let received_nodes = ref [] in
  Hashtbl.iter
    (fun i n ->
      log "---------------------------------------------@.";
      log "send broadcast from node-%d@." (n#get_seqn());
      n#send_broad()
    )
    nodes

let toggle_awake_all() =
  max_tseqn := (if !max_tseqn < 3 then !max_tseqn + 1 else if !max_tseqn = 99 then 0 else 99);
  redraw()

let remove_node() =
  let n = select_node_randomly() in
  let uuid = n#get_uuid() in
  n#remove();
  Hashtbl.remove nodes uuid;
  n_removed := !n_removed + 1;
  redraw()

let _ =
  let fb = Frame.create top in
  let b1 = Button.create ~text: "Node" ~command:(fun () -> gen_node()) fb in
  let b2 = Button.create ~text: "Uni" ~command:(fun () -> send_uni()) fb in
  let b3 = Button.create ~text: "Broad" ~command:(fun () -> send_broad()) fb in
  let b8 = Button.create ~text: "Remove" ~command:(fun () -> remove_node()) fb in
  let b9 = Button.create ~text: "Awake/All" ~command:(fun () -> toggle_awake_all()) fb in
  pack ~anchor:`E ~side:`Left [b1];
  pack ~anchor:`E ~side:`Left [b2];
  pack ~anchor:`E ~side:`Left [b3];
  pack ~anchor:`E ~side:`Left [b8];
  pack ~anchor:`E ~side:`Right [b9];
  pack [fb];
  pack [fw];
  pack [c];
  Random.init 123456;
  gen_node()

let _ = Printexc.print mainLoop ()
