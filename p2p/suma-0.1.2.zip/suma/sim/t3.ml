for i = 3 downto 0 do
  print_int i; print_newline()
done
