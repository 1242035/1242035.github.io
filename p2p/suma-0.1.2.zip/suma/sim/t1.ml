let rmelt lst elt =
  let tmp = ref [] in
  List.iter
    (fun x -> if x <> elt then tmp := !tmp @ [x])
    lst;
  !tmp
