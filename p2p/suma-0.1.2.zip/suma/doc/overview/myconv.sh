CNT=0
for f in `ls src`; do
    cp src/$f dst/$f.jpg
    CNT=$CNT+1
done
