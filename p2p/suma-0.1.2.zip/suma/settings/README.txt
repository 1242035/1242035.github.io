1: f0c0b0fb-d11d-b211-8951-9638feacc9ad
2: ca42f6ff-d11d-b211-b95e-f4bbb877f0b6
3: 189522dc-d11d-b211-9aa1-90e0f4e9d90c
4: d2a96222-d21d-b211-8e44-fbe4e38efc95
5: 6ce109bd-d11d-b211-ad75-ec74e2521be7
6: 7e2b5420-d21d-b211-af3e-eb2346a0cbd6

r=1:     1  2  3  5
         |  |
r=2:  4--+  |
            |
r=3:        +--6
